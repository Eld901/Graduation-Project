package com.example.dao;

import com.example.entity.Log;
import com.example.entity.Params;
import com.example.entity.Sync;
import com.example.entity.SyncUser;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;
import tk.mybatis.mapper.common.Mapper;

import java.util.List;

@Repository
public interface SyncUserDao extends Mapper<SyncUser> {
    @Select("select * from syncuser where syncid = #{syncid} and userid = #{userid}")
    SyncUser findSyncUserById(@Param("syncid") Integer syncid,@Param("userid") Integer userid);

    @Select("select * from syncuser where syncid = #{syncid}")
    List<SyncUser> findSyncUserGroup(@Param("syncid")Integer syncid);

    @Select("select * from syncuser order by id desc")
    List<SyncUser> findSyncAllGroup();

    @Delete("delete from syncuser where syncid = #{syncid}")
    void deleteSyncUser(@Param("syncid")Integer id);

    List<SyncUser> findSyncUserBySearch(@Param("params")Params params);

    @Select("select * from syncuser where syncjoinid = #{syncjoinid}")
    SyncUser findSyncUserByjoinID(@Param("syncjoinid")Integer syncjoinid);

    @Select("select * from syncuser where id = #{id}")
    SyncUser findSyncUserByID(@Param("id")Integer id);
}
