package com.example.dao;

import com.example.entity.Category;
import com.example.entity.Login;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;
import tk.mybatis.mapper.common.Mapper;

import java.util.List;

@Repository
public interface LoginDao extends Mapper<Login> {
    @Select("select * from login where userid = #{id}")
    List<Login> findByUserId(@Param("id")Integer id);

    @Delete("DELETE FROM login WHERE userid = #{id}")
    void removeLoginByUserId(Integer id);
}
