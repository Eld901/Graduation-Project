package com.example.dao;

import com.example.entity.Files;
import com.example.entity.Params;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;
import tk.mybatis.mapper.common.Mapper;

import java.util.List;

@Repository
public interface FilesDao extends Mapper<Files> {
    @Select("select * from files where userid = #{id}")
    List<Files> findByUserId(@Param("id")Integer id);

    @Delete("delete from files where categoryid = #{categoryid}")
    void deleteByCategoryId(@Param("categoryid")Integer id);

    List<Files> findFilesBySearch(@Param("params")Params params);
}
