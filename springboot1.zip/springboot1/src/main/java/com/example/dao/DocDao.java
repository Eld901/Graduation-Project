package com.example.dao;

import com.example.entity.Category;
import com.example.entity.Document;
import com.example.entity.Params;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;
import tk.mybatis.mapper.common.Mapper;

import java.util.List;

@Repository
public interface DocDao extends Mapper<Document> {
    @Select("select * from document where userid = #{id}")
    List<Document> findByUserId(@Param("id")Integer id);

    @Delete("delete from document where categoryid = #{categoryid}")
    void deleteByCategoryId(@Param("categoryid")Integer id);

    @Select("select * from document where categoryid = #{categoryid}")
    List<Document> findDocByCategoryId(@Param("categoryid")Integer id);

    List<Document> findDocBySearch(@Param("params")Params params);

    @Select("select * from document where username = #{name}")
    List<Document> findDocByName(@Param("name")String name);

    @Select("select * from document where id = #{id}")
    Document findDocById(@Param("id")Integer id);
}
