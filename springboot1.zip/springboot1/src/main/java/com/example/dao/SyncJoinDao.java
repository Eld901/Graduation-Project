package com.example.dao;

import com.example.entity.Params;
import com.example.entity.Sync;
import com.example.entity.SyncJoin;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;
import tk.mybatis.mapper.common.Mapper;

import java.util.List;

@Repository
public interface SyncJoinDao extends Mapper<SyncJoin> {
    @Select("select * from syncjoin where joinid = #{id} and userid = #{userid}")
    SyncJoin findSyncJoinById(@Param("id") Integer id,@Param("userid") Integer userid);


    @Select("select * from syncjoin where userid = #{id}")
    List<SyncJoin> findSyncJoinList(@Param("id")Integer id);

    @Delete("delete from syncjoin where joinid = #{joinid}")
    void deleteSyncJoin(@Param("joinid")Integer id);

    List<SyncJoin> findSyncJoinBySearch(@Param("params")Params params);

    @Select("select * from syncjoin where joinid = #{joinid}")
    SyncJoin findSyncJoinByJoinId(@Param("joinid")Integer joinid);
}
