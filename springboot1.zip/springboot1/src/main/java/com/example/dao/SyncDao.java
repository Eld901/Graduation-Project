package com.example.dao;

import com.example.entity.Category;
import com.example.entity.Params;
import com.example.entity.Sync;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;
import tk.mybatis.mapper.common.Mapper;

import java.util.List;

@Repository
public interface SyncDao extends Mapper<Sync> {

    @Select("select * from sync where authorid = #{id}")
    List<Sync> findSyncList(Integer id);

    List<Sync> findSyncBySearch(@Param("params")Params params);

    @Select("select * from sync where authorname != #{name}")
    List<Sync> findSyncByName(@Param("name")String name);

    @Select("select * from sync where id = #{id}")
    Sync findSyncByID(@Param("id")Integer id);

    @Select("select * from sync")
    List<Sync> findSync();

    @Select("select * from sync where authorname = #{authorname} and title = #{title}")
    Sync finSyncByCreate(@Param("authorname")String authorname, @Param("title")String title);
}
