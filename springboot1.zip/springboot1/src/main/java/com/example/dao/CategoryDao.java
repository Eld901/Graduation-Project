package com.example.dao;

import com.example.entity.Category;
import com.example.entity.Img;
import com.example.entity.Notice;
import com.example.entity.Params;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;
import tk.mybatis.mapper.common.Mapper;

import java.util.List;

@Repository
public interface CategoryDao extends Mapper<Category> {
    List<Category> findBySearch(@Param("params")Params params);

    @Select("select * from category where userid = #{id}")
    List<Category> findByUserId(@Param("id")Integer id);

    @Select("select * from category where username = #{username}")
    List<Category> findFolderByName(@Param("username")String username);
}
