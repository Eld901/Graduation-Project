package com.example.dao;

import com.example.entity.*;
import org.apache.ibatis.annotations.*;
import org.springframework.stereotype.Repository;
import tk.mybatis.mapper.common.Mapper;

import java.util.List;

@Repository
public interface SyncMessageDao extends Mapper<SyncMessage> {
    @Select("select * from syncmessage where syncid = #{syncid}")
    SyncMessage findSyncMessageById(@Param("syncid")Integer syncid);

    @Insert("INSERT INTO syncmessage (syncid, content) VALUES (#{syncid}, #{content})")
    void addMessageBySyncID(SyncMessage syncMessage);

    @Update("UPDATE syncmessage SET content = #{content} WHERE syncid = #{syncid}")
    void updateMessageBySyncID(SyncMessage syncMessage);

    @Delete("delete from syncmessage where syncid = #{syncid}")
    void deleteSyncMessage(@Param("syncid")Integer id);

    List<SyncMessage> findSyncMessageBySearch(@Param("params")Params params);
}
