package com.example.dao;

import com.example.entity.Category;
import com.example.entity.Doceditor;
import com.example.entity.Params;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;
import tk.mybatis.mapper.common.Mapper;

import java.util.List;

@Repository
public interface DoceditorDao extends Mapper<Doceditor> {
    @Select("select * from doceditor where userid = #{id}")
    List<Doceditor> findByUserId(@Param("id")Integer id);

    @Select("select * from doceditor where id = #{doceditorid}")
    Doceditor findByEditorId(@Param("doceditorid")Integer doceditorId);

    @Delete("delete from doceditor where docid = #{docid}")
    void deleteByDocId(@Param("docid")Integer id);

    List<Doceditor> findDocEditorBySearch(@Param("params")Params params);
}
