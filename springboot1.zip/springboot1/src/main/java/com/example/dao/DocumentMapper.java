package com.example.dao;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

@Mapper
public interface DocumentMapper {
    @Select("SELECT content FROM documentsocket WHERE id = #{id}")
    String getContentById(int id);

    @Update("UPDATE documentsocket SET content = #{content} WHERE id = #{id}")
    void updateContent(int id, String content);
}