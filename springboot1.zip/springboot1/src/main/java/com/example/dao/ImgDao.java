package com.example.dao;

import com.example.entity.Img;
import com.example.entity.Admin;
import com.example.entity.Params;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import tk.mybatis.mapper.common.Mapper;

import java.util.List;

public interface ImgDao extends Mapper<Img> {
    List<Img> findBySearch(@Param("params") Params params);

    @Select("select * from img where userid = #{id}")
    Img selectByUserId(@Param("id")Integer id);

    @Select("select * from img order by id desc")
    List<Img> findTop3();
//
//    @Select("select * from admin where name =#{name} and password =#{password}")
//    Admin findByNameAndPassword(@Param("name")String name, @Param("password")String password);
}
