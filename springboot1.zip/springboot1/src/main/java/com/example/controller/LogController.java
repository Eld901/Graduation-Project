package com.example.controller;

import com.example.common.Result;
import com.example.entity.Log;
import com.example.entity.Notice;
import com.example.entity.Params;
import com.example.service.LogService;
import com.github.pagehelper.PageInfo;
import jakarta.annotation.Resource;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin
@RestController
@RequestMapping("/log")
public class LogController {
    @Resource
    private LogService logService;
    @GetMapping
    public Result findTop() {
        List<Log> list = logService.findTop();
        return Result.success(list);
    }//查询全部
    @GetMapping("/search")
    public Result findBySearch(Params params) {
        PageInfo<Log> info = logService.findBySearch(params);
        return Result.success(info);
    }//联合查询，包含了查询全部
    @DeleteMapping("/{id}")
    public Result delete(@PathVariable Integer id) {
        logService.delete(id);
        return Result.success();
    }
}
