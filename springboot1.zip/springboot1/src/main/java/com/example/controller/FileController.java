package com.example.controller;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.io.FileUtil;
import cn.hutool.core.lang.Dict;
import cn.hutool.core.util.StrUtil;
import com.example.common.Result;
import com.example.entity.Img;
import com.example.entity.Admin;
import com.example.exception.CustomException;
import com.example.service.ImgService;
import jakarta.annotation.Resource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.core.io.UrlResource;

import jakarta.servlet.http.HttpServletResponse;

import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.net.MalformedURLException;
import java.net.URLEncoder;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 *  文件上传接口
 */
@CrossOrigin
@RestController
@RequestMapping("/files")
public class FileController {

    @Resource
    private ImgService imgService;
    private static final Logger log = LoggerFactory.getLogger(AdminController.class);
    // 文件上传存储路径
    private static final String filePath = System.getProperty("user.dir") + "/file/";

    /**
     * 文件上传接口 -- 学习项目
     */
    @PostMapping("/upload")
    public Result upload(MultipartFile file) {
        synchronized (FileController.class) {
            // 获取时间戳 时间戳作为文件名
            String flag = System.currentTimeMillis() + "";
            // 获取文件名
            String fileName = file.getOriginalFilename();
            try {
                // 判断文件路径是否存在，不存在则创建
                if (!FileUtil.isDirectory(filePath)) {
                    FileUtil.mkdir(filePath);
                }
                // 文件存储形式：时间戳-文件名
                FileUtil.writeBytes(file.getBytes(), filePath + flag + "-" + fileName);
                System.out.println(fileName + "--上传成功");
                Thread.sleep(1L);
            } catch (Exception e) {
                System.err.println(fileName + "--文件上传失败");
            }
            return Result.success(flag);
        }
    }

    /**
     * 文件上传接口
     */
    @PostMapping("/uploadfiles")//用户端：普通上传文件接口
    public Result uploadfiles(MultipartFile file) {
        synchronized (FileController.class) {
            String flag = System.currentTimeMillis() + "";// 获取时间戳 时间戳作为文件名
            String fileName = file.getOriginalFilename();// 获取文件名
            Map<String, String> resultData = new HashMap<>();//封装返回
            resultData.put("flag", flag);
            resultData.put("fileName", fileName);
            try {
                if (!FileUtil.isDirectory(filePath)) {
                    FileUtil.mkdir(filePath);
                }// 判断文件路径是否存在，不存在则创建
                FileUtil.writeBytes(file.getBytes(), filePath + flag + "-" + fileName);// 文件存储形式：时间戳-文件名
                System.out.println(fileName + "--上传成功");
                Thread.sleep(1L);
            } catch (Exception e) {
                System.err.println(fileName + "--文件上传失败");
            }
            return Result.success(resultData);
        }
    }
    @PostMapping("/uploadfileslist")//管理端：可用于批量上传文件接口
    public Result uploadFilesList(@RequestParam("file") MultipartFile[] files) {
        List<String> filePaths = new ArrayList<>();
        String uploadDir = System.getProperty("user.dir") + "/file/";
        File uploadPath = new File(uploadDir);// 创建上传目录
        if (!uploadPath.exists()) {
            uploadPath.mkdirs();
        }
        List<Map<String, String>> resultDataList = new ArrayList<>();
        for (MultipartFile file : files) {
            if (file.isEmpty()) {
                continue;
            }// 跳过空文件
            // 生成文件路径
            String fileFlag = System.currentTimeMillis()+ "";
            String fileName = fileFlag + "_" + file.getOriginalFilename();
            String filePath = uploadDir + fileName;//E:\\eld901\\Idea\\springboot1/file/1748770736489_视频.mp4
            Map<String, String> resultData = new HashMap<>();
            resultData.put("fileFlag", fileFlag);
            resultData.put("fileName", fileName);
            resultData.put("filePath", filePath);

            try {
                file.transferTo(new File(filePath));
                filePaths.add(filePath); // 记录文件路径
                resultDataList.add(resultData); // 将文件信息添加到列表中
            } catch (IOException e) {
                e.printStackTrace();
                return Result.error("Failed to upload file: " + e.getMessage());
            }// 保存文件到本地
        }
        return Result.success(resultDataList); // 返回文件路径列表
    }
    /**
     * 文件下载接口
     */
    @GetMapping("/{flag}")
    public void avatarPath(@PathVariable String flag, HttpServletResponse response) {
        if (!FileUtil.isDirectory(filePath)) {
            FileUtil.mkdir(filePath);
        }
        OutputStream os;
        List<String> fileNames = FileUtil.listFileNames(filePath);
        String avatar = fileNames.stream().filter(name -> name.contains(flag)).findAny().orElse("");
        try {
            if (StrUtil.isNotEmpty(avatar)) {
                response.addHeader("Content-Disposition", "attachment;filename=" + URLEncoder.encode(avatar, "UTF-8"));
                response.setContentType("application/octet-stream");
                byte[] bytes = FileUtil.readBytes(filePath + avatar);
                os = response.getOutputStream();
                os.write(bytes);
                os.flush();
                os.close();
            }
        } catch (Exception e) {
            System.out.println("文件下载失败");
        }
    }
    /**
     * 文件删除接口
     */
    @DeleteMapping("/delete/{flag}")
    public Result deleteFile(@PathVariable String flag) {
        synchronized (FileController.class) {
            List<String> fileNames = FileUtil.listFileNames(filePath);
            String avatar = fileNames.stream().filter(name -> name.contains(flag)).findFirst().orElse("");
            String fullPath = filePath + avatar;// 获取文件路径
            if (StrUtil.isNotEmpty(avatar)) {// 检查文件是否存在
                FileUtil.del(fullPath);// 删除文件
                System.out.println("文件删除成功：" + fullPath);
                return Result.success("文件删除成功");
            } else {
                System.err.println("文件不存在：" + fullPath);
                return Result.error("文件不存在");
            }
        }
    }

    /**
     * wang-editor 编辑器文件上传接口
     */
    @PostMapping("/wang/upload")
    public Map<String, Object> wangEditorUpload(MultipartFile file) {
        String flag = System.currentTimeMillis() + "";
        String fileName = file.getOriginalFilename();
        try {
            // 文件存储形式：时间戳-文件名
            FileUtil.writeBytes(file.getBytes(), filePath + flag + "-" + fileName);
            System.out.println(fileName + "--上传成功");
            Thread.sleep(1L);
        } catch (Exception e) {
            System.err.println(fileName + "--文件上传失败");
        }
        Map<String, Object> resMap = new HashMap<>();
        // wangEditor上传图片成功后， 需要返回的参数
        resMap.put("errno", 0);
        resMap.put("data", CollUtil.newArrayList(Dict.create().set("url", "http://localhost:8080/api/files/" + flag)));
        return resMap;
    }

    /**
     * 保存图片 加载图片
     */
    @PostMapping("/save")
    public Result save(@RequestBody Img files) {
        if (files.getId() == null) {
            imgService.add(files);
            log.info("添加图片成功");
        }else {
            imgService.update(files);
            log.info("修改图片成功");
        }
        return Result.success();
    }
    @GetMapping("/find")
    public Result findByUser(Admin user) {
        Img files = imgService.findByUserId(user.getId());
        return Result.success(files);
    }
}
