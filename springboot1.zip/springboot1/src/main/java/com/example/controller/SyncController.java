package com.example.controller;

import cn.hutool.core.util.ObjectUtil;
import com.example.common.Result;
import com.example.entity.*;
import com.example.service.*;
import com.github.pagehelper.PageInfo;
import jakarta.annotation.Resource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin
@RestController
@RequestMapping("/sync")
public class SyncController {
    private static final Logger log = LoggerFactory.getLogger(AdminController.class);
    @Resource
    private SyncService  syncService;
    @Resource
    private SyncJoinService  syncJoinService;
    @Resource
    private SyncUserService  syncUserService;
    @Resource
    private SyncMessageService  syncMessageService;
    /**
     * 创建协同
     */
    @GetMapping("/findSyncList")
    public Result findSyncList(Admin author) {
        List<Sync> syncList = syncService.findSyncList(author.getId());
        return Result.success(syncList);
    }
    @PostMapping("/saveSync")
    public Result saveSync(@RequestBody Sync sync) {
        if (ObjectUtil.isEmpty(sync.getId())) {
            syncService.addSync(sync);
            log.info("添加协同成功");
        } else {
            syncService.updateSyncById(sync);
            log.info("修改协同成功");
        }
        return Result.success();
    }
    @DeleteMapping("/deleteSync/{id}")
    public Result deleteSync(@PathVariable Integer id) {
        syncService.deleteSync(id);
        return Result.success();
    }
    @GetMapping("/searchSync")
    public Result findSyncBySearch(Params params) {
        PageInfo<Sync> info = syncService.findSyncBySearch(params);
        return Result.success(info);
    }
    @GetMapping("/findSyncByName")
    public Result findSyncByName(Admin author) {
        List<Sync> syncList = syncService.findSyncByName(author.getName());
        return Result.success(syncList);
    }
    @GetMapping("/findSyncByID")
    public Result findSyncByID(Sync sync) {
        Sync syncfind = syncService.findSyncByID(sync.getId());
        return Result.success(syncfind);
    }
    @GetMapping("/findSync")
    public Result findSync() {
        List<Sync> syncList = syncService.findSync();
        return Result.success(syncList);
    }
    @GetMapping("/finSyncByCreate")
    public Result finSyncByCreate(Sync sync) {
        Sync syncfind = syncService.finSyncByCreate(sync.getAuthorname(),sync.getTitle());
        log.info("findSyncByCreate---"+syncfind.getTitle());
        return Result.success(syncfind);
    }
    /**
     * 加入协同：用户加入协同，不同用户可加入同一个协同。
     * 不同用户加入相同协同，新增。
     * 相同用户加入不同协同，新增。
     * 相同用户加入相同协同，修改。
     */
    @GetMapping("/findSyncJoinList")
    public Result findSyncJoinList(Admin author) {
        List<SyncJoin> syncJoinList = syncJoinService.findSyncJoinList(author.getId());
        return Result.success(syncJoinList);
    }
    @PostMapping("/saveSyncJoin")
    public Result saveSyncJoin(@RequestBody SyncJoin syncJoin) {
        //修复重复加入(一个人两次加入同一个协同编辑)和管理员编辑时新增问题
        SyncJoin syncJoinFind = syncJoinService.findSyncJoinById(syncJoin.getJoinid(),syncJoin.getUserid());
        if (ObjectUtil.isEmpty(syncJoin.getId())) {
            if(syncJoinFind == null) {
            syncJoinService.addSyncJoin(syncJoin);
            log.info("添加加入协同成功");
            }else {
                syncJoin.setId(syncJoinFind.getId());
                syncJoinService.updateSyncJoinById(syncJoin);
                log.info("修改加入协同成功");
            }
        } else {
            syncJoinService.updateSyncJoinById(syncJoin);
            log.info("修改协同成功");
        }
        return Result.success();
    }
    @DeleteMapping("/deleteSyncJoin/{id}")
    public Result deleteSyncJoin(@PathVariable Integer id) {
        syncJoinService.deleteSyncJoin(id);
        log.info("删除成功");
        return Result.success();
    }
    @GetMapping("/searchSyncJoin")
    public Result findSyncJoinBySearch(Params params) {
        PageInfo<SyncJoin> info = syncJoinService.findSyncJoinBySearch(params);
        return Result.success(info);
    }
    @DeleteMapping("/deleteSyncJoinByID/{id}")
    public Result deleteSyncJoinByID(@PathVariable Integer id) {
        syncJoinService.deleteSyncJoinByID(id);
        return Result.success();
    }
    /**
     * 协同成员
     */
    @GetMapping("/findSyncUserGroup")
    public Result findSyncAllGroup() {
        List<SyncUser> syncAllGroup = syncUserService.findSyncAllGroup();
        return Result.success(syncAllGroup);
    }
    @PostMapping("/saveSyncUser")
    public Result saveSyncUser(@RequestBody SyncUser syncUser) {
        //修复重复加入(一个人两次加入同一个协同编辑)和管理员编辑时新增问题
        SyncUser syncUserFind = syncUserService.findSyncUserById(syncUser.getSyncid(),syncUser.getUserid());
        if (ObjectUtil.isEmpty(syncUser.getId())) {
            if(syncUserFind == null) {
                syncUserService.addSyncUser(syncUser);
                log.info("添加协同成员成功");
            }else {
                syncUser.setId(syncUserFind.getId());
                syncUserService.updateSyncUserById(syncUser);
                log.info("修改协同成员成功");
            }
        } else {
            syncUserService.updateSyncUserById(syncUser);
            log.info("修改协同成功");
        }
        return Result.success();
    }
    @DeleteMapping("/deleteSyncUser/{id}")
    public Result deleteSyncUser(@PathVariable Integer id) {
        syncUserService.deleteSyncUser(id);
        log.info("删除成功");
        return Result.success();
    }
    @GetMapping("/searchSyncUser")
    public Result findSyncUserBySearch(Params params) {
        PageInfo<SyncUser> info = syncUserService.findSyncUserBySearch(params);
        return Result.success(info);
    }
    @GetMapping("/findSyncUserByID")
    public Result findSyncUserByID(SyncUser sync) {
        SyncUser syncuser = syncUserService.findSyncUserByID(sync.getId());
        return Result.success(syncuser);
    }

    @DeleteMapping("/deleteSyncUserByID/{id}")
    public Result deleteSyncUserByID(@PathVariable Integer id) {
        syncUserService.deleteSyncUserByID(id);
        log.info("删除成功");
        return Result.success();
    }

    /**
     * 协同编辑
     */
    @GetMapping("/findSyncMessageById")
    public Result findSyncMessageById(SyncMessage syncMessage) {
        log.info("01---findMessage SyncId: "+syncMessage.getSyncid());
        SyncMessage syncmessage = syncMessageService.findSyncMessageById(syncMessage.getSyncid());
        return Result.success(syncmessage);
    }
    @PostMapping("/saveSyncMessage")
    public Result saveSyncMessage(@RequestBody SyncMessage syncMessage) {
        if(syncMessage.getSyncid()!=null) {
            SyncMessage syncmessage = syncMessageService.findSyncMessageById(syncMessage.getSyncid());
            if(syncmessage != null) {
                syncMessage.setId(syncmessage.getId());
                syncMessageService.updateSyncMessage(syncMessage);
            }else {
                syncMessageService.addSyncMessage(syncMessage);
            }
        }
        return Result.success();
    }
    @DeleteMapping("/deleteSyncMessage/{id}")
    public Result deleteSyncMessage(@PathVariable Integer id) {
        syncMessageService.deleteSyncMessage(id);
        return Result.success();
    }
    @GetMapping("/searchSyncMessage")
    public Result findSyncMessageBySearch(Params params) {
        PageInfo<SyncMessage> info = syncMessageService.findSyncMessageBySearch(params);
        return Result.success(info);
    }


    /**
     * find...ByID方法
     */
    @GetMapping("/findSyncById")
    public Result findSyncById(Sync sync) {
        Sync syncobj = syncService.findSyncById(sync.getId());
        return Result.success(syncobj);
    }
    @GetMapping("/findSyncJoinById")
    public Result findSyncJoinById(SyncJoin syncjoin) {
        SyncJoin syncJoin = syncJoinService.findSyncJoinById(syncjoin.getJoinid(),syncjoin.getUserid());
        return Result.success(syncJoin);
    }
    @GetMapping("/findSyncUserById")
    public Result findSyncUserById(SyncUser syncuser) {
        SyncUser syncUser = syncUserService.findSyncUserById(syncuser.getSyncid(),syncuser.getUserid());
        return Result.success(syncUser);
    }
    @GetMapping("/findSyncUserByjoinID")
    public Result findSyncUserByjoinID(SyncUser syncuser) {
        SyncUser syncUser = syncUserService.findSyncUserByjoinID(syncuser.getSyncjoinid());
        return Result.success(syncUser);
    }
    @GetMapping("/findSyncJoinByJoinId")
    public Result findSyncJoinByJoinId(SyncJoin syncjoin) {
        SyncJoin syncJoin = syncJoinService.findSyncJoinByJoinId(syncjoin.getJoinid());
        return Result.success(syncJoin);
    }
}
