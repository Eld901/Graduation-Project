package com.example.controller;

//import com.example.common.JwtInterceptor;

import cn.hutool.core.util.ObjectUtil;
import com.example.common.AutoLog;
import com.example.common.CaptureConfig;
import com.example.common.Result;
import com.example.entity.Admin;
//import com.example.service.UserService;
import com.example.entity.Category;
import com.example.entity.Login;
import com.example.entity.Params;
import com.example.service.AdminService;
import com.example.service.LoginService;
import com.github.pagehelper.PageInfo;
import com.wf.captcha.utils.CaptchaUtil;
import jakarta.annotation.Resource;
//import org.slf4j.LoggerFactory;
//import org.slf4j.Logger;
import jakarta.servlet.http.HttpServletRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.*;

import java.util.List;
//import java.util.logging.Logger;

@CrossOrigin
@RestController
@RequestMapping("/admin")
public class AdminController {
    private static final Logger log = LoggerFactory.getLogger(AdminController.class);
    @Resource
    private AdminService adminService;

    @PostMapping("/login")
    @AutoLog("登录系统")
    public Result login(@RequestBody Admin admin, @RequestParam String key, HttpServletRequest request) {
        // 判断验证码对不对
        if (!admin.getVerCode().toLowerCase().equals(CaptureConfig.CAPTURE_MAP.get(key))) {
            // 如果不相等，说明验证不通过
            CaptchaUtil.clear(request);
            return Result.error("验证码不正确");
        }
        Admin loginUser = adminService.login(admin);
        CaptureConfig.CAPTURE_MAP.remove(key);
        return Result.success(loginUser);
    }
    @PostMapping("/register")
    public Result register(@RequestBody Admin admin) {
        adminService.add(admin);
        return Result.success();
    }

    @GetMapping
    public Result findAll() {
        List<Admin> list = adminService.findAll();
        return Result.success(list);
    }
    @GetMapping("/search")
    public Result findBySearch(Params params) {
        PageInfo<Admin> info = adminService.findBySearch(params);
        return Result.success(info);
    }
    @GetMapping("/findUserByName")
    public Result findUserByName(Admin userfind) {
        Admin user = adminService.findUserByName(userfind.getName());
        return Result.success(user);
    }
    @GetMapping("/findUserByID")
    public Result findUserByID(Admin userfind) {
        List<Admin> userlist = adminService.findUserByID(userfind.getId());
        return Result.success(userlist);
    }
    @PostMapping
    public Result save(@RequestBody Admin admin) {
        //adminService.add(admin);
        if (admin.getId() == null) {
            adminService.add(admin);
        } else {
            adminService.update(admin);
        }
        return Result.success();
    }
    @DeleteMapping("/{id}")
    public Result delete(@PathVariable Integer id) {
        adminService.delete(id);
        return Result.success();
    }

}
