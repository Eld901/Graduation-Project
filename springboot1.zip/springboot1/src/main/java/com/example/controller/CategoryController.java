package com.example.controller;

import cn.hutool.core.util.ObjectUtil;
import com.example.common.AutoLog;
import com.example.common.Result;
import com.example.entity.*;
import com.example.service.CategoryService;
import com.example.service.NoticeService;
import com.github.pagehelper.PageInfo;
import jakarta.annotation.Resource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.*;

import java.util.List;

import static net.sf.jsqlparser.util.validation.metadata.NamedObject.user;

@CrossOrigin
@RestController
@RequestMapping("/category")
public class CategoryController {
    private static final Logger log = LoggerFactory.getLogger(AdminController.class);
    @Resource
    private NoticeService noticeService;
    @Resource
    private CategoryService categoryService;

    /**
    * 加载分类、新增分类、删除分类
    * */
    @GetMapping("/find")
    public Result findFolder(Admin user) {
        List<Category> files = categoryService.findByUserId(user.getId());
        return Result.success(files);
    }
    @PostMapping("/save")
    public Result saveFolder(@RequestBody Category ca) {
        if (ObjectUtil.isEmpty(ca.getId())) {
            categoryService.add(ca);
            log.info("添加分类成功");
        } else {
            categoryService.update(ca);
            log.info("修改分类成功");
        }
        return Result.success();
    }
    @DeleteMapping("/{id}")
    public Result delFolder(@PathVariable Integer id) {
        categoryService.delete(id);
        return Result.success();
    }
    @GetMapping("/findByName")
    public Result findFolderByName(Admin user) {
        List<Category> files = categoryService.findFolderByName(user.getName());
        return Result.success(files);
    }

    /**
     * 加载文件、新增文件、删除文件
     * */
    @GetMapping("/findfiles")
    public Result findFiles(Admin user) {
        //根据登录用户加载分类及其文件，并返回查询到的分类信息返回给前端
//        log.info("查询user成功 findFolder"+user);
//        log.info("查询id成功 findFolder"+user.getId());
        List<Files> files = categoryService.findfilesByUserId(user.getId());
//        log.info("查询files成功 findFiles"+files);
        return Result.success(files);
    }
    @PostMapping("/files")
    public Result saveFiles(@RequestBody Files files) {
        if (ObjectUtil.isEmpty(files.getId())) {
            categoryService.addFiles(files);
            log.info("添加文件成功");
        } else {
            categoryService.updateFiles(files);
            log.info("修改文件成功");
        }
        return Result.success();
    }
    @DeleteMapping("/delfiles/{id}")
    public Result delFiles(@PathVariable Integer id) {
        categoryService.deletefiles(id);
        return Result.success();
    }


    /**
     * 加载发布、新增发布、删除发布
     * */
    @GetMapping("/finddoc")
    public Result findDoc(Admin user) {
        //根据登录用户加载分类，并返回查询到的分类信息返回给前端
//        log.info("查询user成功 findFolder"+user);
//        log.info("查询id成功 findFolder"+user.getId());
        List<Document> files = categoryService.finddocByUserId(user.getId());
//        log.info("查询files成功 findFolder"+files);
        return Result.success(files);
    }
    @PostMapping("/savedoc")
    public Result saveDoc(@RequestBody Document doc) {
        //通过传递的参数，新增或修改发布
        if (ObjectUtil.isEmpty(doc.getId())) {
            categoryService.adddoc(doc);
            log.info("添加发布成功");
        } else {
            categoryService.updatedoc(doc);
            log.info("修改发布成功");
        }
        return Result.success();
    }
    @DeleteMapping("/deldoc/{id}")
    public Result delDoc(@PathVariable Integer id) {
        categoryService.deletedoc(id);
        return Result.success();
    }
    @GetMapping("/findDocByName")
    public Result findDocByName(Admin user) {
        List<Document> files = categoryService.findDocByName(user.getName());
        return Result.success(files);
    }
    @GetMapping("/findDocById")
    public Result findDocById(Document doc) {
        Document files = categoryService.findDocById(doc.getId());
        return Result.success(files);
    }

    /**
     * 加载富文本、加载富文本编辑区、新增富文本、删除富文本
     * */
    @GetMapping("/findeditor")
    public Result findDocEditor(Admin user) {
        List<Doceditor> files = categoryService.finddoceditorByUserId(user.getId());
//        log.info("查询files成功 findDocEditor"+files);
        return Result.success(files);
    }
    @GetMapping("/findeditorByid")
    public Result findDocEditorById(Doceditor doceditor) {
//        log.info("doceditor---"+doceditor.getId());
        Doceditor editor = categoryService.finddoceditorByEditorId(doceditor.getId());
        log.info("editor---"+editor);
        log.info("editor content---"+editor.getDoceditorContent());
        return Result.success(editor);
    }
    @PostMapping("/adddoceditor")
    public Result addDoceditor(@RequestBody Doceditor doceditor) {
        //通过传递的参数，新增或修改发布
        log.info("doceditor---"+doceditor);
        if (ObjectUtil.isEmpty(doceditor.getId())) {//如果没有ID新增，如果有ID更新
            categoryService.adddoceditor(doceditor);
            log.info("添加编辑器成功");
        } else {//更新也是根据同一个ID更新
            categoryService.updatedoceditor(doceditor);
            log.info("doceditor content"+doceditor.getDoceditorContent());
            log.info("修改编辑器成功");
        }
        return Result.success();
    }
    @DeleteMapping("/deldoceditor/{id}")
    public Result delDoceditor(@PathVariable Integer id) {
        categoryService.deletedoceditor(id);
        return Result.success();
    }

    /**
     * 发布管理：查询、新增、修改、删除
     * */
    @GetMapping("/search")
    public Result findBySearch(Params params) {
        PageInfo<Category> info = categoryService.findBySearch(params);
        return Result.success(info);
    }
    @GetMapping("/searchfiles")
    public Result findFilesBySearch(Params params) {
        PageInfo<Files> info = categoryService.findFilesBySearch(params);
        return Result.success(info);
    }
    @GetMapping("/searchdoc")
    public Result findDocBySearch(Params params) {
        PageInfo<Document> info = categoryService.findDocBySearch(params);
        return Result.success(info);
    }
    @GetMapping("/searchDoceditor")
    public Result findDocEditorBySearch(Params params) {
        PageInfo<Doceditor> info = categoryService.findDocEditorBySearch(params);
        return Result.success(info);
    }

}
