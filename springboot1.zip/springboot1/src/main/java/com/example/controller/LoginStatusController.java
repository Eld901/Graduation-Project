package com.example.controller;

import cn.hutool.core.util.ObjectUtil;
import com.example.common.Result;
import com.example.entity.Admin;
import com.example.entity.Login;
import com.example.service.AdminService;
import com.example.service.LoginService;
import jakarta.annotation.Resource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.*;

@CrossOrigin
@RestController
@RequestMapping("/login")
public class LoginStatusController {
    private static final Logger log = LoggerFactory.getLogger(AdminController.class);
    @Resource
    private AdminService adminService;
    @Resource
    private LoginService loginService;
    @PostMapping("/status")
    public Result loginStatus(@RequestBody Login login) {
        log.info("登录状态:"+login.getStatus());
        Admin user = adminService.findUserByName(login.getUsername());//根据用户名查询用户
        login.setUserid(user.getId());//设置登录对象的用户id
        if (ObjectUtil.isEmpty(login.getId())) {
            loginService.add(login);
            log.info("添加登录对象成功");
        } else {
            loginService.updateById(login);
            log.info("修改登录对象成功");
        }
        return Result.success();
    }//设置登录对象，登录状态
    @DeleteMapping("{id}")
    public Result logoutStatus(@PathVariable Integer id) {//
        loginService.removeLoginByUserId(id);
        return Result.success();
    }//删除登录对象，登出状态
}
