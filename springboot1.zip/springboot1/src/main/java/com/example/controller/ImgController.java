package com.example.controller;

import com.example.common.Result;
import com.example.entity.Img;
import com.example.entity.Log;
import com.example.entity.Params;
import com.example.service.ImgService;
import com.example.service.LogService;
import com.github.pagehelper.PageInfo;
import jakarta.annotation.Resource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin
@RestController
@RequestMapping("/img")
public class ImgController {
    private static final Logger log = LoggerFactory.getLogger(AdminController.class);
    @Resource
    private LogService logService;
    @Resource
    private ImgService imgService;
    /**
     * 用户头像管理：
     * 全部查询 条件查询 删除
     */
    @GetMapping
    public Result findTop() {
        List<Img> list = imgService.findTop();
        return Result.success(list);
    }
    @GetMapping("/search")
    public Result findBySearch(Params params) {
        PageInfo<Img> info = imgService.findBySearch(params);
        return Result.success(info);
    }
    @DeleteMapping("/{id}")
    public Result delete(@PathVariable Integer id) {
        logService.delete(id);
        return Result.success();
    }
}
