package com.example.common;

import com.example.controller.AdminController;
import com.example.service.DocumentService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.socket.CloseStatus;
import org.springframework.web.socket.TextMessage;
import org.springframework.web.socket.WebSocketSession;
import org.springframework.web.socket.handler.TextWebSocketHandler;

import java.io.IOException;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

@Component
public class DocumentWebSocketHandler extends TextWebSocketHandler {
    private static final Logger log = LoggerFactory.getLogger(AdminController.class);
    private static final Map<String, Set<WebSocketSession>> documentSessions = new ConcurrentHashMap<>();
    @Override
    public void afterConnectionEstablished(WebSocketSession session) {
        log.info("-------执行1----------WebSocketSession");
        log.info("01---session.getId: "+session.getId());
        System.out.println("Connection established: " + session.getId());
    }

    @Override
    public void handleTextMessage(WebSocketSession session, TextMessage message) {
        log.info("-------执行2----------WebSocketSession");
        log.info("01---session: "+session);
        log.info("02---message: "+message);//socketId、'update'、socketContent
        try {
            System.out.println("Received message: " + message.getPayload());
            String[] parts = message.getPayload().split(",");
            String sessionId = parts[0];
            String operation = parts[1];
            String content = parts[2];
            log.info("sessionId："+sessionId);//socketId
            log.info("operation："+operation);//'update'
            log.info("content："+content);//socketContent

            if ("update".equals(operation)) {
                documentSessions.getOrDefault(sessionId, new HashSet<>()).forEach(s -> {
                    try {
                        s.sendMessage(new TextMessage(message.getPayload()));
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                });
            }

            documentSessions.computeIfAbsent(sessionId, k -> new HashSet<>()).add(session);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    @Override
    public void afterConnectionClosed(WebSocketSession session, CloseStatus status) {
        log.info("-------执行3----------WebSocketSession");
        log.info("01---session: "+session);
        log.info("02---status: "+status);
        documentSessions.values().forEach(sessions -> sessions.remove(session));
        System.out.println("Connection closed: " + session.getId());
    }
}