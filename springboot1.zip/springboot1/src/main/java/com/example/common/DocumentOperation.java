package com.example.common;
import com.fasterxml.jackson.annotation.JsonProperty;

public class DocumentOperation {
    @JsonProperty("type")
    private String type; // 操作类型，如 "insert" 或 "delete"

    @JsonProperty("content")
    private String content; // 操作内容，如插入的文本

    @JsonProperty("position")
    private int position; // 操作位置，如插入或删除的起始位置

    @JsonProperty("timestamp")
    private long timestamp; // 操作时间戳

    @JsonProperty("documentId")
    private String documentId; // 文档 ID

    // 构造函数
    public DocumentOperation() {
    }

    public DocumentOperation(String type, String content, int position, long timestamp, String documentId) {
        this.type = type;
        this.content = content;
        this.position = position;
        this.timestamp = timestamp;
        this.documentId = documentId;
    }

    // Getter 和 Setter 方法
    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public int getPosition() {
        return position;
    }

    public void setPosition(int position) {
        this.position = position;
    }

    public long getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(long timestamp) {
        this.timestamp = timestamp;
    }

    public String getDocumentId() {
        return documentId;
    }

    public void setDocumentId(String documentId) {
        this.documentId = documentId;
    }

    @Override
    public String toString() {
        return "DocumentOperation{" +
                "type='" + type + '\'' +
                ", content='" + content + '\'' +
                ", position=" + position +
                ", timestamp=" + timestamp +
                ", documentId='" + documentId + '\'' +
                '}';
    }
}