package com.example.common;

import com.example.controller.AdminController;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.socket.CloseStatus;
import org.springframework.web.socket.TextMessage;
import org.springframework.web.socket.WebSocketSession;
import org.springframework.web.socket.handler.TextWebSocketHandler;

import java.io.IOException;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;

@Component
public class DocumentWebSocketHandler2 extends TextWebSocketHandler {
    private static final Logger log = LoggerFactory.getLogger(AdminController.class);
    private static final Map<String, Set<WebSocketSession>> documentSessions = new ConcurrentHashMap<>();
    private static final Map<String, List<DocumentOperation>> documentOperations = new ConcurrentHashMap<>();
    @Override
    public void afterConnectionEstablished(WebSocketSession session) throws Exception {
        String documentId = session.getAttributes().get("documentId").toString();
        documentSessions.putIfAbsent(documentId, ConcurrentHashMap.newKeySet());
        documentSessions.get(documentId).add(session);
    }

    @Override
    public void afterConnectionClosed(WebSocketSession session, CloseStatus status) throws Exception {
        String documentId = session.getAttributes().get("documentId").toString();
        Set<WebSocketSession> sessions = documentSessions.get(documentId);
        if (sessions != null) {
            sessions.remove(session);
        }
    }

    @Override
    public void handleTextMessage(WebSocketSession session, TextMessage message) {
        log.info("1--message: " + message.getPayload());
        DocumentOperation operation = parseOperation(message.getPayload());//将 JSON 格式的操作消息解析为 DocumentOperation 对象
        log.info("2--operation: " + operation);
        DocumentOperation transformedOperation = transformOperation(operation);//对操作进行转换，以解决可能的冲突
        log.info("3--transformedOperation: " + transformedOperation);
        broadcastChange(transformedOperation);//将转换后的操作广播给所有与该文档关联的 WebSocket 会话
    }

    private DocumentOperation parseOperation(String payload) {
        try {
            return new ObjectMapper().readValue(payload, DocumentOperation.class);//使用 ObjectMapper 的 readValue 方法将 JSON 字符串反序列化为 DocumentOperation 对象
        } catch (IOException e) {
            throw new RuntimeException("Failed to parse operation", e);
        }
    }//将 JSON 格式的操作消息解析为 DocumentOperation 对象

    private DocumentOperation transformOperation(DocumentOperation operation) {
        List<DocumentOperation> operations = getOperationsForDocument(operation.getDocumentId());//获取当前文档的所有操作
        operations.sort(Comparator.comparingLong(op -> op.getTimestamp()));//对操作列表按时间戳进行升序排序
//        operations.sort(Comparator.comparingLong(op -> op.getTimestamp()).thenComparingInt(op -> op.getPriority()));

        for (DocumentOperation existingOp : operations) {
            if (existingOp.getTimestamp() < operation.getTimestamp()) {
                if ("insert".equals(existingOp.getType())) {
                    if (operation.getPosition() >= existingOp.getPosition()) {
                        operation.setPosition(operation.getPosition() + existingOp.getContent().length());
                    }//如果当前操作的位置大于或等于现有操作的位置，则将当前操作的位置向后移动，移动的距离为现有操作的内容长度。
                }//并且现有操作是插入操作，则需要调整当前操作的位置。
            }//如果现有操作的时间戳早于当前操作的时间戳，
        }//检查每个现有操作是否与当前操作冲突
        return operation;//返回调整后的位置的操作
    }//对操作进行转换，以解决可能的冲突

    private List<DocumentOperation> getOperationsForDocument(String documentId) {
        documentOperations.putIfAbsent(documentId, new CopyOnWriteArrayList<>());//如果文档 ID 不存在于 documentOperations 中，则初始化一个空的 CopyOnWriteArrayList
        return documentOperations.get(documentId);
    }//获取当前文档的所有操作

    private void broadcastChange(DocumentOperation operation) {
        Set<WebSocketSession> sessions = documentSessions.get(operation.getDocumentId());//从 documentSessions 中获取与文档 ID 关联的 WebSocket 会话集合
        if (sessions != null) {
            sessions.forEach(session -> {
                try {
//                    session.sendMessage(new TextMessage(new ObjectMapper().writeValueAsString(operation)));
                    String json = new ObjectMapper().writeValueAsString(operation);
                    session.sendMessage(new TextMessage(json));
                } catch (IOException e) {
                    e.printStackTrace();
                }
            });
        }//writeValueAsString 方法将 DocumentOperation 对象序列化为 JSON 字符串;session.sendMessage 方法将消息发送给客户端
    }//将转换后的操作广播给所有与该文档关联的 WebSocket 会话

}