package com.example.common;

import com.example.controller.AdminController;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.socket.config.annotation.EnableWebSocket;
import org.springframework.web.socket.config.annotation.WebSocketConfigurer;


import org.springframework.web.socket.config.annotation.WebSocketConfigurer;
import org.springframework.web.socket.config.annotation.WebSocketHandlerRegistry;

@Configuration
@EnableWebSocket
public class WebSocketConfig implements WebSocketConfigurer {
    private static final Logger log = LoggerFactory.getLogger(AdminController.class);
    @Override
    public void registerWebSocketHandlers(WebSocketHandlerRegistry registry) {
        log.info("111---"+registry.toString());
        registry.addHandler(documentWebSocketHandler2(), "/ws/document")
                .setAllowedOrigins("*")
                .addInterceptors(new WebSocketHandshakeInterceptor());
//        registry.addHandler(documentWebSocketHandler(), "/ws/document")
//                .setAllowedOrigins("*");
//                .setAllowedOrigins("http://localhost:8081");
    }

    @Bean
    public DocumentWebSocketHandler2 documentWebSocketHandler2() {
        log.info("333---DocumentWebSocketHandler2---"+new DocumentWebSocketHandler2());
        return new DocumentWebSocketHandler2();
    }
    @Bean
    public DocumentWebSocketHandler documentWebSocketHandler() {
        log.info("222---DocumentWebSocketHandler---"+new DocumentWebSocketHandler());
        return new DocumentWebSocketHandler();
    }

}
