package com.example.entity;

public class Params {
    private Integer PageNum;
    private Integer PageSize;
    private String name;
    private String phone;
    private Integer userId;
    private String username;
    private String content;
    private String author;
    private Integer editorId;

    private String category;
    private String filename;
    private String title;
    private String doctitle;
    private Long doceditorContent;

    private Integer authorid;
    private String authorname;
    private String joinid;
    private String syncid;

    public String getName() {return name;}

    public void setName(String name) {this.name = name;}

    public String getContent() {return content;}

    public void setContent(String content) {this.content = content;}

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public Integer getPageNum() {
        return PageNum;
    }

    public void setPageNum(Integer pageNum) {
        PageNum = pageNum;
    }

    public Integer getPageSize() {
        return PageSize;
    }

    public void setPageSize(Integer pageSize) {
        PageSize = pageSize;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public Integer getEditorId() {return editorId;}

    public void setEditorId(Integer editorId) {this.editorId = editorId;}

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getFilename() {
        return filename;
    }

    public void setFilename(String filename) {
        this.filename = filename;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDoctitle() {
        return doctitle;
    }

    public void setDoctitle(String doctitle) {
        this.doctitle = doctitle;
    }

    public Long getDoceditorContent() {
        return doceditorContent;
    }

    public void setDoceditorContent(Long doceditorContent) {
        this.doceditorContent = doceditorContent;
    }

    public Integer getAuthorid() {
        return authorid;
    }

    public void setAuthorid(Integer authorid) {
        this.authorid = authorid;
    }

    public String getAuthorname() {
        return authorname;
    }

    public void setAuthorname(String authorname) {
        this.authorname = authorname;
    }

    public String getJoinid() {
        return joinid;
    }

    public void setJoinid(String joinid) {
        this.joinid = joinid;
    }

    public String getSyncid() {
        return syncid;
    }

    public void setSyncid(String syncid) {
        this.syncid = syncid;
    }
}
