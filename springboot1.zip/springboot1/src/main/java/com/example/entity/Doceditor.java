package com.example.entity;

import javax.persistence.*;

@Table(name = "doceditor")
public class Doceditor {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    @Column(name = "docid")
    private Integer docid;
    @Column(name = "userid")
    private Integer userid;
    @Column(name = "username")
    private String username;
    @Column(name = "doctitle")
    private String doctitle;
    @Column(name = "doceditorContent")
    private String doceditorContent;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getUserid() {
        return userid;
    }

    public void setUserid(Integer userid) {
        this.userid = userid;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public Integer getDocid() {return docid;}

    public void setDocid(Integer docid) {this.docid = docid;}

    public String getDoceditorContent() {return doceditorContent;}

    public void setDoceditorContent(String doceditorContent) {this.doceditorContent = doceditorContent;}

    public String getDoctitle() {return doctitle;}

    public void setDoctitle(String doctitle) {this.doctitle = doctitle;}


}
