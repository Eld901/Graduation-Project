package com.example.entity;

import javax.persistence.*;

@Table(name = "syncuser")
public class SyncUser {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    @Column(name = "userid")
    private Integer userid;
    @Column(name = "username")
    private String username;
    @Column(name = "syncid")
    private Integer syncid;
    @Column(name = "synctitle")
    private String synctitle;
    @Column(name = "syncjoinid")
    private Integer syncjoinid;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getUserid() {
        return userid;
    }

    public void setUserid(Integer userid) {
        this.userid = userid;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public Integer getSyncid() {
        return syncid;
    }

    public void setSyncid(Integer syncid) {
        this.syncid = syncid;
    }

    public String getSynctitle() {
        return synctitle;
    }

    public void setSynctitle(String synctitle) {
        this.synctitle = synctitle;
    }

    public Integer getSyncjoinid() {
        return syncjoinid;
    }

    public void setSyncjoinid(Integer syncjoinid) {
        this.syncjoinid = syncjoinid;
    }
}
