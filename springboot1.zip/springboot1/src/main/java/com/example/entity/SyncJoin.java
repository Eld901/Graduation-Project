package com.example.entity;

import javax.persistence.*;

@Table(name = "syncjoin")
public class SyncJoin {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    @Column(name = "userid")
    private Integer userid;
    @Column(name = "username")
    private String username;
    @Column(name = "joinid")
    private Integer joinid;
    @Column(name = "jointitle")
    private String jointitle;
    @Column(name = "joinauthorid")
    private Integer joinauthorid;
    @Column(name = "joinauthorname")
    private String joinauthorname;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getUserid() {
        return userid;
    }

    public void setUserid(Integer userid) {
        this.userid = userid;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public Integer getJoinid() {
        return joinid;
    }

    public void setJoinid(Integer joinid) {
        this.joinid = joinid;
    }

    public String getJointitle() {
        return jointitle;
    }

    public void setJointitle(String jointitle) {
        this.jointitle = jointitle;
    }

    public Integer getJoinauthorid() {
        return joinauthorid;
    }

    public void setJoinauthorid(Integer joinauthorid) {
        this.joinauthorid = joinauthorid;
    }

    public String getJoinauthorname() {
        return joinauthorname;
    }

    public void setJoinauthorname(String joinauthorname) {
        this.joinauthorname = joinauthorname;
    }
}
