package com.example.entity;

import javax.persistence.*;

@Table(name = "files")
public class Files {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    @Column(name = "userid")
    private Integer userid;
    @Column(name = "username")
    private String username;
    @Column(name = "categoryid")
    private Integer categoryid;
    @Column(name = "flag")
    private String flag;
    @Column(name = "filename")
    private String filename;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getUserid() {
        return userid;
    }

    public void setUserid(Integer userid) {
        this.userid = userid;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public Integer getCategoryid() {return categoryid;}

    public void setCategoryid(Integer categoryid) {this.categoryid = categoryid;}

    public String getFlag() {return flag;}

    public void setFlag(String flag) {this.flag = flag;}

    public String getFilename() {return filename;}

    public void setFilename(String filename) {this.filename = filename;}
}
