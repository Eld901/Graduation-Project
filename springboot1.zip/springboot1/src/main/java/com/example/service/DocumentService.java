package com.example.service;

import com.example.dao.DocumentMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class DocumentService {
    @Autowired
    private DocumentMapper documentMapper;

    public String getContent(int id) {
        return documentMapper.getContentById(id);
    }

    public void updateContent(int id, String content) {
        documentMapper.updateContent(id, content);
    }
}