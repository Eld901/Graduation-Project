package com.example.service;

import com.example.dao.*;
import com.example.entity.*;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import jakarta.annotation.Resource;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
public class SyncService {

    @Resource
    private SyncDao syncDao;

    public void addSync(Sync sync) {
        syncDao.insertSelective(sync);
    }

    public void updateSyncById(Sync sync) {
        syncDao.updateByPrimaryKeySelective(sync);
    }
    public List<Sync> findSyncList(Integer id) {
        return syncDao.findSyncList(id);
    }

    public Sync findSyncById(Integer id) {
        return syncDao.selectByPrimaryKey(id);
    }

    public void deleteSync(Integer id) {
        syncDao.deleteByPrimaryKey(id);
    }

    public PageInfo<Sync> findSyncBySearch(Params params) {
        PageHelper.startPage(params.getPageNum(), params.getPageSize());
        List<Sync> list = syncDao.findSyncBySearch(params);
        return PageInfo.of(list);
    }

    public List<Sync> findSyncByName(String name) {
         return syncDao.findSyncByName(name);
    }

    public Sync findSyncByID(Integer id) {
         return syncDao.findSyncByID(id);
    }

    public List<Sync> findSync() {
         return syncDao.findSync();
    }


    public Sync finSyncByCreate(String authorname, String title) {
        return syncDao.finSyncByCreate(authorname, title);
    }
}
