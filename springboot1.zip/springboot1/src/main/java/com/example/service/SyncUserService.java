package com.example.service;

import com.example.controller.AdminController;
import com.example.dao.SyncDao;
import com.example.dao.SyncUserDao;
import com.example.entity.Params;
import com.example.entity.Sync;
import com.example.entity.SyncUser;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import jakarta.annotation.Resource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
public class SyncUserService {
    private static final Logger log = LoggerFactory.getLogger(AdminController.class);
    @Resource
    private SyncUserDao syncUserDao;

    public SyncUser findSyncUserById(Integer syncid,Integer userid) {
        return syncUserDao.findSyncUserById(syncid,userid);
    }

    public void addSyncUser(SyncUser syncUser) {
        syncUserDao.insertSelective(syncUser);
    }

    public void updateSyncUserById(SyncUser syncUser) {
        syncUserDao.updateByPrimaryKeySelective(syncUser);
    }

    public List<SyncUser> findSyncUserGroup(Integer syncid) {
        return syncUserDao.findSyncUserGroup(syncid);
    }

    public List<SyncUser> findSyncAllGroup() {
        return syncUserDao.findSyncAllGroup();
    }

    public void deleteSyncUser(Integer id) {
        syncUserDao.deleteSyncUser(id);
    }

    public PageInfo<SyncUser> findSyncUserBySearch(Params params) {
        PageHelper.startPage(params.getPageNum(), params.getPageSize());
        List<SyncUser> list = syncUserDao.findSyncUserBySearch(params);
        return PageInfo.of(list);
    }

    public SyncUser findSyncUserByjoinID(Integer syncjoinid) {
        return syncUserDao.findSyncUserByjoinID(syncjoinid);
    }

    public SyncUser findSyncUserByID(Integer id) {
         return syncUserDao.findSyncUserByID(id);
    }

    public void deleteSyncUserByID(Integer id) {
        syncUserDao.deleteByPrimaryKey(id);
    }
}
