package com.example.service;

import com.example.dao.*;
import com.example.entity.*;
import jakarta.annotation.Resource;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
public class LoginService {

    @Resource
    private LoginDao  loginDao;

    public void add(Login login) {
        loginDao.insertSelective(login);
    }

    public void updateById(Login login) {
        loginDao.updateByPrimaryKeySelective(login);
    }

    public void removeLoginByUserId(Integer id) {
        loginDao.removeLoginByUserId(id);
    }
}
