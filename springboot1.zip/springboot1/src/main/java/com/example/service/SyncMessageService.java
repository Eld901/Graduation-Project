package com.example.service;

import com.example.dao.*;
import com.example.entity.*;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import jakarta.annotation.Resource;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
public class SyncMessageService {

    @Resource
    private SyncMessageDao syncMessageDao;

    public SyncMessage findSyncMessageById(Integer syncid) {
        return syncMessageDao.findSyncMessageById(syncid);
    }

    public void addSyncMessage(SyncMessage syncMessage) {
        syncMessageDao.insertSelective(syncMessage);
    }

    public void updateSyncMessage(SyncMessage syncMessage) {
        syncMessageDao.updateByPrimaryKeySelective(syncMessage);
    }

    public void deleteSyncMessage(Integer id) {
        syncMessageDao.deleteSyncMessage(id);
    }

    public PageInfo<SyncMessage> findSyncMessageBySearch(Params params) {
        PageHelper.startPage(params.getPageNum(), params.getPageSize());
        List<SyncMessage> list = syncMessageDao.findSyncMessageBySearch(params);
        return PageInfo.of(list);
    }
}
