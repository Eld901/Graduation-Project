package com.example.service;

import com.example.controller.AdminController;
import com.example.entity.Img;
import com.example.dao.ImgDao;
import com.example.entity.Admin;
import com.example.entity.Log;
import com.example.entity.Params;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import jakarta.annotation.Resource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ImgService {
    private static final Logger log = LoggerFactory.getLogger(AdminController.class);
    @Resource
    private ImgDao imgDao;
    public void add(Img img) {
        imgDao.insertSelective(img);
    }

    public void update(Img img) {
        imgDao.updateByPrimaryKeySelective(img);
    }

    public Img findByUserId(Integer id) {
        return imgDao.selectByUserId(id);
    }

    public PageInfo<Img> findBySearch(Params params) {
        // 开启分页查询
        PageHelper.startPage(params.getPageNum(), params.getPageSize());
        // 接下来的查询会自动按照当前开启的分页设置来查询
        List<Img> list = imgDao.findBySearch(params);
        return PageInfo.of(list);
    }

    public List<Img> findTop() {
        return imgDao.findTop3();
    }
}
