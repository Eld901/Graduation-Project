package com.example.service;

import com.example.dao.SyncDao;
import com.example.dao.SyncJoinDao;
import com.example.entity.Params;
import com.example.entity.Sync;
import com.example.entity.SyncJoin;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import jakarta.annotation.Resource;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
public class SyncJoinService {

    @Resource
    private SyncJoinDao syncJoinDao;
    public void addSyncJoin(SyncJoin syncJoin) {
        syncJoinDao.insertSelective(syncJoin);

    }
    public void updateSyncJoinById(SyncJoin syncJoin) {
        syncJoinDao.updateByPrimaryKeySelective(syncJoin);
    }

    public SyncJoin findSyncJoinById(Integer id,Integer userid) {
        return syncJoinDao.findSyncJoinById(id,userid);
    }

    public List<SyncJoin> findSyncJoinList(Integer id) {
        return syncJoinDao.findSyncJoinList(id);
    }

    public void deleteSyncJoin(Integer id) {
        syncJoinDao.deleteSyncJoin(id);
    }

    public PageInfo<SyncJoin> findSyncJoinBySearch(Params params) {
        PageHelper.startPage(params.getPageNum(), params.getPageSize());
        List<SyncJoin> list = syncJoinDao.findSyncJoinBySearch(params);
        return PageInfo.of(list);
    }

    public void deleteSyncJoinByID(Integer id) {
        syncJoinDao.deleteByPrimaryKey(id);
    }

    public SyncJoin findSyncJoinByJoinId(Integer joinid) {
        return syncJoinDao.findSyncJoinByJoinId(joinid);
    }
}
