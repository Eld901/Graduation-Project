package com.example.service;

import cn.hutool.core.date.DateUtil;
import com.example.controller.AdminController;
import com.example.dao.*;
import com.example.entity.*;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import jakarta.annotation.Resource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;


@Service
public class CategoryService {
    private static final Logger log = LoggerFactory.getLogger(AdminController.class);

    @Resource
    private CategoryDao categoryDao;
    @Resource
    private FilesDao filesDao;
    @Resource
    private DocDao docDao;
    @Resource
    private DoceditorDao doceditorDao;
    /**
     * 加载分类、新增分类、删除分类
     * */
    public void add(Category ca) {
        categoryDao.insertSelective(ca);
    }
    public void update(Category ca) {
        categoryDao.updateByPrimaryKeySelective(ca);
    }
    public List<Category> findByUserId(Integer id) {
        return categoryDao.findByUserId(id);
    }
    public void delete(Integer id) {
        List<Document> doclist = docDao.findDocByCategoryId(id);
        for (Document doc : doclist) {
            doceditorDao.deleteByDocId(doc.getId());
        }
        filesDao.deleteByCategoryId(id);
        docDao.deleteByCategoryId(id);
        categoryDao.deleteByPrimaryKey(id);
    }

    public List<Category> findFolderByName(String username) {
         return categoryDao.findFolderByName(username);
    }

    /**
     * 加载文件、新增文件、删除文件
     * */
    public void addFiles(Files files) {
        filesDao.insertSelective(files);
    }
    public void updateFiles(Files files) {
        filesDao.updateByPrimaryKeySelective(files);
    }
    public List<Files> findfilesByUserId(Integer id) {
        return filesDao.findByUserId(id);
    }
    public void deletefiles(Integer id) {
        filesDao.deleteByPrimaryKey(id);
    }


    /**
     * 加载发布、新增发布、删除发布
     * */
    public void adddoc(Document doc) {
        docDao.insertSelective(doc);
    }
    public void updatedoc(Document doc) {
        docDao.updateByPrimaryKeySelective(doc);
    }
    public List<Document> finddocByUserId(Integer id) {
        return docDao.findByUserId(id);
    }
    public void deletedoc(Integer id) {
        doceditorDao.deleteByDocId(id);
        docDao.deleteByPrimaryKey(id);
    }
    public List<Document> findDocByName(String name) {
        return docDao.findDocByName(name);
    }
    public Document findDocById(Integer id) {
        return docDao.findDocById(id);
    }
    /**
     * 加载富文本、加载富文本编辑区、新增富文本、删除富文本
     * */
    public List<Doceditor> finddoceditorByUserId(Integer id) {
        return doceditorDao.findByUserId(id);
    }
    public void adddoceditor(Doceditor doceditor) {
        doceditorDao.insertSelective(doceditor);
    }
    public void updatedoceditor(Doceditor doceditor) {
        doceditorDao.updateByPrimaryKeySelective(doceditor);
    }
    public void deletedoceditor(Integer id) {
        doceditorDao.deleteByPrimaryKey(id);
    }
    public Doceditor finddoceditorByEditorId(Integer doceditorId) {
        return doceditorDao.findByEditorId(doceditorId);
    }


    /**
     * 发布管理：查询、新增、修改、删除
     * */
    public PageInfo<Category> findBySearch(Params params) {
        PageHelper.startPage(params.getPageNum(), params.getPageSize());
        List<Category> list = categoryDao.findBySearch(params);
        return PageInfo.of(list);
    }
    public PageInfo<Files> findFilesBySearch(Params params) {
        PageHelper.startPage(params.getPageNum(), params.getPageSize());
        List<Files> list = filesDao.findFilesBySearch(params);
        return PageInfo.of(list);
    }
    public PageInfo<Document> findDocBySearch(Params params) {
        PageHelper.startPage(params.getPageNum(), params.getPageSize());
        List<Document> list = docDao.findDocBySearch(params);
        return PageInfo.of(list);
    }
    public PageInfo<Doceditor> findDocEditorBySearch(Params params) {
        PageHelper.startPage(params.getPageNum(), params.getPageSize());
        List<Doceditor> list = doceditorDao.findDocEditorBySearch(params);
        return PageInfo.of(list);
    }

}
