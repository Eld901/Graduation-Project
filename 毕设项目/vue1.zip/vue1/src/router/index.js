import Vue from 'vue'
import VueRouter from 'vue-router'
import HomeNoticeView from '../views/HomeNoticeView.vue'
import LoginView from "@/views/LoginView.vue";
import Layout from "@/views/Layout.vue";
import RegisterView from "@/views/RegisterView.vue";
import BookView from "@/views/BookView.vue";
import TypeView from "@/views/TypeView.vue";
import AuditView from "@/views/AuditView.vue";
import HotelView from "@/views/HotelView.vue";
import ReserveView from "@/views/ReserveView.vue";
import LogView from "@/views/LogView.vue";
import NoticeView from "@/views/NoticeView.vue";
import HomeView from "@/views/HomeView.vue";
import PublishView from "@/views/PublishView.vue";
import HomeMeView from "@/views/HomeMeView.vue";
import TestView from "@/views/TestView.vue";
import TestView2 from "@/views/TestView2.vue";
import HomeLogView from "@/views/HomeLogView.vue";
import ImgView from "@/views/ImgView.vue";
import aPublishView from "@/views/aPublishView.vue";
import SyncView from "@/views/SyncView.vue";
import aSyncView from "@/views/aSyncView.vue";
import aPublishView2 from "@/views/aPublishView2.vue";
import aPublishView3 from "@/views/aPublishView3.vue";
import aPublishView4 from "@/views/aPublishView4.vue";
import aSyncView2 from "@/views/aSyncView2.vue";
import aSyncView3 from "@/views/aSyncView3.vue";
import aSyncView4 from "@/views/aSyncView4.vue";

Vue.use(VueRouter)
const routes = [
  {
    path: '/login',
    name: 'Login',
    component: LoginView
  },//登录页面
  {
    path: '/register',
    name: 'Register',
    component: RegisterView
  },//注册页面
  {
    path: '/',
    name: 'Layout',
    component: Layout,
    // redirect: '/home',
    children: [ // 子路由
      {
        path: '',
        name: 'new',
        component: HomeView
      },// 首页展示 HomeView
      {
        path: 'homenotice',
        name: 'homenotice',
        component: HomeNoticeView
      },// 系统公告 HomeNoticeView
      {
        path: 'homelog',
        name: 'homelog',
        component: HomeLogView
      },// 系统日志 HomeLogView
      {
        path: 'homeMe',
        name: 'homeMe',
        component: HomeMeView
      },// 个人中心 HomeMeView
      {
        path: 'publish',
        name: 'publish',
        component: PublishView
      },// 新增发布 PublishView
      {
        path: 'sync',
        name: 'sync',
        component: SyncView
      },// 协同页面 SyncView
      {
        path: 'test',
        name: 'test',
        component: TestView
      },//测试页面 TestView
      {
        path: 'test2',
        name: 'test2',
        component: TestView2
      },//测试页面 TestView2

      {
        path: 'admin',
        name: 'admin',
        component: () => import('../views/AdminView.vue')
      },// 用户管理 AdminView
      {
        path: 'img',
        name: 'img',
        component: ImgView
      },// 头像管理 ImgView
      {
        path: 'notice',
        name: 'notice',
        component: NoticeView
      },// 公告管理 NoticeView
      {
        path: 'log',
        name: 'log',
        component: LogView
      },// 日志管理 LogView
      {
        path: 'apublish',
        name: 'apublish',
        component: aPublishView
      },// 发布管理 aPublishView 发布分类管理--->自定义分类
      {
        path: 'apublish2',
        name: 'apublish2',
        component: aPublishView2
      },// 发布管理 aPublishView2 发布文件管理--->自定义上传
      {
        path: 'apublish3',
        name: 'apublish3',
        component: aPublishView3
      },// 发布管理 aPublishView3 发布文本管理--->富文本发布
      {
        path: 'apublish4',
        name: 'apublish4',
        component: aPublishView4
      },// 发布管理 aPublishView4 发布编辑管理--->富文本编辑
      {
        path: 'async',
        name: 'async',
        component: aSyncView
      },// 协同管理 aSyncView 协同创建管理--->
      {
        path: 'async2',
        name: 'async2',
        component: aSyncView2
      },// 协同管理 aSyncView 协同加入管理--->
      {
        path: 'async3',
        name: 'async3',
        component: aSyncView3
      },// 协同管理 aSyncView 协同成员管理--->
      {
        path: 'async4',
        name: 'async4',
        component: aSyncView4
      },// 协同管理 aSyncView 协同编辑管理--->
      {
        path: 'test2',
        name: 'test2',
        component: TestView2
      },
      {
        path: 'book',
        name: 'book',
        component: BookView
      },
      {
        path: 'type',
        name: 'type',
        component: TypeView
      },
      {
        path: 'audit',
        name: 'audit',
        component: AuditView
      },
      {
        path: 'hotel',
        name: 'hotel',
        component: HotelView
      },
      {
        path: 'reserve',
        name: 'reserve',
        component: ReserveView
      },
    ]
  },//主体页面
]
const router = new VueRouter({
  // mode: 'history',
  mode: 'hash',
  base: process.env.BASE_URL,
  routes
})
// 路由守卫
router.beforeEach((to ,from, next) => {
  const user = localStorage.getItem("user");
  if (!user && to.path !== '/login' && to.path !== '/register') {
    return next("/login");
  }
  next();
})
export default router
