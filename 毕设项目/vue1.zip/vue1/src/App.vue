<template>
  <div id="app">
    <router-view/>
  </div>
</template>
<style>
.el-dropdown-link {
  cursor: pointer;
}
</style>

<script>
export default {
  name: "Layout",
  data() {
    return {
      // user: {
      //   name: ''
      // }
      user: localStorage.getItem("user") ? JSON.parse(localStorage.getItem("user")) : {}

    }
  },
  created() {
    this.user = JSON.parse(localStorage.getItem('user'))
  },
  methods: {
    logout() {
      localStorage.removeItem('user')
      this.user = {}
      this.$router.push('/login')
    }
  }
}
</script>