<template>
  <div class="admin-container">
    <div class="headsearch">
      <el-input v-model="params.syncid" style="width: 200px; margin-right: 10px" placeholder="请输入协同号"></el-input>
      <el-input v-model="params.username" style="width: 200px; margin-right: 10px" placeholder="请输入协同的成员名"></el-input>
      <el-button type="warning" @click="findBySearch()">查询</el-button>
      <el-button type="warning" @click="reset()">清空</el-button>
      <el-button type="primary" @click="add()">新增</el-button>
    </div>
    <div class="midtable">
      <el-table :data="tableData" style="width: 100%; margin: 15px 0px">
<!--        <el-table-column prop="id" label="成员对象ID"></el-table-column>-->
        <el-table-column prop="syncid" label="协同ID"></el-table-column>
        <el-table-column prop="synctitle" label="协同标题"></el-table-column>
        <el-table-column prop="userid" label="成员ID"></el-table-column>
        <el-table-column prop="username" label="成员名"></el-table-column>
        <el-table-column label="操作">
          <template slot-scope="scope">
            <el-button type="primary" @click="edit(scope.row)">编辑</el-button>
            <el-popconfirm title="确定删除吗？" @confirm="del(scope.row.id)">
              <el-button slot="reference" type="danger" style="margin-left: 5px">删除</el-button>
            </el-popconfirm>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <div class="footpage">
      <el-pagination
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
          :current-page="params.pageNum"
          :page-sizes="[5, 10, 15, 20]"
          :page-size="params.pageSize"
          layout=" total, sizes, prev, pager, next"
          :total="total">
      </el-pagination>
    </div>
    <div class="coverdialog">
      <el-dialog :title="sync_title" :visible.sync="dialogFormVisible" width="30%">
        <el-form :model="form">
          <el-form-item label="协同" label-width="15%">
            <el-select v-model="form.syncid" placeholder="请选择协同号" @change="findUserList" style="width: 90%">
              <el-option :label="isync.id" :value="isync.id"
                         v-for="(isync,indexsync) in synclist" :key="indexsync">
                <span style="float: left;margin-right: 25px">{{ isync.id }}</span>
                <span style="color: #8492a6; font-size: 13px;margin-right: 5px">author:{{isync.authorname}}</span>
                <span style="float: right; color: #8492a6; font-size: 13px;margin-right: 5px">title:{{ isync.title }}</span>
              </el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="用户" label-width="15%">
            <el-select v-model="form.username" placeholder="请选择加入的成员名" style="width: 90%">
              <el-option :label="iuser.name" :value="iuser.name"
                         v-for="(iuser,indexuser) in userlist" :key="indexuser">
                <span>{{ iuser.name }}</span>
                <span style="float: right; color: #8492a6; font-size: 13px;margin-right: 5px">userID:{{ iuser.id }}</span>
              </el-option>
            </el-select>
          </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer">
          <el-button @click="dialogFormVisible = false">取 消</el-button>
          <el-button type="primary" @click="submit()">确 定</el-button>
        </div>
      </el-dialog>
    </div>
  </div>
</template>
<style scoped>

</style>
<script>
import request from "@/utils/request";
export default {
  //name: "AdminView",
  data() {
    return {
      user: localStorage.getItem("user") ? JSON.parse(localStorage.getItem("user")) : {},
      params:{
        pageNum: 1,
        pageSize: 5
      },   //前端封装参数：用于传递分页参数或其他参数
      total: 0,                 //分页数据：共几条
      dialogFormVisible: false, //开启/关闭对话框

      synclist: {},             //协同列表：用于新增时选择协同
      userlist: {},             //用户列表：用于新增时选择用户

      tableData: {},            //表格数据
      form: {},                 //表单数据
      formin: {},               //提交对象：提交新增/修改分类数据
      forminuser: {},               //提交对象：提交新增/修改分类数据
      userfind: {},             //用户对象：通过用户名查找用户对象数据

      flag_addORedit: '',       //新增或编辑 标识：add/edit (新增时id为空或undefined)
      sync_title: '',
    }
  },
  created() {
    this.findBySearch();
    this.findSyncList();
    this.user = JSON.parse(localStorage.getItem('user'))
  },
  methods: {
    handleSizeChange(pageSize) {
      this.params.pageSize = pageSize;
      this.findBySearch();
    },    //点击切换分页条数
    handleCurrentChange(pageNum) {
      this.params.pageNum = pageNum;
      this.findBySearch();
    },  //点击跳转当前页码
    reset(){
      this.params = {
        pageNum: 1,
        pageSize: 5,
        name: '',
        phone: ''
      }
      this.findBySearch();
    },                        //点击清空按钮：重置查询条件

    // syncuser： [id syncid synctitle userid username]
    findBySearch(){
      request.get("/sync/searchSyncUser",{params:this.params})
          .then(res =>{
        if(res.code === '0'){
          this.tableData = res.data.list;
          this.total = res.data.total;
        }else{
          this.$message.error({message: res.msg, duration: 800});
          // this.$message({message: res.msg, type: 'error'});
        }
      })
    },                 //加载全部协同成员列表
    findSyncList() {
      request.get("/sync/findSync").then(res =>{
        if(res.code === '0'){
          this.synclist = res.data;
          console.log('synclist-----------',this.synclist)
        }else{
          this.$message.error({message: res.msg, duration: 800});
        }
      })
    },                //加载协同选项：用于在下拉列表选择协同号
    async findUserList(syncid){
      await this.findSyncByID(syncid);
      await this.findUserByID(this.sync.authorid);
    },     //加载用户选项：用于选择当前协同的加入成员
    async findSyncByID(syncid) {
      this.sync = {};
      this.sync.id = syncid;
      await request.get("/sync/findSyncByID",{params:this.sync}).then(res =>{
        if(res.code === '0'){
          this.sync = res.data;
          console.log('authorid-------------',this.sync.authorid)
        }else{
          this.$message.error({message: res.msg, duration: 800});
        }
      })
    },    //获取协同对象：通过表单协同号查询协同对象，用于获取当前协同对应的用户ID
    async findUserByID(userid) {
      this.userfind = {};
      this.userfind.id = userid;
      await request.get("/admin/findUserByID",{params:this.userfind}).then(res =>{
        if(res.code === '0'){
          this.userlist = res.data;
        }else{
          this.$message.error({message: res.msg, duration: 800});
        }
      })
    },    //获取用户对象：通过用户ID查询用户对象，用于选择当前协同的加入成员

    add(){
      this.form = {};
      this.sync_title = '新增协同成员';
      this.flag_addORedit = 'add';           //新增标识：add
      this.dialogFormVisible = true;
    },                             //点击新增按钮：打开新增创建协同对话框，清空已有内容
    edit(obj) {
      this.form = obj;
      this.formin.id = obj.id;              //用于update操作，根据ID修改数据库表当前记录
      // this.sync_title = obj.synctitle;
      this.sync_title = '协同ID：'+obj.syncid;
      this.findUserList(obj.syncid);        //点击编辑按钮时，即加载协同成员下拉列表选项
      this.flag_addORedit = 'edit';         //编辑标识：edit
      this.dialogFormVisible = true;
    },                        //点击编辑按钮：打开修改创建协同对话框，传递已有内容

    async submit(){
      if(this.flag_addORedit == 'add'){
        this.formin.id = '';
      }
      await this.findUserByName(this.form.username);      //通过用户名获取用户对象：通过表单用户名查询用户对象，用于获取用户ID
      this.formin.userid = this.userfind.id;              //userid
      this.formin.username = this.form.username;          //username
      this.formin.joinid = this.form.syncid;              //joinid
      await this.findSyncByID(this.form.syncid);          //通过协同号获取协同对象：通过表单协同号查询协同对象，用于获取协同字段属性
      this.formin.joinauthorname = this.sync.authorname;  //joinauthorname
      this.formin.joinauthorid = this.sync.authorid;      //joinauthorid
      this.formin.jointitle = this.sync.title;            //jointitle
      await request.post("/sync/saveSyncJoin", this.formin).then(res => {
        if (res.code === '0') {
        } else {
          this.$message.error({message: res.msg, duration: 800});
        }
      })

      await this.findSyncJoinById(this.form.syncid,this.formin.userid);
      await this.findSyncUserByjoinID(this.syncjoin.id);
      if(this.flag_addORedit == 'add'){
        this.forminuser.id = '';
      }else if(this.flag_addORedit == 'edit') {
        this.forminuser.id = this.syncuser.id;
      }

      this.forminuser.userid = this.userfind.id;              //userid
      this.forminuser.username = this.form.username;          //username
      this.forminuser.syncid = this.form.syncid;              //syncid
      this.forminuser.synctitle = this.sync.title;            //synctitle
      this.forminuser.syncjoinid = this.syncjoin.id;          //syncjoinid
      await request.post("/sync/saveSyncUser", this.forminuser).then(res => {
        if (res.code === '0') {
          this.$message.success({message: '操作成功', duration: 800});
          this.dialogFormVisible = false;
          this.findBySearch();
        } else {
          this.$message.error({message: res.msg, duration: 800});
        }
      })
    },                    //点击提交按钮：通过用户名、分类名向数据库创建协同表新增一条记录
    async findUserByName(username){
      this.userfind = {};
      this.userfind.name = username;
      await request.get("/admin/findUserByName",{params:this.userfind}).then(res =>{
        if (res.code === '0') {
          this.userfind = res.data;
        }else {
          this.$message.error({message: res.msg, duration: 800});
        }
      })
    },    //通过用户名获取用户对象：通过表单用户名查询用户对象，用于获取用户ID
    async findSyncJoinById(joinid,userid) {
      this.syncjoin = {};             //初始化清空
      this.syncjoin.joinid = joinid;  //joinid
      this.syncjoin.userid = userid;  //userid
      await request.get("/sync/findSyncJoinById", {params: this.syncjoin}).then(res => {
        if (res.code === '0') {
          this.syncjoin = res.data;
        } else {
          this.$message.error({message: res.msg, duration: 800});
        }
      })
    },        //获取加入协同对象：根据协同号、用户ID查询加入协同对象，用于获取加入协同属性
    async findSyncUserByjoinID(syncjoinid) {
      this.syncuser = {};
      this.syncuser.syncjoinid = syncjoinid;
      await request.get("/sync/findSyncUserByjoinID",{params:this.syncuser}).then(res =>{
        if(res.code === '0'){
          this.syncuser = res.data;
        }else{
          this.$message.error({message: res.msg, duration: 800});
        }
      })
    },       //获取协同成员对象：通过表单协同号查询协同成员对象，用于获取协同成员字段属性
    async findSyncUserByID(syncuserid) {
      this.syncuser = {};
      this.syncuser.id = syncuserid;
      await request.get("/sync/findSyncUserByID",{params:this.syncuser}).then(res =>{
        if(res.code === '0'){
          this.syncuser = res.data;
        }else{
          this.$message.error({message: res.msg, duration: 800});
        }
      })
    },

    async del(id) {
      request.delete("/sync/deleteSyncUserByID/" + id).then(res => {
        if (res.code === '0') {
          this.$message.success({message: '删除成功', duration: 800});
          this.findBySearch();
        } else {
          this.$message.error({message: res.msg, duration: 800});
        }
      })
      await this.findSyncUserByID(id);
      id =  this.syncuser.syncjoinid;
      await request.delete("/sync/deleteSyncJoinByID/" + id).then(res => {
        if (res.code === '0') {
        } else {
          this.$message.error({message: res.msg, duration: 800});
        }
      })
    },                                //点击删除按钮：删除数据库中当前 加入协同表 和 协同成员表 记录
  }
}
</script>