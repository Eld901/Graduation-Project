<template>
  <div class="admin-container">
    <div>
      <div class="headsearch">
        <el-input v-model="params.username" style="width: 200px; margin-right: 10px" placeholder="请输入用户名"></el-input>
        <el-input v-model="params.filename" style="width: 200px; margin-right: 10px" placeholder="请输入文件名"></el-input>
        <el-button type="warning" @click="findBySearch()">查询</el-button>
        <el-button type="warning" @click="reset()">清空</el-button>
        <el-button type="primary" @click="add()">新增</el-button>
      </div>
      <div class="midtable">
        <el-table :data="tableData" style="width: 100%; margin: 15px 0px">
<!--          <el-table-column prop="id" label="上传ID" width="180"></el-table-column>-->
          <el-table-column prop="categoryid" label="分类ID"></el-table-column>
          <el-table-column prop="userid" label="用户ID"></el-table-column>
          <el-table-column prop="username" label="用户名"></el-table-column>
          <el-table-column prop="flag" label="上传时间戳"></el-table-column>
          <el-table-column prop="filename" label="上传文件名"></el-table-column>
          <el-table-column label="操作">
            <template slot-scope="scope">
              <el-button type="primary" @click="edit(scope.row)">编辑</el-button>
              <el-popconfirm title="确定删除吗？" @confirm="del(scope.row.id)">
                <el-button slot="reference" type="danger" style="margin-left: 5px">删除</el-button>
              </el-popconfirm>
            </template>
          </el-table-column>
        </el-table>
      </div>
      <div class="footpage">
        <el-pagination
            @size-change="handleSizeChange"
            @current-change="handleCurrentChange"
            :current-page="params.pageNum"
            :page-sizes="[5, 10, 15, 20]"
            :page-size="params.pageSize"
            layout=" total, sizes, prev, pager, next"
            :total="total">
        </el-pagination>
      </div>
      <div class="coverdialog">
        <el-dialog title="上传文件" :visible.sync="dialogFormVisible">
          <el-form :model="form">
            <el-form-item label="用户" label-width="15%">
              <el-select v-model="form.username" placeholder="请选择用户" @change="findCategoryList" style="width: 90%">
                <el-option :label="iuser.name" :value="iuser.name"
                           v-for="(iuser,indexuser) in userlist" :key="indexuser">
                  <span>{{ iuser.name }}</span>
                  <span style="float: right; color: #8492a6; font-size: 13px;margin-right: 5px">userID:{{ iuser.id }}</span>
                </el-option>
              </el-select>
            </el-form-item>
            <el-form-item label="分类ID" label-width="15%">
              <el-select v-model="form.categoryid" placeholder="请选择分类" style="width: 90%">
                <el-option :label="icate.id"  :value="icate.id"
                           v-for="(icate,indexcate) in categorylist" :key="indexcate">
                  <span>{{ icate.id }}</span>
                  <span style="float: right; color: #8492a6; font-size: 13px;margin-right: 5px">category:{{ icate.category }}</span>
                </el-option>
              </el-select>
            </el-form-item>
            <el-form-item label="文件" label-width="15%">
              <template>
                <div v-if="file_txtview">{{file_title}}</div>
                <img v-if="file_type === 'image'" :src="file_url" alt="" style="width: 500px"/>
                <audio controls v-if="file_type === 'audio'">
                  <source :src="file_url" type="audio/mpeg">
                  Your browser does not support the audio element.
                </audio>
                <video controls v-if="file_type === 'video'" style="width: 500px">
                  <source :src="file_url" type="video/mp4">
                  Your browser does not support the video tag.
                </video>
              </template>
              <div style="display: flex;flex-direction: row;justify-content: center">
                <el-upload ref="upload"
                           :auto-upload="false"
                           :on-change="selectFiles"
                           :file-list="fileList"
                           :show-file-list="false"
                           :http-request="false">
                  <el-button size="small" type="primary">选择文件</el-button>
                </el-upload>
                <div>
                  <el-button size="small" type="success" @click="downFile(file_download)" v-if="file_btnview">下载文件</el-button>
                </div>
              </div>
            </el-form-item>
          </el-form>
          <div slot="footer" class="dialog-footer">
            <el-button @click="dialogFormVisible = false">取 消</el-button>
            <el-button type="primary" @click="submit()">确 定</el-button>
          </div>
        </el-dialog>
      </div>
    </div>
  </div>
</template>
<style scoped>

</style>
<script>
import request from "@/utils/request";
import axios from "axios";
export default {
  //name: "AdminView",
  data() {
    return {
      user: localStorage.getItem("user") ? JSON.parse(localStorage.getItem("user")) : {},
      params:{
        pageNum: 1,
        pageSize: 5
      },   //前端封装参数：用于传递分页参数或其他参数
      total: 0,                 //分页数据：共几条
      dialogFormVisible: false, //开启/关闭对话框

      userlist: {},             //用户列表：用于新增时选择用户
      categorylist: {},         //分类列表：用于新增时选择分类

      tableData: {},            //表格展示数据
      form: {},                 //表单提交数据
      formin: {},               //提交对象：提交新增/修改分类数据
      userfind: {},             //用户对象：通过用户名查找用户对象数据

      file_url: '',             //'http://localhost:8080/api/files/' + flag
      file_type: '',            //文件类型：用于预览
      file_title: '',           //显示文件名
      file_download: '',        //传递当前待下载文件时间戳 flag
      file_btnview: false,      //"下载文件"按钮显示隐藏
      file_txtview: false,      //"上传文件"文字显示隐藏
      fileList: [],             //上传文件列表：用于存储文件列表
      files: [],                //上传文件列表：用于存储文件数据
      flag_addORedit: '',       //新增或编辑 标识：add/edit (新增时id为空或undefined)
      flag_select: '',          //选择文件 标识
    }
  },
  created() {
    this.findBySearch();
    this.findUerList();
    this.user = JSON.parse(localStorage.getItem('user'))
  },
  methods: {
    handleSizeChange(pageSize) {
      this.params.pageSize = pageSize;
      this.findBySearch();
    },    //点击切换分页条数
    handleCurrentChange(pageNum) {
      this.params.pageNum = pageNum;
      this.findBySearch();
    },  //点击跳转当前页码
    reset(){
      this.params = {
        pageNum: 1,
        pageSize: 5,
        name: '',
        phone: ''
      }
      this.findBySearch();
    },                        //点击清空按钮：重置查询条件

    // files： [id categoryid userid username flag filename]
    findBySearch(){
      request.get("/category/searchfiles",{params:this.params})
          .then(res =>{
            if(res.code === '0'){
              this.tableData = res.data.list;
              this.total = res.data.total;
            }else{
              this.$message.error({message: res.msg, duration: 800});
            }
          })
    },                    //加载全部分类列表
    findUerList(){
      request.get("/admin").then(res =>{
        if(res.code === '0'){
          this.userlist = res.data;
        }else{
          this.$message.error({message: res.msg, duration: 800});
        }
      })
    },                     //加载用户选项：用于在下拉列表选择用户
    findCategoryList(username) {
      this.userfind = {};
      this.userfind.name = username;
      request.get("/category/findByName",{params:this.userfind}).then(res =>{
        if(res.code === '0'){
          this.categorylist = res.data;
        }else{
          this.$message.error({message: res.msg, duration: 800});
        }
      })
    },       //加载分类选项：用于选择当前用户创建的分类

    add(){
      this.form = {};
      this.file_url = '';
      this.file_type = '';
      this.file_title = '上传文件';
      this.file_btnview = false;             //隐藏"下载文件"按钮
      this.file_txtview = false;             //隐藏"上传文件"文字
      this.flag_addORedit = 'add';           //新增标识：add
      this.dialogFormVisible = true;
    },                             //点击新增按钮：打开新增分类对话框，清空已有内容
    edit(obj) {
      this.form = obj;                      //传递当前行数据：传递form，用于提交表单数据
      this.findCategoryList(obj.username);  //加载分类选项： 用于选择当前用户创建的分类
      this.viewFiles(obj);                  //传递当前行数据：用于预览当前行文件
      this.file_download = obj.flag;        //传递当前行数据：用于下载当前行文件 flag
      this.file_btnview = true;             //启用"下载文件"按钮
      this.file_txtview = true;             //启用"上传文件"文字
      this.flag_addORedit = 'edit';         //编辑标识：edit
      this.dialogFormVisible = true;        //打开对话框
      this.formin.id = obj.id;              //传递当前行数据： 用于数据库更新一条上传记录 id
    },                        //点击编辑按钮：打开修改分类对话框，传递已有内容
    viewFiles(data){
      this.file_url = 'http://localhost:8080/api/files/' + data.flag;
      this.file_type = this.filesgetType(data.filename);
      this.file_title =  data.filename;
    },                   //点击编辑按钮：预览已有文件
    filesgetType(filename) {
      const extension = filename.split('.').pop().toLowerCase();
      if (['jpg', 'jpeg', 'png', 'gif'].includes(extension)) {
        return 'image';
      } else if (['mp3', 'wav'].includes(extension)) {
        return 'audio';
      } else if (['mp4', 'avi'].includes(extension)) {
        return 'video';
      }
      return 'other';
    },           //点击编辑按钮：解析文件格式
    downFile(flag) {
      location.href = 'http://localhost:8080/api/files/' + flag
    },                   //点击下载按钮：下载文件
    selectFiles(file, fileList) {
      this.fileList = fileList;         //更新文件列表
      this.files.push(file.raw);        //更新文件数据：将文件对象存储到 files 数组中
      this.file_type = '';              //点击选择文件：1.关闭文件预览
      this.file_btnview = false;        //点击选择文件：2.隐藏"下载文件"按钮
      this.file_txtview = true;         //点击选择文件：3.启用"上传文件"文字
      this.file_title = file.name;      //点击选择文件：4.传递文件名称
      this.form.filename =  file.name;  //点击选择文件：5.用于向数据库文件表新增一条记录 filename
      this.flag_select =  'select';
    },      //点击选择按钮：选择文件
    async submit() {
      //1. 上传文件
      if(this.flag_select ==  'select') {
        const formData = new FormData();
        this.files.forEach((file, index) => {
          formData.append('file', file);
        });
        await axios.post("http://localhost:8080/api/files/uploadfileslist", formData).then(response => {
          if(response.data.code === '0') {
            this.fileList = [];                               // 清空文件列表
            this.files = [];                                  // 清空文件数据
            this.form.flag = response.data.data[0].fileFlag;  //flag
          }else {
            this.$message.error({message: response.data.msg, duration: 800});
          }
        });
      }
      //2. 保存上传记录到数据库
      await this.findUserByName(this.form.username);
      this.form.userid = this.userfind.id;    //userid
      this.saveSubmit();
    },                   //点击提交按钮：1.上传文件，2.保存上传记录到到数据库，3.加载文件预览，4.查询文件列表
    async findUserByName(username){
      this.userfind = {};
      this.userfind.name = username;
      await request.get("/admin/findUserByName",{params:this.userfind}).then(res =>{
        if (res.code === '0') {
          this.userfind = res.data;
        }else {
          this.$message.error({message: res.msg, duration: 800});
        }
      })
    },    //通过用户名获取用户对象：通过表单用户名查询用户对象，用于获取用户ID
    saveSubmit() {
      if(this.flag_addORedit == 'add'){
        this.formin.id = '';
      }
      this.formin.userid = this.form.userid;            //userid
      this.formin.username = this.form.username;        //username
      this.formin.categoryid = this.form.categoryid;    //categoryid
      this.formin.flag = this.form.flag;                //flag
      this.formin.filename = this.form.filename;        //filename
      request.post("/category/files", this.formin).then(res => {
        if (res.code === '0') {
          this.$message.success({message: '操作成功', duration: 800});
          this.file_txtview = false;
          this.findBySearch();
        } else {
          this.$message.error({message: res.msg, duration: 800});
        }
      })
    },                     //点击提交按钮：2.保存上传记录到到数据库
    del(id) {
      request.delete("/category/delfiles/" + id).then(res => {
        if (res.code === '0') {
          this.$message.success({message: '删除成功', duration: 800});
          this.findBySearch();
        } else {
          this.$message.error({message: res.msg, duration: 800});
        }
      })
    },                          //点击删除按钮：删除数据库中当前文件
  }
}
</script>