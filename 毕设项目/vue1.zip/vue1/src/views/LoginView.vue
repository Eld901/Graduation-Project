<template>
  <div>
    <div class="login-container">
      <nav class="navTo" style="text-align: center;width: 10%;font-size: 13px;color: #00c1ed">
        <router-link to="/" class="textColor" style="text-decoration: none">Home</router-link> |
        <router-link to="/login" class="textColor" style="text-decoration: none">Login</router-link> |
        <router-link to="/register" class="textColor" style="text-decoration: none">Register</router-link>
      </nav>
      <div style="width: 400px; height: 400px; margin: 150px auto; background-color:rgba(0,215,236,0.17); border-radius: 10px">
        <div style="width: 100%; height: 100px; font-size: 30px; line-height: 100px; text-align: center; color: #00c1ed">登录</div>
        <div style="margin-top: 25px; text-align: center; height: 320px;">
          <el-form :model="admin">
            <el-form-item>
              <el-input v-model="admin.name" prefix-icon="el-icon-user" style="width: 80%" placeholder="请输入用户名"></el-input>
            </el-form-item>
            <el-form-item>
              <el-input v-model="admin.password" show-password prefix-icon="el-icon-lock" style="width: 80%" placeholder="请输入密码"></el-input>
            </el-form-item>
            <el-form-item>
              <div style="display: flex; justify-content: center">
                <el-input v-model="admin.verCode" prefix-icon="el-icon-user" style="width: 42%; margin-right: 10px" placeholder="请输入验证码"></el-input>
                <img :src="captchaUrl" @click="clickImg()" width="140px" height="33px" />
              </div>
            </el-form-item>
            <el-form-item>
              <el-button style="width: 80%; margin-top: 10px" type="primary" @click="loginto()">登录</el-button>
            </el-form-item>
            <div style="color:#015c8c;text-align: center">
              未有账号？<a href="javascript:void(0)" style="color: #006fff;text-decoration: none" @click="navRegister">点击注册</a>
            </div>
          </el-form>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
.login-container {
  background-size: 50%;background-image: url("@/assets/login_bg1.png");
  display: flex;flex-direction: column;
}
</style>
<script>
import request from "@/utils/request";

export default {
  name: "Login",
  data() {
    return {
      admin:{},
      files: {},
      key:'',
      captchaUrl: '',
      login: {},
      loginstatus: '',
    }
  },
  mounted() {
    this.key = Math.random();
    this.captchaUrl = 'http://localhost:8080/api/captcha?key=' + this.key;
  },
  methods: {
    navRegister() {
      this.$router.push("/register")
    },
    loginto() {
      request.post("/admin/login?key=" + this.key, this.admin).then(res => {
        if (res.code === '0') {
          this.$message.success({message: "登录成功", duration: 800});
          localStorage.setItem("user", JSON.stringify(res.data));
          this.$router.push("/");
          //保存登录用户
          // this.login.username = this.admin.name;
          // this.login.status = 'true';
          // request.post("/login/status", this.login).then(res => {
          //   if (res.code === '0') {
          //   } else {
          //     this.$message.error({message: res.msg, duration: 800});
          //   }
          // })
        } else {
          this.$message.error({message: res.msg, duration: 800});// 设置滞留时间为 5000 毫秒（5 秒）
          // this.$message.error(res.msg);
          this.key = Math.random();
          this.captchaUrl = 'http://localhost:8080/api/captcha?key=' + this.key;
          this.admin.verCode = ''
        }//登录失败，刷新验证码
      })


    },
    clickImg() {
      this.key = Math.random();
      this.captchaUrl = 'http://localhost:8080/api/captcha?key=' + this.key;
    }
  }
}
</script>
