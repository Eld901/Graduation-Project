<template>
  <div class="admin-container">
    <div>
      <div class="headsearch">
        <el-input v-model="params.username" style="width: 200px; margin-right: 10px" placeholder="请输入用户名"></el-input>
        <el-input v-model="params.title" style="width: 200px; margin-right: 10px" placeholder="请输入发布标题"></el-input>
        <el-button type="warning" @click="findBySearch()">查询</el-button>
        <el-button type="warning" @click="reset()">清空</el-button>
        <el-button type="primary" @click="add()">新增</el-button>
      </div>
      <div class="midtable">
        <el-table :data="tableData" style="width: 100%; margin: 15px 0px">
          <el-table-column prop="id" label="发布ID"></el-table-column>
          <el-table-column prop="categoryid" label="分类ID"></el-table-column>
          <el-table-column prop="userid" label="用户ID"></el-table-column>
          <el-table-column prop="username" label="用户名"></el-table-column>
          <el-table-column prop="title" label="发布标题"></el-table-column>
          <el-table-column label="操作">
            <template slot-scope="scope">
              <el-button type="primary" @click="edit(scope.row)">编辑</el-button>
              <el-popconfirm title="确定删除吗？" @confirm="del(scope.row.id)">
                <el-button slot="reference" type="danger" style="margin-left: 5px">删除</el-button>
              </el-popconfirm>
            </template>
          </el-table-column>
        </el-table>
      </div>
      <div class="footpage">
        <el-pagination
            @size-change="handleSizeChange"
            @current-change="handleCurrentChange"
            :current-page="params.pageNum"
            :page-sizes="[5, 10, 15, 20]"
            :page-size="params.pageSize"
            layout=" total, sizes, prev, pager, next"
            :total="total">
        </el-pagination>
      </div>
      <div class="coverdialog">
        <el-dialog title="请填写姓名" :visible.sync="dialogFormVisible" width="30%">
          <el-form :model="form">
            <el-form-item label="用户" label-width="15%">
              <el-select v-model="form.username" placeholder="请选择用户" @change="findCategoryList" style="width: 90%">
                <el-option :label="iuser.name" :value="iuser.name"
                           v-for="(iuser,indexuser) in userlist" :key="indexuser">
                  <span>{{ iuser.name }}</span>
                  <span style="float: right; color: #8492a6; font-size: 13px;margin-right: 5px">userID:{{ iuser.id }}</span>
                </el-option>
              </el-select>
            </el-form-item>
            <el-form-item label="分类ID" label-width="15%">
              <el-select v-model="form.categoryid" placeholder="请选择分类" style="width: 90%">
                <el-option :label="icate.id"  :value="icate.id"
                           v-for="(icate,indexcate) in categorylist" :key="indexcate">
                  <span>{{ icate.id }}</span>
                  <span style="float: right; color: #8492a6; font-size: 13px;margin-right: 5px">category:{{ icate.category }}</span>
                </el-option>
              </el-select>
            </el-form-item>
            <el-form-item label="发布" label-width="15%">
              <el-input v-model="form.title" autocomplete="off" style="width:90%" placeholder="请输入发布名"></el-input>
            </el-form-item>
          </el-form>
          <div slot="footer" class="dialog-footer">
            <el-button @click="dialogFormVisible = false">取 消</el-button>
            <el-button type="primary" @click="submit()">确 定</el-button>
          </div>
        </el-dialog>
      </div>
    </div>
  </div>
</template>
<style scoped>

</style>
<script>
import request from "@/utils/request";
export default {
  //name: "AdminView",
  data() {
    return {
      user: localStorage.getItem("user") ? JSON.parse(localStorage.getItem("user")) : {},
      params:{
        pageNum: 1,
        pageSize: 5
      },   //前端封装参数：用于传递分页参数或其他参数
      total: 0,                 //分页数据：共几条
      dialogFormVisible: false, //开启/关闭对话框

      userlist: {},             //用户列表：用于新增时选择用户
      categorylist: {},         //分类列表：用于新增时选择分类

      tableData: {},            //表格数据
      form: {},                 //表单数据
      formin: {},               //提交对象：提交新增/修改分类数据
      userfind: {},             //用户对象：通过用户名查找用户对象数据
    }
  },
  created() {
    this.findBySearch();
    this.findUerList();
    this.user = JSON.parse(localStorage.getItem('user'))
  },
  methods: {
    handleSizeChange(pageSize) {
      this.params.pageSize = pageSize;
      this.findBySearch();
    },    //点击切换分页条数
    handleCurrentChange(pageNum) {
      this.params.pageNum = pageNum;
      this.findBySearch();
    },  //点击跳转当前页码
    reset(){
      this.params = {
        pageNum: 1,
        pageSize: 5,
        name: '',
        phone: ''
      }
      this.findBySearch();
    },                        //点击清空按钮：重置查询条件

    // document： [id userid username categoryid title | content time]
    findBySearch(){
      request.get("/category/searchdoc",{params:this.params})
          .then(res =>{
            if(res.code === '0'){
              this.tableData = res.data.list;
              this.total = res.data.total;
            }else{
              this.$message.error({message: res.msg, duration: 800});
            }
          })
    },                    //加载全部发布列表
    findUerList(){
      request.get("/admin").then(res =>{
        if(res.code === '0'){
          this.userlist = res.data;
        }else{
          this.$message.error({message: res.msg, duration: 800});
        }
      })
    },                     //加载用户选项：用于在下拉列表选择用户
    findCategoryList(username) {
      this.userfind = {};
      this.userfind.name = username;
      request.get("/category/findByName",{params:this.userfind}).then(res =>{
        if(res.code === '0'){
          this.categorylist = res.data;
        }else{
          this.$message.error({message: res.msg, duration: 800});
        }
      })
    },       //加载分类选项：用于选择当前用户创建的分类

    add(){
      this.form = {};
      this.flag_addORedit = 'add';         //新增标识：add
      this.dialogFormVisible = true;
    },                             //点击新增按钮：打开新增发布对话框，清空已有内容
    edit(obj) {
      this.form = obj;
      this.flag_addORedit = 'edit';         //编辑标识：edit
      this.formin.id = obj.id;
      this.dialogFormVisible = true;
    },                        //点击编辑按钮：打开修改发布对话框，传递已有内容
    async submit(){
      if(this.flag_addORedit == 'add'){
        this.formin.id = '';
      }
      await this.findUserByName(this.form.username);    //通过用户名获取用户对象：通过表单用户名查询用户对象，用于获取用户ID
      this.formin.userid = this.userfind.id;            //userid
      this.formin.username = this.form.username;        //username
      this.formin.categoryid = this.form.categoryid;    //categoryid
      this.formin.title = this.form.title;              //title
      request.post("/category/savedoc", this.formin).then(res => {
        if (res.code === '0') {
          this.$message.success({message: '操作成功', duration: 800});
          this.dialogFormVisible = false;
          this.findBySearch();
        } else {
          this.$message.error({message: res.msg, duration: 800});
        }
      })
    },                    //点击提交按钮：通过用户名、分类名向数据库发布表新增一条记录
    async findUserByName(username){
      this.userfind.name = username;
      await request.get("/admin/findUserByName",{params:this.userfind}).then(res =>{
        if (res.code === '0') {
          this.userfind = res.data;
        }else {
          this.$message.error({message: res.msg, duration: 800});
        }
      })
    },    //通过用户名获取用户对象：通过表单用户名查询用户对象，用于获取用户ID
    del(id) {
      request.delete("/category/deldoc/" + id).then(res => {
        if (res.code === '0') {
          this.$message.success({message: '删除成功', duration: 800});
          this.findBySearch();
        } else {
          this.$message.error({message: res.msg, duration: 800});
        }
      })
    },                          //点击删除按钮：删除数据库中当前发布
  }
}
</script>