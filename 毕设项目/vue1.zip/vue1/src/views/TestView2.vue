<template>
  <div style="margin-left: 100px">
    <!-- 文件上传组件，禁用自动上传 -->
    <el-upload
        ref="upload"
        :auto-upload="false"
        :on-change="handleChange"
        :file-list="fileList"
        :http-request="false"
    >
    <el-button slot="trigger" size="small" type="primary">选择文件</el-button>
    <el-button
        style="margin-left: 10px;"
        size="small"
        type="success"
        @click="submitUpload"
    >上传文件</el-button>
    </el-upload>
  </div>
</template>

<script>
import axios from 'axios';

export default {
  data() {
    return {
      fileList: [], // 用于存储文件列表
      files: [] // 用于存储文件数据
    };
  },
  methods: {
    handleChange(file, fileList) {
      this.fileList = fileList;     // 更新文件列表
      this.files.push(file.raw);    // 将文件对象存储到 files 数组中
    },        // 点击按钮选择文件
    submitUpload() {
      const formData = new FormData();
      this.files.forEach((file, index) => {
        formData.append('file', file);
      });// 统一使用 'file' 作为字段名

      // 使用 axios 发起上传请求
      axios.post("http://localhost:8080/api/files/uploadfileslist", formData,
          {headers: {'Content-Type': 'multipart/form-data'}}).then(response => {
            if(response.data.code === '0') {
              this.$message.success({message: '操作成功', duration: 800});
              this.fileList = []; // 清空文件列表
              this.files = []; // 清空文件数据
              console.log('response---------------' , response.data);
              console.log('response---------------' , response.data.data);
              console.log('response---------------' , response.data.data[0]);
              console.log('response---------------' , response.data.data[0].fileFlag);
            }else {
              this.$message.error({message: response.data.msg, duration: 800});
            }
          });
    }                       // 点击按钮上传文件
  }
};
</script>