<template>
  <div class="admin-container">
    <div>
<!--      <el-input v-model="params.name" style="width: 200px; margin-right: 10px" placeholder="请输入图书名称"></el-input>-->
<!--      <el-input v-model="params.author" style="width: 200px; margin-right: 10px" placeholder="请输入图书作者"></el-input>-->
      <el-input v-model="params.name" style="width: 200px; margin-right: 10px" placeholder="请输入发布名称"></el-input>
      <el-input v-model="params.author" style="width: 200px; margin-right: 10px" placeholder="请输入发布作者"></el-input>
      <el-button type="warning" @click="findBySearch()">查询</el-button>
      <el-button type="warning" @click="reset()">清空</el-button>
      <el-button type="primary" @click="add()"  v-if="user.role !== 'ROLE_STUDENT'">新增</el-button>
    </div>
    <div>
      <el-table :data="tableData" style="width: 100%; margin: 15px 0px">
<!--        <el-table-column label="图书封面" width="">-->
<!--          <template v-slot="scope">-->
<!--            <el-image-->
<!--                style="width: 30px; height: 30px; border-radius: 50%"-->
<!--                :src="'http://localhost:8080/api/files/' + scope.row.img"-->
<!--                :preview-src-list="['http://localhost:8080/api/files/' + scope.row.img]">-->
<!--            </el-image>-->
<!--          </template>-->
<!--        </el-table-column>-->
<!--        <el-table-column label="图书姓名" prop="name" width=""></el-table-column>-->
<!--        <el-table-column label="图书介绍" width="180">-->
<!--          <template slot-scope="scope">-->
<!--            <el-button type="success" @click="viewEditor(scope.row.content)">点击查看</el-button>-->
<!--          </template>-->
<!--        </el-table-column>-->
<!--        <el-table-column label="图书作者" prop="author" width=""></el-table-column>-->
<!--        <el-table-column label="图书价格" prop="price" width=""></el-table-column>-->
<!--        <el-table-column label="图书出版社" prop="press" width=""></el-table-column>-->
<!--        <el-table-column label="图书分类" prop="typeName" width=""></el-table-column>-->
        <el-table-column label="发布id" prop="price" width=""></el-table-column>
        <el-table-column label="发布用户" prop="author" width=""></el-table-column>
        <el-table-column label="分类名称" prop="typeName" width=""></el-table-column>
        <el-table-column label="上传文件" prop="press" width=""></el-table-column>
        <el-table-column label="发布名称" prop="name" width=""></el-table-column>
        <el-table-column label="发布文件" width="">
          <template v-slot="scope">
            <el-image
                style="width: 30px; height: 30px; border-radius: 50%"
                :src="'http://localhost:8080/api/files/' + scope.row.img"
                :preview-src-list="['http://localhost:8080/api/files/' + scope.row.img]">
            </el-image>
          </template>
        </el-table-column>
        <el-table-column label="发布编辑" width="180">
          <template slot-scope="scope">
            <el-button type="success" @click="viewEditor(scope.row.content)">点击查看</el-button>
          </template>
        </el-table-column>
        <el-table-column label="操作" width="250">
          <template slot-scope="scope">
            <el-button type="primary" @click="edit(scope.row)" v-if="user.role === 'ROLE_ADMIN'">编辑</el-button>
            <el-button type="primary" @click="down(scope.row.img)">下载</el-button>
            <el-popconfirm title="确定删除吗？" @confirm="del(scope.row.id)">
              <el-button slot="reference" type="danger" style="margin-left: 5px" v-if="user.role === 'ROLE_ADMIN'">删除</el-button>
            </el-popconfirm>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <div class="block">
      <el-pagination
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
          :current-page="params.pageNum"
          :page-sizes="[5, 10, 15, 20]"
          :page-size="params.pageSize"
          layout="total, sizes, prev, pager, next"
          :total="total">
      </el-pagination>
    </div>
    <div>
      <el-dialog title="请填写姓名" :visible.sync="dialogFormVisible" width="50%">
        <el-form :model="form">
          <el-form-item label="图书名称" label-width="15%">
            <el-input v-model="form.name" autocomplete="off" style="width:90%"></el-input>
          </el-form-item>
          <el-form-item label="图书封面" label-width="15%">
            <el-upload action="http://localhost:8080/api/files/upload" :on-success="successUpload">
              <el-button size="small" type="primary">点击上传</el-button>
            </el-upload>
          </el-form-item>
          <el-form-item label="图书作者" label-width="15%">
            <el-input v-model="form.author" autocomplete="off" style="width:90%"></el-input>
          </el-form-item>
          <el-form-item label="图书价格" label-width="15%">
            <el-input v-model="form.price" autocomplete="off" style="width:90%"></el-input>
          </el-form-item>
          <el-form-item label="图书出版社" label-width="15%">
            <el-input v-model="form.press" autocomplete="off" style="width:90%"></el-input>
          </el-form-item>
          <el-form-item label="图书分类" label-width="15%">
            <el-select v-model="form.typeId" placeholder="请选择" style="width: 90%">
              <el-option v-for="item in typeObjs" :key="item.id" :label="item.name" :value="item.id"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="图书介绍" label-width="15%">
            <div id="editor" style="width:90%"></div>
          </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer">
          <el-button @click="dialogFormVisible = false">取 消</el-button>
          <el-button type="primary" @click="submit()">确 定</el-button>
        </div>
      </el-dialog>
    </div>
    <el-dialog title="文本.txt" :visible.sync="editorVisible" width="50%">
      <div v-html="viewData" class="w-e-text"></div>
    </el-dialog>
  </div>
</template>
<script>
import request from "@/utils/request";
import E from 'wangeditor'
let editor
function initWangEditor(content) {	setTimeout(() => {
  if (!editor) {
    editor = new E('#editor')
    editor.config.placeholder = '请输入内容'
    editor.config.uploadFileName = 'file'
    editor.config.uploadImgServer = 'http://localhost:8080/api/files/wang/upload'
    editor.create()
  }
  editor.txt.html(content)
}, 0)
}
export default {
  //name: "BookView",
  data() {
    return {
      params:{
        //img: '',
        name: '',
        author: '',
        //price: '',
        //press: '',
        pageNum: 1,
        pageSize: 5
      },
      tableData: [],
      total: 0,
      dialogFormVisible: false,
      editorVisible: false,
      form: {},
      typeObjs: [],
      viewData:'',
      user: localStorage.getItem("user") ? JSON.parse(localStorage.getItem("user")) : {}
    }
  },
  created() {
    this.findBySearch();
    this.findTypes();
  },
  methods: {
    findTypes() {
      request.get("/type").then(res => {
        if (res.code === '0') {
          this.typeObjs = res.data;
        } else {
          this.$message.error({message: res.msg, duration: 800});
          // this.$message.error(res.msg)
        }
      })
    },
    findBySearch(){
      request.get("/book/search",{params:this.params}).then(res =>{
        if(res.code === '0'){
          this.tableData = res.data.list;
          this.total = res.data.total;
        }else{
          this.$message.error({message: res.msg, duration: 800});
          // this.$message.error(res.msg);
        }
      })
    },
    reset(){
      this.params = {
        pageNum: 1,
        pageSize: 5,
        name: '',
        phone: ''
      }
      this.findBySearch();
    },
    handleSizeChange(pageSize) {
      this.params.pageSize = pageSize;
      this.findBySearch();
    },
    handleCurrentChange(pageNum) {
      this.params.pageNum = pageNum;
      this.findBySearch();
    },
    add(){
      this.form = {};
      initWangEditor("");
      this.dialogFormVisible = true;
    },
    edit(obj) {
      this.form = obj;
      //this.form = JSON.parse(JSON.stringify(obj));
      //initWangEditor(this.form.content);
      initWangEditor(obj.content ? this.form.content : "");
      this.dialogFormVisible = true;
    },
    viewEditor(data){
      //this.form.content = data;
      this.viewData = data;
      this.editorVisible = true;

    },
    submit(){
      this.form.content = editor.txt.html();
      request.post("/book", this.form).then(res => {
        if (res.code === '0') {
          this.$message.success({message: "操作成功", duration: 800});
          // this.$message.success("操作成功");
          this.dialogFormVisible = false;
          this.findBySearch();
        } else {
          this.$message.error({message: res.msg, duration: 800});
          // this.$message.error(res.msg);
        }
      })
    },
    del(id) {
      request.delete("/book/" + id).then(res => {
        if (res.code === '0') {
          this.$message.success({message: "删除成功", duration: 800});
          // this.$message.success("删除成功");
          this.findBySearch();
        } else {
          this.$message.error({message: res.msg, duration: 800});
          // this.$message.error(res.msg);
        }
      })
    },
    successUpload(res) {
      this.form.img = res.data;
      console.log(this.form.img);
    },
    down(flag) {
      console.log(flag);
      location.href = 'http://localhost:8080/api/files/' + flag
    }
  }
}
</script>