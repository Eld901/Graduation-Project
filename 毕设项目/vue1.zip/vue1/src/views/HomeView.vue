<template>
  <div>
    <div class="notice">
      <div class="notice-left"></div>
      <div class="notice-right-group">
        <div class="nr-left">
          <div class="notice-item" v-for="(inr, indexnr) in ntc_item" :key="indexnr" @click="tonotice">
            <div>{{indexnr+1}} {{inr.name}}</div>
            <div>{{inr.time}}</div>
          </div>
        </div>
        <div class="nr-right">
          <div class="notice-item" v-for="(ilog, indexlog) in log_item" :key="indexlog" @click="tolog">
            <div>{{indexlog+1}} {{ilog.username}}</div>
            <div>{{ilog.content}}</div>
            <div>{{ilog.time}}</div>
          </div>
        </div>
      </div>
    </div>
    <div class="btnrow">
      <div class="custom-btn-rowgroup-container" style="position: relative">
        <div class="custom-btn-rowgroup">
          <div class="custom-btn1">点击按钮</div>
          <div class="custom-btn1">点击按钮</div>
          <div class="custom-btn1">点击按钮</div>
        </div>
        <div class="custom-btn-rowgroup">
          <div class="custom-btn1">点击按钮</div>
          <div class="custom-btn1">点击按钮</div>
          <div class="custom-btn1">点击按钮</div>
        </div>
        <div class="ipt-group" style="position: absolute;right: 0px;">
          <el-input v-model="params" style="width: 200px; " placeholder="请输入姓名"></el-input>
          <el-button  @click="Click" >点击</el-button>
        </div>
      </div>
    </div>
    <div class="new-container">
      <div class="page-group">
        <div class="page-container" @mouseenter="showViewPoint(indexpage)" @mouseleave="hideViewPoint(indexpage)"
             v-for="(ipage, indexpage) in page_items" :key="indexpage">
          <div class="page-body">
            <div class="side-content"></div>
            <div class="page-content" >
              <div class="title">
                <div>{{ipage.name}}</div>
              </div>
              <div>zzz</div>
              <transition name="el-zoom-in-bottom">
                <div class="viewpoint" v-show="ipage.show_pointview">
                  <input class="custom-ipt" type="text" v-model="params">
                  <div @click="comment(ipage.comment_item)" class="custom-ipt-btn" style="margin-left: 10px;">评论</div>
                  <div v-if="checkComment(ipage.comment_item)" @click="showComments(indexpage)" class="custom-ipt-btn" style="margin-left: 10px;">{{ipage.show_comments_msg}}</div>
                </div>
              </transition>
            </div>
          </div>
          <transition name="el-zoom-in-top">
            <div class="comments" v-show="ipage.show_comments">
              <div class="comment-item" v-for="(icomment, indexcomment) in ipage.comment_item" :key="indexcomment">
                <div class="comment-item-title">{{icomment.title}}</div>
                <div class="comment-item-content">{{icomment.content}}</div>
                <div class="comment-item-bottom">
                  <div v-if="checkInner(icomment.comment_inner_item)" @click="showInnerComments(indexpage,indexcomment)" class="replybtm-btn" style="margin-left: 10px;">{{icomment.show_inner_comments_msg}}</div>
                  <div @click="showReply(indexpage,indexcomment)" class="replybtm-btn" style="margin-left: 10px;">回复</div>
                </div>
                <div class="replypoint" v-show="icomment.show_reply">
                  <input class="custom-ipt" type="text" v-model="params">
                  <div @click="viewPoint(ipage.comment_item)" class="replypoint-btn" style="margin-left: 10px;">评论</div>
                </div>
                <div  v-show="icomment.show_inner_comments">
                  <div class="comment-inner-item" v-for="(icommentinner, indexinner) in icomment.comment_inner_item" :key="indexinner">
                    <div class="comment-item-title">{{icommentinner.title}}</div>
                    <div class="comment-item-content">{{icommentinner.content}}</div>
                    <div class="comment-item-bottom">
                      <div @click="showInnerReply(indexpage,indexcomment,indexinner)" class="replybtm-btn" style="margin-left: 10px;">回复</div>
                    </div>
                    <div class="replypoint" v-show="icommentinner.show_inner_reply">
                      <input class="custom-ipt" type="text" v-model="params">
                      <div @click="replyPoint(ipage.comment_item)" class="replypoint-btn" style="margin-left: 10px;">评论</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </transition>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
.btnrow {
  width: 60%;
  margin: 0 auto;
}
.new-container {
  width: 100%;
  display: flex;
  justify-content: center;
}
.page-group {
  width: 60%;
}
.page-body {
  display: flex;
  flex-direction: row;
  position: relative;
}
.side-content {
  position: absolute;
  left: -190px;
  height: 300px;
  width: 180px;
  border: 1px solid #c5dce8;
}
.page-content {
  display: flex;
  flex-direction: column;
  width: 100%;
  height: 300px;
  color: #00c1ed;
  background-color: rgba(255, 255, 255, 0.76);
}
.page-content:hover {
  border: 1px solid #c5dce8;
}

.viewpoint {
  box-shadow: 0px 0px 5px rgb(179, 202, 214);
  position: absolute;bottom: 0px;left: 0px;right: 0px;
  display: flex;flex-direction: row;
  align-items: center;
  margin: 10px;
  padding: 5px 15px;
  overflow: hidden;
}
.replypoint {
  padding: 5px 15px;
  display: flex;
  flex-direction: row;
  align-items: center;
  margin-top: 10px;
  margin-bottom: 5px;
}
.custom-ipt {
  background-color: rgba(197, 220, 232, 0);
  border-radius: 15px;
  border: 1px  solid #c5dce8;
  box-sizing: border-box;
  color: #00c1ed;
  display: inline-block;
  height: 35px;
  line-height: 35px;
  outline: 0;
  padding: 0 15px;
  transition: border-color .2s cubic-bezier(.645,.045,.355,1);
  width: 100%;
}
.custom-ipt:focus {
  border-color: #00c1ed; /* 聚焦时的边框颜色 */
  background-color: rgba(9, 123, 147, 0.12);
}
.custom-ipt-btn {
  border-radius: 15px;
  border: 1px solid #00c1ed;
  width: 80px;height: 35px;line-height: 35px;
  color: #00c1ed;
  background-color: rgba(140, 212, 225, 0);
  text-align: center;
  font-size: 14px;
}
.custom-ipt-btn:hover {
  cursor: pointer;
  color: #ffffff;
  background-color: #d6e7fa;
  transition: background-color 0.3s ease;
  border-color: #d6e7fa;
}
.replybtm-btn {
  border-radius: 5px;
  //border: 1px solid rgb(9, 123, 147);
  border: 1px solid #c5dce8;
  width: 50px;height: 25px;line-height: 25px;
  color: rgb(9, 123, 147);
  background-color: rgba(140, 212, 225, 0);
  text-align: center;
  font-size: 14px;
}
.replybtm-btn:hover {
  cursor: pointer;
  color: #ffffff;
  background-color: #d6e7fa;
  transition: background-color 0.3s ease;
  border-color: #d6e7fa;
}
.replypoint-btn {
  border-radius: 5px;
  //border: 1px solid rgb(9, 123, 147);
  border: 1px solid #00c1ed;
  width: 50px;height: 25px;line-height: 25px;
  color: #00c1ed;
  //background-color: #8cd4e1a1;
  text-align: center;
  font-size: 14px;
}
.replypoint-btn:hover {
  cursor: pointer;
  color: #ffffff;
  background-color: #d6e7fa;
  transition: background-color 0.3s ease;
  border-color: #d6e7fa;
}

.comments {
  width: 100%;
  border: 1px solid #c5dce8;
  box-shadow: 0px 0px 5px rgb(179, 202, 214);
  margin-bottom: 15px;
}
.comment-item {
  color: rgb(9, 123, 147);
  padding: 0 25px;
  border-bottom: 1px solid #c5dce8;
}
.comment-item:hover {
  cursor: pointer;
  background-color: #e0eef1;
}
.comment-inner-item {
  color: rgb(9, 123, 147);
  padding: 0 25px;
}
.comment-inner-item:hover {
  cursor: pointer;
  background-color: rgba(197, 220, 232, 0.42)
}
.comment-item-title {
  font-size: 14px;
  font-weight: bold;
}
.comment-item-title:hover {
  color: #00c1ed;
}
.comment-item-content {
  font-size: 14px;
}
.comment-item-bottom {
  display: flex;
  flex-direction: row;
  justify-content: flex-end;
  padding-bottom: 5px;
}
</style>
<script>
import request from "@/utils/request";

export default {
  name: "NewView",
  data() {
    return {
      params:'',
      count: 0,
      exit: '',
      msg:'',
      showContent: true,
      active_color: '',
      page_items_test: [
        {
          name:  '1',
          show_pointview: '',
          show_comments: '',
          show_comments_msg:'展开',
          comment_item: [
            {
              title: '评论1',
              content: '评论内容1',
              show_inner_comments: '',
              show_inner_comments_msg:'展开',
              show_reply: '',
              comment_inner_item: [
                {
                  title: '内部评论1',
                  content: '内部评论内容1',
                  show_inner_reply: '',
                },
                {
                  title: '内部评论2',
                  content: '内部评论内容2',
                  show_inner_reply: '',
                },
              ],
            },
            {
              title: '评论2',
              content: '评论内容2',
              msg:'展开',
              show_inner_comments: '',
              show_reply: '',
              comment_inner_item:[],
            },
            {
              title: '评论3',
              content: '评论内容3',
              msg:'展开',
              show_inner_comments: '',
              show_reply: '',
              comment_inner_item:[],
            },
          ],
        },
      ],
      page_items: [
        {
          name:  '1',
          show_pointview: '',
          show_comments: '',
          show_comments_msg:'展开',
          comment_item: [
            {
              title: '评论1',
              content: '评论内容1',
              show_inner_comments: '',
              show_inner_comments_msg:'展开',
              show_reply: '',
              comment_inner_item: [
                {
                  title: '内部评论1',
                  content: '内部评论内容1',
                  show_inner_reply: '',
                },
                {
                  title: '内部评论2',
                  content: '内部评论内容2',
                  show_inner_reply: '',
                },
              ],
            },
            {
              title: '评论2',
              content: '评论内容2',
              msg:'展开',
              show_inner_comments: '',
              show_reply: '',
              comment_inner_item:[],
            },
            {
              title: '评论3',
              content: '评论内容3',
              msg:'展开',
              show_inner_comments: '',
              show_reply: '',
              comment_inner_item:[],
            },
          ],
        },
        {
          name:  '2',
          show_pointview: '',
          show_comments: '',
          show_comments_msg:'展开',
          comment_item:[
            {
              title: '评论1',
              content: '评论内容1',
              show_inner_comments: '',
              show_inner_comments_msg:'展开',
              show_reply: '',
              comment_inner_item:[
                {
                  title: '内部评论1',
                  content: '内部评论内容1',
                  show_inner_reply: '',
                },
                {
                  title: '内部评论2',
                  content: '内部评论内容2',
                  show_inner_reply: '',
                },
              ],
            },
          ],
        },
        {
          name:  '3',
          show_pointview: '',
          show_comments: '',
          show_comments_msg:'展开',
          comment_item:[
            {
              title: '',
              content: '',
              show_inner_comments: '',
              show_inner_comments_msg: '',
              show_reply: '',
              comment_inner_item:[],
            },
          ],
        },
      ],
      ntc_item:[
          // {num:'1', content:'公告内容',},
      ],
      log_item:[
        // {num:'1', content:'日志内容',},
      ],
      user: localStorage.getItem("user") ? JSON.parse(localStorage.getItem("user")) : {},
      //---------------------------
    }
  },
  created() {
    this.user = JSON.parse(localStorage.getItem('user'));
  },
  mounted() {
    this.findNotice();
    this.findLog();
  },
  methods: {
    tonotice() {
      // this.$router.push({name: 'HomeView'});
      if(this.user.role === 'ROLE_ADMIN') {
        console.log('admin');
        this.$router.push('/notice');
      }else {
        console.log('user');
        this.$router.push('/home');
      }
    },
    tolog() {
      if(this.user.role === 'ROLE_ADMIN') {
        console.log('admin');
        this.$router.push('/log');
      }else {
        console.log('user');
        this.$router.push('/homelog');
        // this.$router.push('/home');
      }
    },
    findNotice(){
      request.get("/notice").then(res =>{
        if(res.code === '0'){
          this.ntc_item = res.data;
          console.log(this.ntc_item);
        }else{
          this.$message.error({message: res.msg, duration: 800});
          // this.$message.error(res.msg);
        }
      })
    },
    findLog(){
      request.get("/log").then(res =>{
        if(res.code === '0'){
          this.log_item = res.data;
          // this.total = res.data.total;
        }else{
          this.$message.error({message: res.msg, duration: 800});
          // this.$message({message: res.msg, type: 'error'});
        }
      })
    },
    showViewPoint(indexp) {
      this.page_items[indexp].show_pointview = true;
    },
    hideViewPoint(index) {
      this.page_items[index].show_pointview = false;
    },
    checkComment(commentItem) {
      // 检查 comment_item 是否存在且不为空
      return commentItem && commentItem.length > 0 && commentItem.some(item => item.content.trim() !== '');
      // this.exit = true;
      // return this.exit;
    },
    checkInner(commentInnerItem) {
      // 检查 comment_inner_item 是否存在且不为空
      return commentInnerItem && commentInnerItem.length > 0 && commentInnerItem.some(item => item.content.trim() !== '');
      // this.exit = true;
      // return this.exit;
    },
    showComments(index){
      this.page_items[index].show_comments = !this.page_items[index].show_comments;
      if(this.page_items[index].show_comments){
        this.page_items[index].show_comments_msg = '收起';
      }else{
        this.page_items[index].show_comments_msg = '展开';
      }
    },
    showInnerComments(indexp,indexc){
      this.page_items[indexp].comment_item[indexc].show_inner_comments = !this.page_items[indexp].comment_item[indexc].show_inner_comments;
      if(this.page_items[indexp].comment_item[indexc].show_inner_comments){
        this.page_items[indexp].comment_item[indexc].show_inner_comments_msg = '收起';
      }else{
        this.page_items[indexp].comment_item[indexc].show_inner_comments_msg = '展开';
      }
    },
    showReply(indexp,indexc){
      this.page_items[indexp].comment_item[indexc].show_reply = !this.page_items[indexp].comment_item[indexc].show_reply;
    },
    showInnerReply(indexp,indexc,indexi){
      this.page_items[indexp].comment_item[indexc].comment_inner_item[indexi].show_inner_reply =
          !this.page_items[indexp].comment_item[indexc].comment_inner_item[indexi].show_inner_reply;
    },
    viewPoint(commentItem){
      console.log(commentItem);
      console.log(commentItem.length);
    },
    replyPoint(commentItem){
      console.log(commentItem);
      console.log(commentItem.length);
    },
    Click() {
      // console.log(this.items);
      // console.log(this.items);
      // this.items = this.change;
    },
    Clicker(index) {
      return null;
    },
    //---------------------------
  }
}
</script>