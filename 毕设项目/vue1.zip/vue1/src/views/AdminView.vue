<template>
  <div class="admin-container">
    <div>
      <el-input v-model="params.name" style="width: 200px; margin-right: 10px" placeholder="请输入姓名"></el-input>
      <el-input v-model="params.phone" style="width: 200px; margin-right: 10px" placeholder="请输入电话"></el-input>
      <el-button type="warning" @click="findBySearch()">查询</el-button>
      <el-button type="warning" @click="reset()">清空</el-button>
      <el-button type="primary" @click="add()">新增</el-button>
    </div>
    <div>
      <el-table :data="tableData" style="width: 100%; margin: 15px 0px">
        <el-table-column prop="name" label="姓名" width="100"></el-table-column>
        <el-table-column prop="sex" label="性别" width="100"></el-table-column>
        <el-table-column prop="age" label="年龄" width="100"></el-table-column>
        <el-table-column prop="phone" label="电话" width=""></el-table-column>
        <el-table-column prop="role" label="角色" width=""></el-table-column>
        <el-table-column label="操作">
          <template slot-scope="scope">
            <el-button type="primary" @click="edit(scope.row)">编辑</el-button>
            <el-popconfirm title="确定删除吗？" @confirm="del(scope.row.id)">
              <el-button slot="reference" type="danger" style="margin-left: 5px">删除</el-button>
            </el-popconfirm>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <div class="block">
      <el-pagination
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
          :current-page="params.pageNum"
          :page-sizes="[5, 10, 15, 20]"
          :page-size="params.pageSize"
          layout=" total, sizes, prev, pager, next"
          :total="total">
      </el-pagination>
    </div>
    <div>
      <el-dialog title="请填写姓名" :visible.sync="dialogFormVisible" width="30%">
        <el-form :model="form">
          <el-form-item label="姓名" label-width="15%">
            <el-input v-model="form.name" autocomplete="off" style="width:90%"></el-input>
          </el-form-item>
          <el-form-item label="性别" label-width="15%">
            <el-radio v-model="form.sex" label="男">男</el-radio>
            <el-radio v-model="form.sex" label="女">女</el-radio>
          </el-form-item>
          <el-form-item label="年龄" label-width="15%">
            <el-input v-model="form.age" autocomplete="off" style="width:90%"></el-input>
          </el-form-item>
          <el-form-item label="电话" label-width="15%">
            <el-input v-model="form.phone" autocomplete="off" style="width:90%"></el-input>
          </el-form-item>
          <el-form-item label="角色" label-width="15%">
            <el-select v-model="form.role" placeholder="请选择" style="width: 90%">
              <el-option label="教师" value="ROLE_TEACHER"></el-option>
              <el-option label="学生" value="ROLE_STUDENT"></el-option>
              <el-option label="管理员" value="ROLE_ADMIN" v-if="user.role === 'ROLE_ADMIN'"></el-option>
            </el-select>
          </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer">
          <el-button @click="dialogFormVisible = false">取 消</el-button>
          <el-button type="primary" @click="submit()">确 定</el-button>
        </div>
      </el-dialog>
    </div>
  </div>
</template>
<style scoped>

</style>
<script>
import request from "@/utils/request";
export default {
  //name: "AdminView",
  data() {
    return {
      params:{
        name: '',
        phone: '',
        pageNum: 1,
        pageSize: 5
      },
      user_byname: {},
      tableData: [],
      total: 0,
      dialogFormVisible: false,
      form: {},
      user: localStorage.getItem("user") ? JSON.parse(localStorage.getItem("user")) : {},
      files: {
        img: '',
        userid: '',
        username: ''
      }
    }
  },
  created() {
    this.findBySearch();
    this.user = JSON.parse(localStorage.getItem('user'))
  },
  methods: {
    findBySearch(){
      request.get("/admin/search",{params:this.params})
          .then(res =>{
        if(res.code === '0'){
          this.tableData = res.data.list;
          this.total = res.data.total;
        }else{
          this.$message.error({message: res.msg, duration: 800});
          // this.$message({message: res.msg, type: 'error'});
        }
      })
    },
    findUserByName(username){
      request.get("/admin/findUserByName",{params:{username:username}}).then(res =>{
            if (res.code === '0') {
              this.user_byname = res.data;
            }else {
              this.$message.error({message: res.msg, duration: 800});
            }
          })
    },
    reset(){
      this.params = {
        pageNum: 1,
        pageSize: 5,
        name: '',
        phone: ''
      }
      this.findBySearch();
    },
    handleSizeChange(pageSize) {
      this.params.pageSize = pageSize;
      this.findBySearch();
    },
    handleCurrentChange(pageNum) {
      this.params.pageNum = pageNum;
      this.findBySearch();
    },
    add(){
      this.form = {};
      this.dialogFormVisible = true;
    },
    edit(obj) {
      this.form = obj;
      this.dialogFormVisible = true;
      console.log(this.form);
    },
    submit(){
      if(this.form.role === 'ROLE_TEACHER'){
        this.form.role = 'ROLE_TEACHER';
      }else{
        this.form.role = 'ROLE_STUDENT';
      }
      //保存用户信息到数据库
      request.post("/admin", this.form).then(res => {
        if (res.code === '0') {
          this.$message.success({message: '操作成功', duration: 800});
          // this.$message({message: '操作成功', type: 'success'});
          this.dialogFormVisible = false;
          this.findBySearch();
          //新增一个用户，新增一条用户头像数据
          //新增一个用户，保存到数据库，查询全部用户列表，
          //查询当前添加的用户：主要是为了获取用户的id
          //根据当前用户id、当前用户名，新增一条用户头像数据，初始化图片id，初始化的时间戳为空
          //只能根据当前用户名添加头像数据
          // this.files.img = res.data;//时间戳
          // this.files.userid = this.user_byname.id;//用户id 为空
          // this.findUserByName(this.form.name);
          // this.files.username =  this.form.name;//用户名
          // // console.log(this.files);
          // // console.log(this.user);
          // //保存上传信息
          // request.post("/files/save", this.files).then(res => {
          //   if (res.code === '0') {
          //     this.$message.success({message: '操作成功', duration: 800});
          //     // this.$message({message: '操作成功', type: 'success'});
          //     //加载图片
          //     // this.findByUser();
          //   } else {
          //     this.$message.error({message: res.msg, duration: 800});
          //     // this.$message({message: res.msg, type: 'error'});
          //   }
          // })
        } else {
          this.$message.error({message: res.msg, duration: 800});
          // this.$message({message: res.msg, type: 'error'});
        }
      })
    },
    del(id) {
      request.delete("/admin/" + id).then(res => {
        if (res.code === '0') {
          this.$message.success({message: '删除成功', duration: 800});
          // this.$message({message: '删除成功', type: 'success'});
          this.findBySearch();
        } else {
          this.$message.error({message: res.msg, duration: 800});
          // this.$message({message: res.msg, type: 'error'});
        }
      })
    }
  }
}
</script>