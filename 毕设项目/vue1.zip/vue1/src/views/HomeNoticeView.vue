<template>
  <div class="admin-container">
    <div style="display: flex">
      <div style="flex: 1;">
        <div style="margin-bottom: 15px; font-weight: bold; font-size: 18px">系统公告</div>
        <el-collapse v-model="activeName" accordion>
          <el-collapse-item v-for="(item,index) in data" :key="index" :title="`${item.time} ${item.name}`" :name="item.id">
            <div style="padding: 0 20px">发布时间：{{ item.time }}</div>
            <div style="padding: 0 20px">发布用户：admin</div>
            <div style="padding: 0 20px">公告标题：{{ item.name }}</div>
            <div style="padding: 0 20px">公告内容：{{ item.content }}</div>
          </el-collapse-item>
        </el-collapse>
      </div>
<!--      <div style="width: 50px"></div>-->
<!--      <div style="flex: 1; margin-top: 50px;">-->
<!--        <div id="bie" style="width: 100%; height: 400px"></div>-->
<!--      </div>-->
    </div>
<!--    <div style="display: flex">-->
<!--      <div style="flex: 1; margin-top: 50px">-->
<!--        <div id="bar" style="width: 100%; height: 400px"></div>-->
<!--      </div>-->
<!--      <div style="flex: 1; margin-top: 50px">-->
<!--        <div id="line" style="width: 100%; height: 400px"></div>-->
<!--      </div>-->
<!--    </div>-->
  </div>
</template>
<script>

import request from "@/utils/request";
import * as echarts from "echarts";

export default {
  name: 'HomeNoticeView',
  data() {
    return {
      activeName: '1',
      data: []
    };
  },
  mounted() {
    this.findNotice();
    // this.initEcharts();
    // this.initBar();
  },
  methods: {
    findNotice(){
      request.get("/notice").then(res =>{
        if(res.code === '0'){
          this.data = res.data;
          this.activeName = res.data[0].id;
        }else{
          this.$message.error({message: res.msg, duration: 800});
          // this.$message.error(res.msg);
        }
      })
    },
    initEcharts() {
      request.get("/book/echarts/bie").then(res => {
        if (res.code === '0') {
          // 开始去渲染饼图数据啦
          this.initBie(res.data)
        } else {
          this.$message.error({message: res.msg, duration: 800});
          // this.$message.error(res.msg)
        }
      })
      request.get("/book/echarts/bar").then(res => {
        if (res.code === '0') {
          // 开始去渲染柱状图数据啦
          let map = res.data;
          this.initBar(map.xAxis, map.yAxis)
          // 开始去渲染折线图数据啦
          this.initLine(map.xAxis, map.yAxis)
        } else {
          this.$message.error({message: res.msg, duration: 800});
          // this.$message.error(res.msg)
        }
      })
    },
    initBie(data) {
      let chartDom = document.getElementById('bie');
      let myChart = echarts.init(chartDom);
      let option;

      option = {
        title: {
          text: '图书统计(饼图)',
          subtext: '统计维度：图书分类',
          left: 'center'
        },
        tooltip: {
          trigger: 'item'
        },
        legend: {
          orient: 'vertical',
          left: 'left'
        },
        series: [
          {
            name: '图书分类',
            type: 'pie',
            radius: '50%',
            data: data,
            //     [
            //   { value: 1048, name: '情感类图书' },
            //   { value: 735, name: '技术类图书' },
            //   { value: 580, name: '生活类图书' },
            //   { value: 484, name: '悬疑类图书' }
            // ],
            emphasis: {
              itemStyle: {
                shadowBlur: 10,
                shadowOffsetX: 0,
                shadowColor: 'rgba(0, 0, 0, 0.5)'
              }
            }
          }
        ]
      };

      option && myChart.setOption(option);

    },
    initBar(xAxis,yAxis) {
      let chartDom = document.getElementById('bar');
      let myChart = echarts.init(chartDom);
      let option;

      option = {
        title: {
          text: '图书统计（柱状图）',
          subtext: '统计维度：图书分类',
          left: 'center'
        },
        xAxis: {
          type: 'category',
          data: xAxis
          //['情感类图书', '技术类图书', '生活类图书', '悬疑类图书']
        },
        yAxis: {
          type: 'value'
        },
        series: [
          {
            data: yAxis,
            //[1048, 735, 580, 484],
            type: 'bar',
            showBackground: true,
            backgroundStyle: {
              color: 'rgba(180, 180, 180, 0.2)'
            }
          }
        ]
      };

      option && myChart.setOption(option);
    },
    initLine(xAxis, yAxis) {
      let chartDom = document.getElementById('line');
      let myChart = echarts.init(chartDom);
      let option;

      option = {
        title: {
          text: '图书统计（折线图）',
          subtext: '统计维度：图书分类',
          left: 'center'
        },
        xAxis: {
          type: 'category',
          data: xAxis
        },
        yAxis: {
          type: 'value'
        },
        series: [
          {
            data: yAxis,
            type: 'line'
          }
        ]
      };

      option && myChart.setOption(option);
    }
  }
}
</script>