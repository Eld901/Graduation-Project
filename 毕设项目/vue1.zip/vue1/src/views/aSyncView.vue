<template>
  <div class="admin-container">
    <div class="headsearch">
      <el-input v-model="params.authorname" style="width: 200px; margin-right: 10px" placeholder="请输入创建者"></el-input>
      <el-input v-model="params.title" style="width: 200px; margin-right: 10px" placeholder="请输入创建的协同标题"></el-input>
      <el-button type="warning" @click="findBySearch()">查询</el-button>
      <el-button type="warning" @click="reset()">清空</el-button>
      <el-button type="primary" @click="add()">新增</el-button>
    </div>
    <div class="midtable">
      <el-table :data="tableData" style="width: 100%; margin: 15px 0px">
        <el-table-column prop="id" label="协同ID"></el-table-column>
        <el-table-column prop="authorid" label="创建者ID"></el-table-column>
        <el-table-column prop="authorname" label="创建者名"></el-table-column>
        <el-table-column prop="title" label="协同标题"></el-table-column>
        <el-table-column label="操作">
          <template slot-scope="scope">
            <el-button type="primary" @click="edit(scope.row)">编辑</el-button>
            <el-popconfirm title="确定删除吗？" @confirm="del(scope.row.id)">
              <el-button slot="reference" type="danger" style="margin-left: 5px">删除</el-button>
            </el-popconfirm>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <div class="footpage">
      <el-pagination
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
          :current-page="params.pageNum"
          :page-sizes="[5, 10, 15, 20]"
          :page-size="params.pageSize"
          layout=" total, sizes, prev, pager, next"
          :total="total">
      </el-pagination>
    </div>
    <div class="coverdialog">
      <el-dialog :title="sync_title" :visible.sync="dialogFormVisible" width="30%">
        <el-form :model="form">
          <el-form-item label="用户" label-width="15%">
            <el-select v-model="form.authorname" placeholder="请选择用户" style="width: 90%">
              <el-option :label="iuser.name" :value="iuser.name"
                         v-for="(iuser,indexuser) in userlist" :key="indexuser">
                <span>{{ iuser.name }}</span>
                <span style="float: right; color: #8492a6; font-size: 13px;margin-right: 5px">userID:{{ iuser.id }}</span>
              </el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="协同" label-width="15%">
            <el-input v-model="form.title" autocomplete="off" style="width:90%" placeholder="请输入创建协同标题"></el-input>
          </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer">
          <el-button @click="dialogFormVisible = false">取 消</el-button>
          <el-button type="primary" @click="submit()">确 定</el-button>
        </div>
      </el-dialog>
    </div>
  </div>
</template>
<style scoped>

</style>
<script>
import request from "@/utils/request";
export default {
  //name: "AdminView",
  data() {
    return {
      user: localStorage.getItem("user") ? JSON.parse(localStorage.getItem("user")) : {},
      params:{
        pageNum: 1,
        pageSize: 5
      },   //前端封装参数：用于传递分页参数或其他参数
      total: 0,                 //分页数据：共几条
      dialogFormVisible: false, //开启/关闭对话框

      userlist: {},             //用户列表：用于新增时选择用户

      tableData: {},            //表格数据
      form: {},                 //表单数据
      formin: {},               //提交对象：提交新增/修改分类数据
      forminmessage: {},        //提交对象
      userfind: {},             //用户对象：通过用户名查找用户对象数据

      flag_addORedit: '',       //新增或编辑 标识：add/edit (新增时id为空或undefined)
      sync_title: '',
    }
  },
  created() {
    this.findBySearch();
    this.findUerList();
    this.user = JSON.parse(localStorage.getItem('user'))
  },
  methods: {
    handleSizeChange(pageSize) {
      this.params.pageSize = pageSize;
      this.findBySearch();
    },    //点击切换分页条数
    handleCurrentChange(pageNum) {
      this.params.pageNum = pageNum;
      this.findBySearch();
    },  //点击跳转当前页码
    reset(){
      this.params = {
        pageNum: 1,
        pageSize: 5,
        name: '',
        phone: ''
      }
      this.findBySearch();
    },                        //点击清空按钮：重置查询条件

    // sync： [id authorid authorname title]
    findBySearch(){
      request.get("/sync/searchSync",{params:this.params})
          .then(res =>{
            if(res.code === '0'){
              this.tableData = res.data.list;
              this.total = res.data.total;
            }else{
              this.$message.error({message: res.msg, duration: 800});
            }
          })
    },                 //加载全部协同列表
    findUerList(){
      request.get("/admin").then(res =>{
        if(res.code === '0'){
          this.userlist = res.data;
        }else{
          this.$message.error({message: res.msg, duration: 800});
        }
      })
    },                  //加载用户选项：用于在下拉列表选择用户

    add(){
      this.form = {};
      this.flag_addORedit = 'add';           //新增标识：add
      this.sync_title = '新增创建协同';
      this.dialogFormVisible = true;
    },                             //点击新增按钮：打开新增创建协同对话框，清空已有内容
    edit(obj) {
      this.form = obj;
      this.formin.id = obj.id;
      this.flag_addORedit = 'edit';         //编辑标识：edit
      // this.sync_title = obj.title;
      this.sync_title = '协同ID：'+obj.id;
      this.dialogFormVisible = true;
    },                        //点击编辑按钮：打开修改创建协同对话框，传递已有内容
    async submit(){
      if(this.flag_addORedit == 'add'){
        this.formin.id = '';
      }
      await this.findUserByName(this.form.authorname);    //通过用户名获取用户对象：通过表单用户名查询用户对象，用于获取用户ID
      this.formin.authorid = this.userfind.id;            //authorid
      this.formin.authorname = this.form.authorname;      //authorname
      this.formin.title = this.form.title;                //title
      await request.post("/sync/saveSync", this.formin).then(res => {
        if (res.code === '0') {
        } else {
          this.$message.error({message: res.msg, duration: 800});
        }
      })

      await this.finSyncByCreate(this.form.authorname, this.form.title);
      this.forminmessage.syncid = this.userfind.id;
      this.forminmessage.action = 'update';
      this.forminmessage.content = '';
      request.post("/sync/saveSyncMessage", this.forminmessage).then(res => {
        if (res.code === '0') {
          this.$message.success({message: '操作成功', duration: 800});
          this.dialogFormVisible = false;
          this.findBySearch();
        } else {
          this.$message.error({message: res.msg, duration: 800});
        }
      })
    },                    //点击提交按钮：通过用户名、分类名向数据库创建协同表新增一条记录
    async findUserByName(username){
      this.userfind = {};
      this.userfind.name = username;
      await request.get("/admin/findUserByName",{params:this.userfind}).then(res =>{
        if (res.code === '0') {
          this.userfind = res.data;
        }else {
          this.$message.error({message: res.msg, duration: 800});
        }
      })
    },    //通过用户名获取用户对象：通过表单用户名查询用户对象，用于获取用户ID
    async finSyncByCreate(authorname,title){
      this.userfind = {};
      this.userfind.authorname = authorname;
      this.userfind.title = title;
      await request.get("/sync/finSyncByCreate",{params:this.userfind}).then(res =>{
        if (res.code === '0') {
          this.userfind = res.data;
        }else {
          this.$message.error({message: res.msg, duration: 800});
        }
      })
    },

    async del(id) {
      await request.delete("/sync/deleteSync/" + id).then(res => {
        if (res.code === '0') {
        } else {
          this.$message.error({message: res.msg, duration: 800});
        }
      })
      await request.delete("/sync/deleteSyncMessage/" + id).then(res => {
        if (res.code === '0') {
          this.$message.success({message: '删除成功', duration: 800});
          this.findBySearch();
        } else {
          this.$message.error({message: res.msg, duration: 800});
        }
      })
    },                          //点击删除按钮：删除数据库中当前创建协同表记录
  }
}
</script>