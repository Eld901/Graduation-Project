<template>
  <div class="admin-container">
    <div>
      <div class="headsearch">
        <el-input v-model="params.username" style="width: 200px; margin-right: 10px" placeholder="请输入用户名"></el-input>
        <el-input v-model="params.doctitle" style="width: 200px; margin-right: 10px" placeholder="请输入发布标题"></el-input>
        <el-button type="warning" @click="findBySearch()">查询</el-button>
        <el-button type="warning" @click="reset()">清空</el-button>
        <el-button type="primary" @click="add()">新增</el-button>
      </div>
      <div class="midtable">
        <el-table :data="tableData" style="width: 100%; margin: 15px 0px">
          <el-table-column prop="id" label="富文本编辑器ID"></el-table-column>
          <el-table-column prop="docid" label="发布ID"></el-table-column>
          <el-table-column prop="doctitle" label="发布标题"></el-table-column>
          <el-table-column prop="userid" label="用户ID"></el-table-column>
          <el-table-column prop="username" label="用户名"></el-table-column>
          <el-table-column prop="" label="富文本内容">
            <template slot-scope="scope">
              <el-button type="success" @click="viewEditor(scope.row)">点击查看</el-button>
            </template>
          </el-table-column>
<!--          <el-table-column prop="doceditorContent" label="富文本内容" width="180"></el-table-column>-->
          <el-table-column label="操作">
            <template slot-scope="scope">
              <el-button type="primary" @click="edit(scope.row)">编辑</el-button>
              <el-popconfirm title="确定删除吗？" @confirm="del(scope.row.id)">
                <el-button slot="reference" type="danger" style="margin-left: 5px">删除</el-button>
              </el-popconfirm>
            </template>
          </el-table-column>
        </el-table>
      </div>
      <div class="footpage">
        <el-pagination
            @size-change="handleSizeChange"
            @current-change="handleCurrentChange"
            :current-page="params.pageNum"
            :page-sizes="[5, 10, 15, 20]"
            :page-size="params.pageSize"
            layout=" total, sizes, prev, pager, next"
            :total="total">
        </el-pagination>
      </div>
      <div class="coverdialog">
        <el-dialog title="请填写姓名" :visible.sync="dialogFormVisible">
          <el-form :model="form">
            <el-form-item label="用户" label-width="15%">
              <el-select v-model="form.username" placeholder="请选择用户" @change="findDocumentList" style="width: 90%">
                <el-option :label="iuser.name" :value="iuser.name"
                           v-for="(iuser,indexuser) in userlist" :key="indexuser">
                  <span>{{ iuser.name }}</span>
                  <span style="float: right; color: #8492a6; font-size: 13px;margin-right: 5px">userID:{{ iuser.id }}</span>
                </el-option>
              </el-select>
            </el-form-item>
            <el-form-item label="发布" label-width="15%">
              <el-select v-model="form.docid" placeholder="请选择发布" style="width: 90%">
                <el-option :label="idoc.title"  :value="idoc.id"
                           v-for="(idoc,indexdoc) in documentlist" :key="indexdoc">
                  <span>{{ idoc.title }}</span>
                  <span style="float: right; color: #8492a6; font-size: 13px;margin-right: 5px">docID:{{ idoc.id }}</span>
                </el-option>
              </el-select>
            </el-form-item>
            <el-form-item label="编辑" label-width="15%">
              <div id="editor" style="margin: 0px auto;width: 90%"></div>
            </el-form-item>
          </el-form>
          <div slot="footer" class="dialog-footer">
            <el-button @click="dialogFormVisible = false">取 消</el-button>
            <el-button type="primary" @click="submit()">确 定</el-button>
          </div>
        </el-dialog>
        <el-dialog :title="viewTitle" :visible.sync="editorVisible" class="el-dialog__body">
          <div v-html="viewData" class="w-e-text"></div>
        </el-dialog>
      </div>
    </div>
  </div>
</template>
<style scoped>

</style>
<script>
import request from "@/utils/request";
import E from "wangeditor";
let editor
function initWangEditor(content) {	setTimeout(() => {
  console.log(editor)
  if(editor){
    editor.destroy();
    editor = null;
  }
  if (!editor) {
    editor = new E('#editor')
    editor.config.placeholder = '请输入内容'
    editor.config.uploadFileName = 'file'
    editor.config.uploadImgServer = 'http://localhost:8080/api/files/wang/upload'
    editor.create()
    editor.txt.html(content)
  }
}, 0)}
export default {
  //name: "AdminView",
  data() {
    return {
      user: localStorage.getItem("user") ? JSON.parse(localStorage.getItem("user")) : {},
      params:{
        pageNum: 1,
        pageSize: 5
      },   //前端封装参数：用于传递分页参数或其他参数
      total: 0,                 //分页数据：共几条
      dialogFormVisible: false, //开启/关闭对话框

      userlist: {},             //用户列表：用于新增时选择用户
      documentlist: {},         //发布列表：用于新增时选择发布

      tableData: {},            //表格数据
      form: {},                 //表单数据
      formin: {},               //提交对象：提交新增/修改分类数据
      userfind: {},             //用户对象：通过用户名查找用户对象数据
      docfind: {},              //编辑对象：通过docid查找编辑对象数据

      editorVisible: false,     //点击查看按钮：打开查看内容对话框
      viewTitle:'',             //点击查看按钮：传递当前行数据 富文本标题
      viewData:'',              //点击查看按钮：传递当前行数据 富文本内容

      editorInstances: {},
    }
  },
  created() {
    this.findBySearch();
    this.findUerList();
    this.user = JSON.parse(localStorage.getItem('user'))
  },
  methods: {
    handleSizeChange(pageSize) {
      this.params.pageSize = pageSize;
      this.findBySearch();
    },    //点击切换分页条数
    handleCurrentChange(pageNum) {
      this.params.pageNum = pageNum;
      this.findBySearch();
    },  //点击跳转当前页码
    reset(){
      this.params = {
        pageNum: 1,
        pageSize: 5,
        name: '',
        phone: ''
      }
      this.findBySearch();
    },                        //点击清空按钮：重置查询条件

    findBySearch(){
      request.get("/category/searchDoceditor",{params:this.params})
          .then(res =>{
            if(res.code === '0'){
              this.tableData = res.data.list;
              this.total = res.data.total;
            }else{
              this.$message.error({message: res.msg, duration: 800});
            }
          })
    },                 //加载全部编辑器内容列表
    findUerList(){
      request.get("/admin").then(res =>{
        if(res.code === '0'){
          this.userlist = res.data;
        }else{
          this.$message.error({message: res.msg, duration: 800});
        }
      })
    },                  //加载用户选项：用于在下拉列表选择用户
    findDocumentList(username) {
      this.userfind = {};
      this.userfind.name = username;
      request.get("/category/findDocByName",{params:this.userfind}).then(res =>{
        if(res.code === '0'){
          this.documentlist = res.data;
        }else{
          this.$message.error({message: res.msg, duration: 800});
        }
      })
    },    //加载编辑选项：用于选择当前用户创建的富文本编辑
    viewEditor(data){
      this.viewTitle = data.doctitle;
      this.viewData = data.doceditorContent;
      this.editorVisible = true;
    },               //点击查看按钮：打开查看内容对话框

    add(){
      this.form = {};
      initWangEditor("");
      this.flag_addORedit = 'add';         //新增标识：add
      this.dialogFormVisible = true;
    },                             //点击新增按钮：打开新增富文本编辑对话框，清空已有内容
    edit(obj) {
      this.form = obj;
      this.formin.id = obj.id;
      this.flag_addORedit = 'edit';         //编辑标识：edit
      initWangEditor( obj.doceditorContent);
      this.dialogFormVisible = true;
    },                        //点击编辑按钮：打开修改富文本编辑对话框，传递已有内容
    async submit(){
      if(this.flag_addORedit == 'add'){
        this.formin.id = '';
      }
      await this.findUserByName(this.form.username);    //通过用户名获取用户对象：通过表单用户名查询用户对象，用于获取用户ID
      this.formin.userid = this.userfind.id;            //userid
      this.formin.username = this.form.username;        //username
      this.formin.docid = this.form.docid;              //docid
      if(editor){
        this.formin.doceditorContent = editor.txt.html();
      }                                   //doceditorContent
      await this.findDocById(this.form.docid);          //通过ID获取富文本编辑对象：通过表单docid查询编辑对象，用于获取编辑title
      this.formin.doctitle = this.docfind.title;        //doctitle
      console.log('formin--------',this.formin);
      request.post("/category/adddoceditor", this.formin).then(res => {
        if (res.code === '0') {
          this.$message.success({message: '操作成功', duration: 800});
          this.dialogFormVisible = false;
          this.findBySearch();
        } else {
          this.$message.error({message: res.msg, duration: 800});
        }
      })
    },                    //点击提交按钮：通过用户名、分类名向数据库分类表新增一条记录
    async findUserByName(username){
      this.userfind.name = username;
      await request.get("/admin/findUserByName",{params:this.userfind}).then(res =>{
        if (res.code === '0') {
          this.userfind = res.data;
        }else {
          this.$message.error({message: res.msg, duration: 800});
        }
      })
    },    //通过用户名获取用户对象：通过表单用户名查询用户对象，用于获取用户ID
    async findDocById(docid) {
      this.docfind = {};
      this.docfind.id = docid;
      await request.get("/category/findDocById",{params:this.docfind}).then(res =>{
        if (res.code === '0') {
          this.docfind = res.data;
        }else {
          this.$message.error({message: res.msg, duration: 800});
        }
      })
    },         //通过docid获取富文本编辑对象：通过表单docid查询编辑对象，用于获取编辑标题doctitle
    del(id) {
      request.delete("/category/deldoceditor/" + id).then(res => {
        if (res.code === '0') {
          this.$message.success({message: '删除成功', duration: 800});
          this.findBySearch();
        } else {
          this.$message.error({message: res.msg, duration: 800});
        }
      })
    },                          //点击删除按钮：删除数据库中当前富文本编辑
  }
}
</script>