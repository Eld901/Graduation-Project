<template>
  <div >
    <div class="register-container">
      <nav class="navTo" style="text-align: center;width: 10%;font-size: 13px;color: #00c1ed">
        <router-link to="/" class="textColor" style="text-decoration: none">Home</router-link> |
        <router-link to="/login" class="textColor" style="text-decoration: none">Login</router-link> |
        <router-link to="/register" class="textColor" style="text-decoration: none">Register</router-link>
      </nav>
      <div style="width: 400px; height: 400px; margin: 150px auto; background-color:rgba(0,215,236,0.17); border-radius: 10px">
        <div style="width: 100%; height: 100px; font-size: 30px; line-height: 100px; text-align: center; color: #00c1ed">注册</div>
        <div style="margin-top: 25px; text-align: center; height: 320px;">
          <el-form :model="admin">
            <el-form-item>
              <el-input v-model="admin.name" prefix-icon="el-icon-user" style="width: 80%" placeholder="请输入用户名"></el-input>
            </el-form-item>
            <el-form-item>
              <el-input v-model="admin.password" show-password prefix-icon="el-icon-lock" style="width: 80%" placeholder="请输入密码"></el-input>
            </el-form-item>
            <el-form-item>
              <el-select v-model="admin.role" placeholder="请选择" style="width: 80%">
                <el-option label="教师" value="ROLE_TEACHER"></el-option>
                <el-option label="学生" value="ROLE_STUDENT"></el-option>
              </el-select>
            </el-form-item>
            <el-form-item>
              <el-button style="width: 80%; margin-top: 10px" type="primary" @click="register()">注册</el-button>
            </el-form-item>
            <div style="color:#015c8c;text-align: center">
              已有账号？<a href="javascript:void(0)" style="color: #006fff;text-decoration: none" @click="navLogin">点击登录</a>
            </div>
          </el-form>
        </div>
      </div>
    </div>

  </div>
</template>
<style scoped>
.register-container {
  background-size: 50%;background-image: url("@/assets/login_bg2.png");
  display: flex;flex-direction: column;
}
</style>
<script>
import request from "@/utils/request";

export default {
  name: "Register",
  data() {
    return {
      admin:{
        //name: '',
        //password: ''
      }
    }
  },
  // 页面加载的时候，做一些事情，在created里面
  created() {
  },
  methods: {
    navLogin() {
      this.$router.push("/login")
    },
    register(){
      if(this.admin.role === 'ROLE_TEACHER'){
        this.admin.role = 'ROLE_TEACHER';
      }else {
        this.admin.role = 'ROLE_STUDENT';
      }
      request.post("/admin/register", this.admin).then(res =>{
        if(res.code === '0'){
          this.$message.success({message: '注册成功', duration: 800});
          // this.$message({message: '注册成功', type: 'success'});
          this.$router.push("/login");
        }else {
          this.$message.error({message: res.msg, duration: 800});
          // this.$message({message: res.msg, type: 'error'});
        }
      })
    }

  }
}
</script>