<template>
  <div class="admin-container">
    <div style="display: flex">
      <div style="flex: 1;">
        <div style="margin-bottom: 15px; font-weight: bold; font-size: 18px">系统日志</div>
        <el-collapse v-model="activeName" accordion>
          <el-collapse-item v-for="(item,index) in data" :key="index" :title="`${item.time} ${item.username}`" :name="item.id">
            <div style="padding: 0 20px">操作时间：{{ item.time }}</div>
            <div style="padding: 0 20px">操作用户：{{ item.username }}</div>
            <div style="padding: 0 20px">操作IP：{{ item.ip }}</div>
            <div style="padding: 0 20px">操作内容：{{ item.content }}</div>
          </el-collapse-item>
        </el-collapse>
      </div>
    </div>
  </div>
</template>
<script>

import request from "@/utils/request";
import * as echarts from "echarts";

export default {
  name: 'HomeLogView',
  data() {
    return {
      activeName: '1',
      data: []// 公告：id、name标题、time、content //日志：id、username、time、content用户操作、ip
    };
  },
  mounted() {
    this.findNotice();
  },
  methods: {
    findNotice(){
      request.get("/log").then(res =>{
        if(res.code === '0'){
          this.data = res.data;
          this.activeName = res.data[0].id;// 默认选中开启第一个
        }else{
          this.$message.error({message: res.msg, duration: 800});
          // this.$message.error(res.msg);
        }
      })
    },
  }
}
</script>