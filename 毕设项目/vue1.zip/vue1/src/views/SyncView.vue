<template>
  <div class="admin-container">
    <div class="sync-container">
      <div class="sync-body">
        <div class="sync-bottom">
          <div class="sync-left">
            <div class="sync-left-top">
              <div class="sync-li-icon" style="font-size: 15px;margin:auto 5px;display: flex;justify-content: space-between;align-items: center;">
                <div>协同页面</div>
                <el-dropdown trigger="click">
                    <span class="el-dropdown-link">
                      <i class="el-icon-circle-plus li-i"></i>
                    </span>
                  <el-dropdown-menu>
                    <el-dropdown-item><div @click="openAddSync">新建协同 <i class="el-icon-s-custom"></i></div></el-dropdown-item>
                    <el-dropdown-item><div @click="openJoinSync">加入协同 <i class="el-icon-user"></i></div></el-dropdown-item>
                  </el-dropdown-menu>
                </el-dropdown>
              </div>
            </div>
            <div style="height: 10px"></div>
            <div style="font-size: 13px;color: #aec6d3">------------------我创建的协同</div>
            <div class="item-group" v-for="(isync,indexsync) in synclist" :key="indexsync"
                 @click="viewSync(isync.id)">
              <div class="sync-left-item">
                <div class="sync-li-first">
                  <i class="el-icon-tickets"></i>
                  <div class="sync-li-title">{{isync.title}}</div>
                </div>
                <div class="sync-li-icon">
                  <i class="el-icon-view sync-li-i" style="margin-right: 2px" @click="viewSyncId(isync.id,isync.authorname)"></i>
                  <el-popconfirm title="确定删除协同编辑吗？" @confirm="deleteSync(isync.id)">
                    <template #reference>
                      <i class="el-icon-delete-solid sync-li-i"></i>
                    </template>
                  </el-popconfirm>
                </div>
              </div>
              <div class="sync-li-subtitle" style="font-size: 14px"><i class="el-icon-s-custom"></i>{{user.name}}</div>
              <div class="sync-left-subitem"
                   v-if="isyncgroup.syncid==isync.id"
                   v-for="(isyncgroup,indexsyncgroup) in syncUserGroup" :key="indexsyncgroup">
                <div class="sync-li-subtitle"><i class="el-icon-user-solid"></i>{{isyncgroup.username}}</div>
              </div>
            </div>
            <div style="height: 10px"></div>
            <div style="height: 10px"></div>
            <div style="font-size: 13px;color: #aec6d3">------------------我加入的协同</div>
            <div class="item-group" v-for="(isyncjoin,indexsyncjoin) in syncJoinlist" :key="indexsyncjoin"
                 @click="viewJoinSync(isyncjoin.joinid)">
              <div class="sync-left-item">
                <div class="sync-li-first">
                  <i class="el-icon-tickets"></i>
                  <div class="sync-li-title">{{isyncjoin.jointitle}}</div>
                </div>
                <div class="sync-li-icon">
                  <i class="el-icon-view sync-li-i" style="margin-right: 2px" @click="viewSyncId(isyncjoin.joinid,isyncjoin.joinauthorname)"></i>
                  <el-popconfirm title="确定退出协同编辑吗？" @confirm="quitSync(isyncjoin.joinid)">
                    <template #reference>
                      <i class="el-icon-remove sync-li-i"></i>
                    </template>
                  </el-popconfirm>
                </div>
              </div>
              <div class="sync-li-subtitle" style="font-size: 14px"><i class="el-icon-s-custom"></i>{{isyncjoin.joinauthorname}}</div>
              <div class="sync-left-subitem"
                   v-if="isyncgroup.syncid==isyncjoin.joinid"
                   v-for="(isyncgroup,indexsyncgroup) in syncUserGroup" :key="indexsyncgroup">
                <div class="sync-li-subtitle"><i class="el-icon-user-solid"></i>{{isyncgroup.username}}</div>
              </div>
            </div>
          </div>
          <div class="sync-main">
            <div v-if="isync.id == sync_showid"
                 v-for="(isync,indexsync) in synclist" :key="indexsync"
                 class="sync-main-body">
              <div style="margin-bottom: 15px">{{isync.title}}</div>
              <textarea :value="socketContent" @input="sendEditMessage(isync.id,$event.target.value)" style="width: 100%;height: 50vh"></textarea>
            </div>
            <div v-if="isyncjoin.joinid == syncjoin_showid"
                 v-for="(isyncjoin,indexsyncjoin) in syncJoinlist" :key="indexsyncjoin"
                 class="sync-main-body">
              <div style="margin-bottom: 15px">{{isyncjoin.jointitle}}</div>
              <textarea :value="socketContent" @input="sendEditMessage(isyncjoin.joinid,$event.target.value)" style="width: 100%;height: 50vh"></textarea>
            </div>
          </div>
        </div>
      </div>
      <el-dialog :visible.sync="open_addSync" >
        <el-form>
          <div style="font-size: 18px;margin-bottom: 10px">新建协同编辑</div>
          <div style="display: flex;flex-direction: row;align-items: center">
            <el-input v-model="sync_title" placeholder="请输入协同标题"></el-input>
            <div @click="saveSync"
                 class="sync-replypoint-btn"
                 style="margin-left: 10px;width:80px;height: 32px;line-height: 32px">
              提交
            </div>
          </div>
        </el-form>
      </el-dialog>
      <el-dialog :visible.sync="open_joinSync" >
        <el-form>
          <div style="font-size: 18px;margin-bottom: 10px">加入协同编辑</div>
          <div style="display: flex;flex-direction: row;align-items: center">
            <el-input v-model="syncJoinid" placeholder="请输入协同号"></el-input>
            <div @click="saveSyncJoin(syncJoinid)"
                 class="sync-replypoint-btn"
                 style="margin-left: 10px;width:80px;height: 32px;line-height: 32px">
              提交
            </div>
          </div>
        </el-form>
      </el-dialog>
      <el-dialog :visible.sync="view_infoOfSync" >
        <el-form>
          <div style="font-size: 18px;margin-bottom: 10px">协同号：{{syncid}}</div>
          <div style="font-size: 18px;margin-bottom: 10px">创建人：{{syncauthor}}</div>
        </el-form>
      </el-dialog>
    </div>
  </div>
</template>
<style>
.sync-container {
  width: 100%;
  height: 100%;
}

.sync-body {
  background-color: rgba(0, 107, 163, 0);
  height: 80vh;
  width: 100%;
  //display: flex;
  //flex-direction: column;
  //justify-content: space-between;
}

.sync-bottom {
  background-color: rgba(0, 107, 163, 0);
  height: 100%;
  width: 100%;
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  position: relative;
}

.sync-left {
  border: 1px solid rgb(195, 218, 230);
  width: 14%;
  height: 100%;
  overflow: auto;
  text-align: left;
}

.sync-left-top {
  height: 20px;
  border-bottom: 1px solid rgb(195, 218, 230);
  text-align: right;
}

.sync-left-item {
  color: #00c1ed;
  font-size: 12px;
  height: 20px;
  display: flex;
  flex-direction: row;
  justify-content: space-between;
}

.sync-left-subitem {
  color: rgb(9, 123, 147);
  font-size: 15px;
  height: 20px;
  display: flex;
  flex-direction: row;
  justify-content: space-between;
}

.sync-li-first {
  margin-left: 5px;
  display: flex;
  flex-direction: row;
  align-items: center;
}

.sync-li-title {
  //width: 123px;
  margin-left: 5px;
  //width: 75%;
  overflow: hidden;
}

.sync-li-subtitle {
  width: 135px;
  //width: 70%;
  margin-left: 10px;
  overflow: hidden;
}

.sync-li-icon {
  font-size: 14px;
  margin-right: 5px;
  color: #a38200;
}

.sync-li-i {
  color: #a38200;
}

.sync-li-i:hover {
  color: #00c1ed;
}

.sync-ed-icon {
  color: #42b983;
}

.sync-ed-icon:hover {
  color: #00c1ed;
}

.sync-left-item:hover {
  cursor: pointer;
  background-color: rgba(197, 220, 232, 0.3);
}

.sync-left-subitem:hover {
  cursor: pointer;
  background-color: rgba(197, 220, 232, 0.3);
}

.sync-replypoint-btn {
  border-radius: 5px;
  //border: 1px solid rgb(9, 123, 147);
  border: 1px solid #00c1ed;
  width: 50px;
  height: 25px;
  line-height: 25px;
  color: #00c1ed;
  //background-color: #8cd4e1a1;
  text-align: center;
  font-size: 14px;
}

.sync-replypoint-btn:hover {
  cursor: pointer;
  color: #ffffff;
  background-color: #d6e7fa;
  transition: background-color 0.3s ease;
  border-color: #d6e7fa;
}

.replybtm-btn {
  border-radius: 5px;
  //border: 1px solid rgb(9, 123, 147);
  border: 1px solid #c5dce8;
  width: 50px;
  height: 25px;
  line-height: 25px;
  color: rgb(9, 123, 147);
  background-color: rgba(140, 212, 225, 0);
  text-align: center;
  font-size: 14px;
}

.replybtm-btn:hover {
  cursor: pointer;
  color: #ffffff;
  background-color: #d6e7fa;
  transition: background-color 0.3s ease;
  border-color: #d6e7fa;
}

.test-newer-main {
  //width: 85.5%;
  //height: 100%;
  //overflow: auto;
  //border: 1px solid rgb(195, 218, 230);
}

.sync-main {
  position: absolute;
  margin-left: 185.26px;
  width: 1102.9px;
  height: 100%;
  overflow: auto;
  border: 1px solid rgb(195, 218, 230);
}

.sync-main-body {
  border: 1px #00c1ed solid;
  border-radius: 15px;
  margin: 20px;
  padding: 20px;

}

.sync-main-body img,
.sync-main-body video {
  width: 100%;
}

.sync-main-body iframe {
  width: 100%;
  height: 500px;
}
</style>
<script>
import {Upload} from "element-ui";
import request from "@/utils/request";
import E from 'wangeditor'
let editor
function initWangEditor(content) {	setTimeout(() => {
  if (editor) {
    console.log('editor destroy---'+editor);
    editor.destroy(); // 如果编辑器已存在，先销毁
    editor = null;
  }
  if (!editor) {//如果编辑器不存在，才创建
    console.log('editor none---'+editor);//undefined
    editor = new E('#editor')
    console.log('editor exist---'+editor);//object
    editor.config.placeholder = '请输入内容'
    editor.config.uploadFileName = 'file'
    editor.config.uploadImgServer = 'http://localhost:8080/api/files/wang/upload'
    editor.create()
  }
  if (content) {//如果有传递值不为空，则将内容作为初始化内容
    editor.txt.html(content)
  }
}, 0)
}

export default {
  computed: {
    Upload() {
      return Upload
    }
  },
  data() {
    return {
      user: localStorage.getItem("user") ? JSON.parse(localStorage.getItem("user")) : {},
      open_addSync:  false,   //打开新增协同对话框
      sync_title: '',         //定义协同标题
      sync:  {},              //新增的协同实体类：协同id、创始用户id、创始用户名、协同标题、协同内容
      syncjoin:  {},              //新增的协同实体类：协同id、创始用户id、创始用户名、协同标题、协同内容
      synclist:  {},          //全部协同列表实体类：根据登录用户查询当前登录用户下的全部协同，返回全部协同列表

      open_joinSync:  false,  //打开加入协同对话框
      syncJoinid:  '',        //打开加入协同：加入协同号
      syncJoin:  {},          //用户加入协同实体类：加入对象id、协同id、协同标题、成员id、成员名
      syncJoinlist:  {},      //加入协同列表实体类：用户加入的协同集合
      syncUser:  {},          //协同成员实体类：加入对象id、协同id、协同标题、成员id、成员名
      syncUserGroup:  {},     //协同成员列表实体类：协同成员集合

      view_infoOfSync:  false,//打开查看协同号对话框
      syncid:  0,             //打开查看协同号：查看协同号
      syncauthor: '',         //打开查看协同号：查看创建人
      sync_showid: 'x',       //点击编辑创建协同
      syncjoin_showid: 'x',   //点击编辑加入协同

      socketContent: '',          //socket内容
      socketId: '',               // socket标识，假设每个文档有一个唯一的 ID
      socket: null,               //socket对象
      socketMessageSend: '',      //socket消息 socketId、'update'、content
      socketMessageReceive: '',   //socket消息 socketId、'update'、content
      syncMessage: {},          //socket消息对象，保存到数据库

    };
  },
  created() {
    this.user = JSON.parse(localStorage.getItem('user'));
    this.findSyncList();
    this.findSyncJoinList();
    this.findSyncUserGroup();
  },
  mounted() {
    // const documentId = 'doc123';
    // this.socket = new WebSocket(`ws://localhost:8080/ws/document?documentId=${documentId}`);// 创建 WebSocket 连接
    this.socket = new WebSocket('ws://localhost:8080/ws/document');
    // this.socket.onmessage = (event) => {
    //   // 处理接收到的文档编辑消息
    //   console.log('event---{}' , event);
    //   console.log('content---' + event.data);
    //   this.socketContent = event.data;
    // };
  },
  methods: {
    //新建协同：sync [id authorid authorname title]
    findSyncList() {
      request.get("/sync/findSyncList", {params: this.user}).then(res => {
        if (res.code === '0') {
          this.synclist = res.data;
        } else {
          this.$message.error({message: res.msg, duration: 800});
        }
      })
    },                   //加载全部新建的协同列表
    openAddSync() {
      this.open_addSync = true;
    },                    //点击新建按钮，打开新建协同对话框
    saveSync() {
      this.sync = {};                         //初始化清空
      this.sync.authorid = this.user.id;      //authorid
      this.sync.authorname = this.user.name;  //authorname
      this.sync.title = this.sync_title;      //title
      request.post("/sync/saveSync", this.sync).then(res => {
        if (res.code === '0') {
          this.$message.success({message: '操作成功', duration: 800});
          this.findSyncList();
          this.open_addSync = false;
        } else {
          this.$message.error({message: res.msg, duration: 800});
        }
      })
    },                       //点击提交按钮，保存新建的协同到数据库，关闭新建协同对话框，调用查询加载全部新建的协同列表
    viewSyncId(syncid,syncauthor) {
      this.syncid = syncid;
      this.syncauthor = syncauthor;
      this.view_infoOfSync = true;
    },    //点击查看按钮，打开查看协同号对话框

    //加入协同：syncjoin [id userid username joinid joinauthorid joinauthorname jointitle]
    //协同成员：syncuser [id syncid synctitle userid username]
    async findSyncJoinList() {
      await request.get("/sync/findSyncJoinList", {params: this.user}).then(res => {
        if (res.code === '0') {
          this.syncJoinlist = res.data;
        } else {
          this.$message.error({message: res.msg, duration: 800});
        }
      })
    },          //加载全部加入的协同列表(当前用户)
    async findSyncUserGroup() {
      await request.get("/sync/findSyncUserGroup", {params: this.syncUser}).then(res => {
        if (res.code === '0') {
          this.syncUserGroup = res.data;
        } else {
          this.$message.error({message: res.msg, duration: 800});
        }
      })
    },         //加载全部加入的协同成员列表(当前协同)
    openJoinSync() {
      this.open_joinSync = true
    },                    //点击加入按钮，打开加入协同对话框
    async saveSyncJoin(syncJoinid) {
      this.syncJoin.userid  = this.user.id;                 //userid
      this.syncJoin.username  = this.user.name;             //username
      this.syncJoin.joinid  = syncJoinid;                   //joinid
      await this.findSyncById(syncJoinid);                  //获取创建协同对象：根据协同号，查询创建协同对象，用于获取加入协同属性
      this.syncJoin.jointitle  = this.sync.title;           //jointitle
      this.syncJoin.joinauthorid = this.sync.authorid;      //joinauthorid
      this.syncJoin.joinauthorname = this.sync.authorname;  //joinauthorname
      await request.post("/sync/saveSyncJoin", this.syncJoin).then(res => {
        if (res.code === '0') {
          this.$message.success({message: '操作成功', duration: 800});
          this.saveSyncUser(syncJoinid);
          this.findSyncJoinList();
        } else {
          this.$message.error({message: res.msg, duration: 800});
        }
      })
      this.open_joinSync = false;
    },    //点击提交按钮时：1. 保存加入协同到数据库，关闭加入协同对话框，调用查询加载全部加入协同列表
    async saveSyncUser(syncJoinid) {
      this.syncUser = {};                           //初始化清空
      this.syncUser.userid  = this.user.id;         //userid
      this.syncUser.username  = this.user.name;     //username
      this.syncUser.syncid  = syncJoinid;           //syncid
      await this.findSyncById(syncJoinid);          //获取创建协同对象：根据协同号，查询创建协同对象，用于获取加入协同属性
      this.syncUser.synctitle  = this.sync.title;   //synctitle

      await this.findSyncJoinByJoinId(syncJoinid);
      this.syncUser.syncjoinid  = this.syncjoin.id;     //syncjoinid
      request.post("/sync/saveSyncUser", this.syncUser).then(res => {
        if (res.code === '0') {
          this.findSyncUserGroup();
        } else {
          this.$message.error({message: res.msg, duration: 800});
        }
      })
    },    //点击提交按钮后：2. 保存协同成员到数据库，调用查询加载全部协同成员
    async findSyncById(syncid) {
      this.sync = {};         //初始化清空
      this.sync.id = syncid;  //syncid
      await request.get("/sync/findSyncById", {params: this.sync}).then(res => {
        if (res.code === '0') {
          this.sync = res.data;
        } else {
          this.$message.error({message: res.msg, duration: 800});
        }
      })
    },        //获取创建协同对象：根据协同号，查询创建协同对象，用于获取加入协同属性
    async findSyncJoinByJoinId(syncid) {
      this.syncjoin = {};         //初始化清空
      this.syncjoin.joinid = syncid;  //joinid
      await request.get("/sync/findSyncJoinByJoinId", {params: this.syncjoin}).then(res => {
        if (res.code === '0') {
          this.syncjoin = res.data;
        } else {
          this.$message.error({message: res.msg, duration: 800});
        }
      })
    },        //获取创建协同对象：根据协同号，查询创建协同对象，用于获取加入协同属性

    // 协同编辑：syncmessage [id syncid action content]
    async viewSync(syncid) {
      this.sync_showid = syncid;                //打开创建协同编辑器
      this.syncjoin_showid='x';                 //关闭加入协同编辑器
      await this.findSyncMessageById(syncid);   //查找协同内容：根据输入协同号，获取协同内容对象，用于获取协同内容
      if(this.sync){                            //成功获取对象
        this.socketContent = this.sync.content; //传递内容
      }else{                                    //获取对象失败
        this.socketContent = '';                //内容置空
      }
    },                      //点击选中创建协同，打开创建协同ID对应的编辑器，并传递内容
    async viewJoinSync(syncJoinid) {
      this.syncjoin_showid = syncJoinid;            //打开加入协同编辑器
      this.sync_showid='x';                         //关闭创建协同编辑器
      await this.findSyncMessageById(syncJoinid);   //查找协同内容：根据输入协同号，获取协同内容对象，用于获取协同内容
      if(this.sync){                                //成功获取对象
        this.socketContent = this.sync.content;     //传递内容
      }else{                                        //获取对象失败
        this.socketContent = '';                    //内容置空
      }
    },              //点击选中加入协同，打开加入协同ID对应的编辑器，并传递内容
    async findSyncMessageById(syncid) {
      this.sync = {};             //初始化清空
      this.sync.syncid = syncid;  //syncid
      await request.get("/sync/findSyncMessageById", {params: this.sync}).then(res => {
        if (res.code === '0') {
          this.sync = res.data;
        } else {
          this.$message.error({message: res.msg, duration: 800});
        }
      })
    },           //获取协同消息对象：根据当前协同号，查询协同消息对象，用于获取协同消息id
    sendEditMessage(socketId,inputvalue) {
      if (this.socket.readyState === WebSocket.OPEN) {                      // 1 == 1
        this.socketId = socketId;
        this.socketMessageSend = `${this.socketId},update,${inputvalue}`;   //socketId、'update'、content
        this.socket.send(this.socketMessageSend);
      }     //1. 发送到后端协同消息处理接口
      this.saveEditMessage(socketId,inputvalue);               //2. 保存编辑内容到数据库
    },        //编辑协同内容：1. 发送到后端协同消息处理接口 2. 保存编辑内容到数据库
    async saveEditMessage(socketId,inputvalue) {
      this.syncMessage.syncid = socketId;       //syncid
      this.syncMessage.action = 'update';       //action
      this.syncMessage.content = inputvalue;    //content
      await request.post("/sync/saveSyncMessage", this.syncMessage).then(res => {
        if (res.code === '0') {
          this.$message.success({message: '操作成功', duration: 800});
        } else {
          this.$message.error({message: res.msg, duration: 800});
        }
      })   //保存编辑内容到数据库
      // this.socket.onmessage = (event) => {
      //   this.socketMessageReceive = event.data.split(',');
      //   this.receivedSocketId = Number(this.socketMessageReceive[0]);
      //   this.action = this.socketMessageReceive[1];
      //   this.receivedContent = this.socketMessageReceive[2];
      //   console.log('Received socketId:', this.receivedSocketId);
      //   console.log('Action:', this.action);
      //   console.log('Received content:', this.receivedContent);
      //   this.socketContent = this.receivedContent;
      // };                                              //处理后端返回的协同消息
    },  //保存协同内容：1. 保存编辑内容到数据库 2. 处理后端返回的协同消息

    // 删除协同 退出协同
    deleteSync(syncid) {
      this.deleteSyncMessage(syncid);                                       //1. 删除协同内容
      this.quitSync(syncid);                                                //2. 退出加入协同
      request.delete("/sync/deleteSync/" + syncid).then(res => {
        if (res.code === '0') {
          this.$message.success({message: "删除成功", duration: 800});
          this.findSyncUserGroup();
          this.findSyncJoinList();
          this.findSyncList();
        } else {
          this.$message.error({message: res.msg, duration: 800});
        }
      })   //3. 删除创建协同
    },                //点击删除按钮: 1. 删除协同内容 2. 退出加入协同 3. 删除创建协同
    deleteSyncMessage(syncid) {
      request.delete("/sync/deleteSyncMessage/" + syncid).then(res => {
        if (res.code === '0') {
        } else {
          this.$message.error({message: res.msg, duration: 800});
        }
      })
    },         //删除协同内容
    quitSync(syncid) {
      request.delete("/sync/deleteSyncUser/" + syncid).then(res => {
        if (res.code === '0') {
          request.delete("/sync/deleteSyncJoin/" + syncid).then(res => {
            if (res.code === '0') {
              this.$message.success({message: "退出成功", duration: 800});
              this.findSyncUserGroup();
              this.findSyncJoinList();
            } else {
              this.$message.error({message: res.msg, duration: 800});
            }
          })//2. 移除加入协同
        } else {
          this.$message.error({message: res.msg, duration: 800});
        }
      })//1. 移除协同成员
    },                  //点击退出按钮：1. 移除协同成员 2. 移除加入协同

    //附加功能实现
    // 移除加入成员
    // 点击进入个人中心
  },
  beforeDestroy() {
    if (this.socket) {
      this.socket.close();
    }
  },
};
</script>


