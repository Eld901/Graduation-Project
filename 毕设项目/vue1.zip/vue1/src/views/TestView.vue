<template>
  <div class="editor">
<!--    <textarea v-model="content" @input="sendEditMessage"></textarea>-->
<!--    <textarea v-model="content" @input="sendEditMessage"></textarea>-->
    <textarea v-model="content" @input="handleInput"></textarea>
  </div>
</template>

<script>
export default {
  data() {
    return {
      content: '',// 当前文档的内容
      socket: null,// WebSocket 实例
    };
  },
  methods: {
    handleInput(e) {
      const operation = {
        type: 'insert',// 操作类型为插入
        content: e.target.value, // 操作内容为当前文本框的值
        position: this.content.length,// 操作位置为当前文档内容的长度
        timestamp: Date.now(),// 操作时间戳
        documentId: 'doc123' // 假设文档 ID 是 doc123
      };
      this.socket.send(JSON.stringify(operation));// 假设文档 ID 是 doc123
      console.log('s;',this.socket)
    },
    handleWebSocketMessage(event) {
      console.log('e;',JSON.parse(event.data))
      const operation = JSON.parse(event.data);// 解析接收到的操作
      this.applyOperation(operation);// 应用操作到本地文档：调用 applyOperation 方法，将操作应用到本地文档中。
    },
    applyOperation(operation) {
      if (operation.type === 'insert') {
        this.content = operation.content ;
      }
    },// 应用操作到本地文档
  },
  mounted() {
    const documentId = 'doc123';
    this.socket = new WebSocket(`ws://localhost:8080/ws/document?documentId=${documentId}`);// 创建 WebSocket 连接
    this.socket.onmessage = this.handleWebSocketMessage;// 设置消息处理函数
  },
};
</script>

<style scoped>
.editor {
  margin: 20px;
}

textarea {
  width: 100%;
  height: 200px;
}
</style>