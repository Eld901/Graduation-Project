<template>
  <div class="admin-container">
    <div>
      <el-input v-model="params.userid" style="width: 200px; margin-right: 10px" placeholder="用户ID"></el-input>
      <el-input v-model="params.username" style="width: 200px; margin-right: 10px" placeholder="请输入用户名"></el-input>
      <el-button type="warning" @click="findBySearch()">查询</el-button>
      <el-button type="warning" @click="reset()">清空</el-button>
    </div>
    <div>
      <el-table :data="tableData" style="width: 100%; margin: 15px 0px;" align="center">
        <el-table-column prop="userid" label="用户ID" width="100"></el-table-column>
        <el-table-column prop="username" label="用户名" width="100"></el-table-column>
        <el-table-column prop="img" label="用户头像" width="100">
          <template slot-scope="scope">
            <el-image
                style="width: 50px; height: 50px; border-radius: 15px;display: flex;align-items: center;justify-content: center"
                :src="'http://localhost:8080/api/files/' + scope.row.img"
                :preview-src-list="['http://localhost:8080/api/files/' + scope.row.img]">
              <div slot="error" class="image-slot">
                <i class="el-icon-picture-outline"></i>
              </div>
            </el-image>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <div class="block">
      <el-pagination
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
          :current-page="params.pageNum"
          :page-sizes="[5, 10, 15, 20]"
          :page-size="params.pageSize"
          layout="total, sizes, prev, pager, next"
          :total="total">
      </el-pagination>
    </div>
  </div>
</template>
<script>
import request from "@/utils/request";
export default {
  //name: "AdminView",
  data() {
    return {
      params:{
        userid: '',
        username: '',
        pageNum: 1,
        pageSize: 5
      },
      files: {},
      tableData: [],
      total: 0,
    }
  },
  created() {
    this.findBySearch();
    // this.findByUser();
  },
  methods: {
    getTableRow(row, index) {

    },
    findBySearch(){
      request.get("/img/search",{params:this.params}).then(res =>{
        if(res.code === '0'){
          console.log(res.data.list);
          this.tableData = res.data.list;
          this.total = res.data.total;
        }else{
          this.$message.error({message: res.msg, duration: 800});
        }
      })
    },
    reset(){
      this.params = {
        pageNum: 1,
        pageSize: 5,
        content: '',
        username: ''
      }
      this.findBySearch();
    },
    handleSizeChange(pageSize) {
      this.params.pageSize = pageSize;
      this.findBySearch();
    },
    handleCurrentChange(pageNum) {
      this.params.pageNum = pageNum;
      this.findBySearch();
    },
    del(id) {
      request.delete("/img/" + id).then(res => {
        if (res.code === '0') {
          this.$message.success({message: '删除成功', duration: 800});
          // this.$message({message: '删除成功', type: 'success'});
          this.findBySearch();
        } else {
          this.$message.error({message: res.msg, duration: 800});
          // this.$message.error(res.msg);
        }
      })
    }
  }
}
</script>