<template>
  <div class="layout-container">
    <div class="header arrowDown" style="width: 100%;font-size: 13px;">
      <nav class="navTo" style="text-align: center;width: 10%;font-size: 13px;color: #00c1ed">
        <router-link to="/" class="textColor" style="text-decoration: none">Home</router-link> |
        <router-link to="/login" class="textColor" style="text-decoration: none">Login</router-link> |
        <router-link to="/register" class="textColor" style="text-decoration: none">Register</router-link>
      </nav>
      <div class="textColor hoverRotate"
           style="width: 80%;text-align: center;font-size:13px"
           :style="{ transform: `rotate(${rotation}deg)` }"
           @mouseenter="showNavtopHover"
           @click="showNavtopClick">
        <i class="el-icon-arrow-down"></i>
      </div>
      <div class="loginUser" style="text-align: center;width: 10%;font-size: 13px;">
        <el-dropdown>
          <span class="el-dropdown-link textColor" style="font-size: 13px">
            {{ user.name }}
          </span>
          <el-dropdown-menu>
            <el-dropdown-item><div @click="logout">退出登录</div></el-dropdown-item>
            <el-dropdown-item><div @click="tomypage">个人中心</div></el-dropdown-item>
          </el-dropdown-menu>
        </el-dropdown>
      </div>
    </div>
    <div class="floating">
      <div class="floatingScroll hoverScroll" @click="scrollToTop" v-show="show_scroll">
        <i class="el-icon-arrow-up"></i>
      </div>
      <div class="floatingGroup" @click="showNavsideClick">
        <img class="hoverRotate" src="@/assets/login_bg3.png" alt="首页" style="height: 40px;">
        <!--        <span id="toggle-btn" class="toggle-btn">☰</span>-->
      </div>
      <transition name="el-zoom-in-top">
        <div class="navtop-content" v-show="show_navbartop">
          <el-menu
              mode="horizontal" :default-active="$route.path" router
              background-color="#FFFFFF00" text-color="#00c1ed" active-text-color="rgb(172, 217, 241)">
<!--            <el-menu-item index="/"><span slot="title">首页展示</span></el-menu-item>-->
<!--            <el-menu-item index="/new2"><span slot="title">新建页面</span></el-menu-item>-->
<!--            <el-menu-item index="/mypage">个人中心</el-menu-item>-->
<!--            <el-menu-item index="/sync">协同页面</el-menu-item>-->
<!--            <el-menu-item index="/home"><span slot="title">系统公告</span></el-menu-item>-->
<!--            <el-menu-item index="/admin" v-if="user.role === 'ROLE_ADMIN'">用户管理</el-menu-item>-->

<!--            <el-menu-item index="/test">测试页面</el-menu-item>-->
            <el-menu-item index="/apublish">自定义分类</el-menu-item>
            <el-menu-item index="/apublish2">自定义上传</el-menu-item>
            <el-submenu index="1">
              <template slot="title"><span>富文本编辑</span></template>
              <el-menu-item-group >
                <el-menu-item index="/apublish3">创建富文本编辑</el-menu-item>
                <el-menu-item index="/apublish4">修改编辑器内容</el-menu-item>
              </el-menu-item-group>
            </el-submenu>
<!--            <el-menu-item index="/apublish3">富文本发布</el-menu-item>-->
<!--            <el-menu-item index="/apublish4">富文本编辑</el-menu-item>-->
            <el-menu-item index=""></el-menu-item>
            <el-submenu index="2">
              <template slot="title"><span>协同创建管理</span></template>
              <el-menu-item-group >
                <el-menu-item index="/async">协同创建管理</el-menu-item>
                <el-menu-item index="/async4">协同编辑管理</el-menu-item>
              </el-menu-item-group>
            </el-submenu>
            <el-submenu index="3">
              <template slot="title"><span>协同加入管理</span></template>
              <el-menu-item-group >
                <el-menu-item index="/async2">协同加入管理</el-menu-item>
                <el-menu-item index="/async3">协同成员管理</el-menu-item>
              </el-menu-item-group>
            </el-submenu>
<!--            <el-menu-item index="/async">协同创建管理</el-menu-item>-->
<!--            <el-menu-item index="/async4">协同编辑管理</el-menu-item>-->
<!--            <el-menu-item index="/async2">协同加入管理</el-menu-item>-->
<!--            <el-menu-item index="/async3">协同成员管理</el-menu-item>-->
            <el-menu-item index=""></el-menu-item>
            <el-submenu index="4">
              <template slot="title"><span>用户信息管理</span></template>
              <el-menu-item-group >
                <el-menu-item index="/admin">用户信息管理</el-menu-item>
                <el-menu-item index="/img">用户头像管理</el-menu-item>
              </el-menu-item-group>
            </el-submenu>
<!--            <el-menu-item index="/admin">用户信息管理</el-menu-item>-->
<!--            <el-menu-item index="/img">用户头像管理</el-menu-item>-->
            <el-menu-item index=""></el-menu-item>
            <el-submenu index="5">
              <template slot="title"><span>系统信息管理</span></template>
              <el-menu-item-group >
                <el-menu-item index="/notice">系统公告管理</el-menu-item>
                <el-menu-item index="/log">系统日志管理</el-menu-item>
              </el-menu-item-group>
            </el-submenu>
<!--            <el-menu-item index="/notice" v-if="user.role === 'ROLE_ADMIN'">公告管理</el-menu-item>-->
<!--            <el-menu-item index="/log">日志管理</el-menu-item>-->

<!--            <el-menu-item index="/book">图书管理</el-menu-item>-->
<!--            <el-menu-item index="/type">图书分类</el-menu-item>-->
<!--            <el-menu-item index="/audit">请假审核</el-menu-item>-->
<!--            <el-menu-item index="/hotel">酒店信息</el-menu-item>-->
<!--            <el-menu-item index="/reserve">预定信息</el-menu-item>-->
          </el-menu>
        </div>
      </transition>
      <transition name="el-zoom-in-top">
        <div class="navside-content" v-show="show_navbarside">
          <div class="custom-btn-colgroup">
            <router-link to="/" class="custom-btn1" style="text-decoration: none">首页展示</router-link>
          </div>
          <div class="custom-btn-colgroup">
            <router-link to="/homeMe" class="custom-btn1">个人中心</router-link>
          </div>
          <div class="custom-btn-colgroup">
            <router-link to="/homenotice" class="custom-btn1" style="text-decoration: none">系统公告</router-link>
            <router-link to="/homelog" class="custom-btn1" style="text-decoration: none">系统日志</router-link>
          </div>
          <div class="custom-btn-colgroup">
            <router-link to="/publish" class="custom-btn1">新增发布</router-link>
          </div>
          <div class="custom-btn-colgroup">
            <router-link to="/sync" class="custom-btn1">协同页面</router-link>
            <router-link to="/test" class="custom-btn1">协同测试</router-link>
          </div>
        </div>
      </transition>
    </div>
    <div class="body" @click="hideNavtopbar">
      <div class="top">
        <div class="roundimg-container">
          <img class="hoverRotate rotating" src="@/assets/login_bg6.png" alt="" style="height: 200px;">
        </div>
      </div>
      <div class="main-content"><router-view/></div>
      <div class="bottom">
        <div style="width: 70%;">
          Design and Implementation of an Integrated and Innovative Rich Text,
          Audio, and Video Document Community Platform Based on Vue+SpringBoot
          <br>
          (融创富文本音视频集合的文档社区平台的设计与实现)
        </div>
      </div>
      <div class="background">
<!--        <img class="hoverRotate anti-rotating" src="@/assets/login_bg6.png" alt="" style="height: 600px;">-->
      </div>
    </div>
  </div>
</template>

<style>
.layout-container {
  height: 100vh;
  display: flex;flex-direction: column;
}
.header {
  display: flex;flex-direction: row;
}
.floatingScroll {
  position: fixed;z-index: 1000;
  bottom: 50%;right: 15%;
  border-radius: 15%;width: 40px;height: 40px;line-height: 40px;
  color: white;background-color: #8cd4e1a1;text-align: center;
  transition: background-color 0.3s ease;
}
.floatingGroup {
  position: fixed;z-index: 1000;
  //top: 5%;left: 20px;
  bottom: 5%;left: 20px;
  border-radius: 15%;width: 40px;height: 40px;line-height: 40px;
  //background-color: rgb(255, 255, 255);
  background-color: rgba(255, 255, 255, 0);
  box-shadow: 0px 0px 5px rgb(179, 202, 214);
  transition: background-color 0.3s ease;
}
.floatingGroup:hover {
  cursor: pointer;
  background-color: #ffffff;
  box-shadow: 0px 0px 5px #d7f5ff;
  //box-shadow: 0px 0px 1px #00c1ed;
  //background-color: #e9f5f8;
}
.navtop-content {
  position: fixed;z-index: 900;
  display: flex;justify-content: center; /* justify水平居中 align垂直居中 */
  background-color: rgba(255, 255, 255, 0.5);
  width: 100%; /* 侧边栏宽度 */
  /*width: 6%;height: 100vh;*/
}
.navside-content {
  position: fixed;z-index: 900;
  display: flex;flex-direction: column;justify-content: center;align-items: center; /* justify水平居中 align垂直居中 */
  background-color: rgba(255, 255, 255, 0);
  //background-color: rgba(255, 255, 255, 0.75);
  //width: 100%; /* 侧边栏宽度 */
  width: 90px;
  height: 80%;
  margin-top: 4%;

}


.body {
  flex: 1;
  overflow: auto;
  display: flex;
  flex-direction: column; /* 垂直排列子元素 */
  justify-content: space-between;
}
.top {
  z-index: 10;
  display: flex;align-items: center;justify-content: center;
  height: 50px;
  background-color: #e0eef1;
  pointer-events: none;
}
.bottom {
  display: flex;align-items: center;justify-content: center;
  margin-top: 200px;
  height: 50px;
  //color: rgb(172, 217, 241);background-color: #8cd4e1a1;
  color: white;background-color: #e0eef1;
  font-size: 13px;
  text-align: center;
}
.roundimg-container {
  border-radius: 50%;
  overflow: hidden;
}
.background {
  position: fixed;
  width: 100%;
  height: 100%;
  z-index: -10; /* 确保背景在内容下方 */
  //background-color: #e9f5f8;
  background-color: rgba(233, 245, 248, 0.63);
  display: flex;
  justify-content: center;
  align-items: center;

  //padding-bottom: 100vh;

}
.main-content {
  flex: 1;
}
</style>


<script>
import request from "@/utils/request";

export default {
  name: "Layout",

  data() {
    return {
      user: localStorage.getItem("user") ? JSON.parse(localStorage.getItem("user")) : {},
      show_scroll: true,
      show_navbartop: true,
      show_navbarside: true,
      flag_click: true,
      rotation: 0,
      login: {},
      loginstatus: '',
    }
  },
  created() {
    this.user = JSON.parse(localStorage.getItem('user'))
  },
  mounted() {
    // 监听滚动事件
    const container = document.querySelector('.body');
    container.addEventListener('scroll', this.showScroll);
    // window.addEventListener('scroll', this.showScroll);
    // window.addEventListener('scroll', () => {
    //   console.log(window.scrollY);
    // });
  },
  beforeDestroy() {
    // 在组件销毁时移除事件监听
    const container = document.querySelector('.body');
    container.removeEventListener('scroll', this.showScroll);
    // window.removeEventListener('scroll', this.showScroll);
  },
  methods: {
    logout() {
      this.login.userid  = this.user.id;
      this.loginstatus = 'false';
      request.delete("/login/" + this.login.userid).then(res => {
        if (res.code === '0') {
          this.$message.success({message: '登出成功', duration: 800});
          localStorage.removeItem('user')
          this.$router.push('/login')
        } else {
          this.$message.error({message: res.msg, duration: 800});
        }
      })
    },
    tomypage() {
      this.$router.push('/mypage');
    },
    showNavsideClick() {
      this.show_navbarside = !this.show_navbarside;
    },
    showNavtopClick() {
      console.log(this.flag_click);
      if(!this.show_navbartop) {
        this.rotation = 180;
      }else {
        this.rotation = 0;
      }
      this.flag_click = !this.flag_click;
      this.show_navbartop = !this.show_navbartop;
    },
    showNavtopHover() {
      this.show_navbartop = true;
      this.rotation = 180;
    },
    hideNavtopbar() {
      this.show_navbartop = false;
      this.rotation = 0;
    },
    showScroll() {
      // 当页面滚动超过一定距离时显示按钮
      const container = document.querySelector('.body');
      this.show_scroll = container.scrollTop > 0;
      // this.show_scroll = container.scrollY > 0;
      // this.show_scroll = window.scrollY > 0;
      // if(container.scrollTop > 0){
      //   this.show_scroll = true;
      // }else {
      //   this.show_scroll = false;
      // }
    },
    scrollToTop() {
      const container = document.querySelector('.body');
      container.scrollTo({top: 0, behavior: 'smooth'});
      console.log("scrollTop: "+container.scrollTop)
      console.log('回到顶部');
      // window.scrollTo({top: 0,behavior: 'smooth'});
      // const scrollY = window.scrollY || document.documentElement.scrollTop;
      // console.log(scrollY);

      // if ('scrollBehavior' in document.documentElement.style) {
      //   console.log('浏览器支持平滑滚动');
      // } else {
      //   console.log('浏览器不支持平滑滚动');
      // }
    },
    newClick(key) {
      console.log("newClick:"+key);
      //跳转页面时执行方法
      if(key === '/newer'){
        this.$router.push('/new');
      }
    },

  }
}
</script>

<style>
.el-menu{
  border-right: none !important;
}
</style>