<template>
  <div class="admin-container">
    <div class="newer-container">
      <div class="newer-body">
        <div class="newer-bottom">
          <div class="newer-left">
            <div class="left-top">
              <div class="li-icon" style="font-size: 15px;margin:auto 5px;display: flex;justify-content: space-between;align-items: center;">
                <div>新增发布</div>
                <i class="el-icon-folder-add li-i" @click="addFolder"></i>
              </div>
            </div>
            <div class="item-group" v-for="(ifolder,indexfolder) in folder" :key="indexfolder">
              <div class="left-item">
                <div class="li-first">
                  <i class="el-icon-folder"></i>
                  <div class="li-title">{{ifolder.category}}</div>
                </div>
                <div class="li-icon">
                  <el-dropdown trigger="click">
                    <span class="el-dropdown-link">
                      <i class="el-icon-circle-plus li-i"></i>
                    </span>
                    <el-dropdown-menu>
                      <el-dropdown-item><div @click="addDoc(ifolder.id)"><i class="el-icon-circle-plus-outline"></i>新增发布</div></el-dropdown-item>
                      <el-upload action="http://localhost:8080/api/files/uploadfiles" :on-success="uploadFile" :show-file-list="false">
                        <el-dropdown-item><div @click="preuploadFile(ifolder.id)"><i class="el-icon-upload2"></i>文本文件</div></el-dropdown-item>
                        <el-dropdown-item><div @click="preuploadFile(ifolder.id)"><i class="el-icon-upload2"></i>图片文件</div></el-dropdown-item>
                        <el-dropdown-item><div @click="preuploadFile(ifolder.id)"><i class="el-icon-upload2"></i>音频文件</div></el-dropdown-item>
                        <el-dropdown-item><div @click="preuploadFile(ifolder.id)"><i class="el-icon-upload2"></i>视频文件</div></el-dropdown-item>
                        <el-dropdown-item><div @click="preuploadFile(ifolder.id)"><i class="el-icon-upload2"></i>其他文件</div></el-dropdown-item>
                      </el-upload>
                    </el-dropdown-menu>
                  </el-dropdown>
                  <el-popconfirm title="确定删除分类吗？" @confirm="deleteFolder(ifolder.id)">
                    <template #reference>
                      <i class="el-icon-delete-solid li-i"></i>
<!--                      <i class="el-icon-delete li-i"></i>-->
                    </template>
                  </el-popconfirm>
                </div>
              </div>
              <div class="left-subitem" @click="filesShowid(ifiles.id,ifiles.filename,ifiles.flag)"
                   v-if="ifiles.categoryid==ifolder.id"
                   v-for="(ifiles,indexfiles) in fileslist" :key="indexfiles">
                <div class="li-subtitle"><i class="el-icon-document"></i>{{ifiles.filename}}</div>
                <div class="li-icon">
                  <i class="el-icon-download li-i" @click="downFile(ifiles.flag)"></i>
                  <i class="el-icon-remove-outline li-i" @click="deleteFile(ifiles.id,ifiles.flag)"></i>
                </div>
              </div>
              <div class="left-subitem" @click="docShowid(idoc.id)"
                   v-if="idoc.categoryid==ifolder.id"
                   v-for="(idoc,indexdoc) in doclist" :key="indexdoc">
                <div class="li-subtitle">{{idoc.title}}</div>
                <div class="li-icon">
                  <el-dropdown trigger="click">
                    <span class="el-dropdown-link">
                      <i class="el-icon-circle-plus-outline li-i"></i>
                    </span>
                    <el-dropdown-menu>
                      <el-dropdown-item><div @click="addDoceditor(idoc.id,idoc.title)"><i class="el-icon-edit"></i>发布编辑</div></el-dropdown-item>
                    </el-dropdown-menu>
                  </el-dropdown>
                  <el-popconfirm title="确定删除发布吗？" @confirm="deleteDoc(idoc.id)">
                    <template #reference>
                      <i class="el-icon-delete li-i"></i>
                    </template>
                  </el-popconfirm>
                </div>
              </div>
            </div>
          </div>
          <div class="newer-main">
            <div v-if="ifilesmian.id == files_showid"
                 v-for="(ifilesmian,indexfiles) in fileslist" :key="indexfiles"
                 class="newer-main-body">
              <div style="margin-bottom: 15px">{{ifilesmian.filename}}</div>
              <div v-if="file_url">
                <img v-if="file_type === 'image'" :src="file_url" alt=""/>
                <audio controls v-if="file_type === 'audio'">
                  <source :src="file_url" type="audio/mpeg">
                  Your browser does not support the audio element.
                </audio>
                <video controls v-if="file_type === 'video'">
                  <source :src="file_url" type="video/mp4">
                  Your browser does not support the video tag.
                </video>
  <!--                  http://localhost:8080/api/files/-->
  <!--                  1747532371759-图片.png-->
  <!--                  1747532377682-音频.mp3-->
  <!--                  1747558561273-视频.pm4-->
  <!--                  1747562534245-文本.txt-->
  <!--                  1747532404795-excel.xlsx-->
  <!--                  1747532409194-word.docx-->
  <!--              思路：kkview预览+iframe嵌入-->
  <!--              思路：第三方接口+iframe嵌入-->
  <!--              <embed src="http://localhost:8080/api/files/1747562534245-文本.txt" type="text/plain">-->
  <!--              <iframe src="http://localhost:8080/api/files/1747562534245-文本.txt"></iframe>-->
  <!--              <iframe src="https://kkview.cn/zh-cn/docs/production.html"></iframe>-->
  <!--              <iframe src="https://docs.google.com/gview?url=http://localhost:8080/api/files/1747532409194-word.docx.docx&embedded=true" width="100%" height="500px"></iframe>-->
  <!--              <iframe src="https://view.officeapps.live.com/op/embed.aspx?src=http://localhost:8080/api/files/1747532409194-word.docx" width="100%" height="500px"></iframe>-->
              </div>
            </div>
            <div v-if="idocmain.id == doc_showid"
                 v-for="(idocmain,indexdoc) in doclist" :key="indexdoc">
              <div style="margin:20px;padding: 20px">{{idocmain.title}}</div>
              <div class="newer-main-body"
                   v-if="idoceditor.docid == doc_showid"
                   v-for="(idoceditor,indexdoceditor) in doceditorlist" :key="indexdoceditor"
                   >
                <div style="display: flex;flex-direction: row;align-items: center;margin-bottom: 5px">
                  <i class="el-icon-circle-close li-i" @click="deleteDoceditor(idoceditor.id)"></i>
                  <div class="ed-icon" @click="saveDoceditor(idoceditor.id,idocmain.id,idocmain.title,indexdoceditor)" style="flex-direction: row;display: flex">
<!--                    <i class="el-icon-circle-check" v-show="!view_checkicon"></i>-->
<!--                    <i class="el-icon-success" v-show="view_checkicon"></i>-->
                    <i class="el-icon-circle-check" v-show="!idoceditor.view_checkicon"></i>
                    <i class="el-icon-success" v-show="idoceditor.view_checkicon"></i>
                  </div>
                  <i class="el-icon-edit li-i" @click="selectDoceditor(idoceditor.id,indexdoceditor)" style="margin-left: 15px;color: rgb(9, 123, 147);"></i>
                </div>
                <div v-html="idoceditor.doceditorContent" v-show="show_html"></div>
                <div :id="`editor-${indexdoceditor}`" v-show="show_editor"></div>
              </div>
<!--              <div>继续添加</div>-->
            </div>
            <div v-if="ifilesmian.id == docfiles_showid"
                 v-for="(ifilesmian,indexfiles) in fileslist" :key="indexfiles"
                 class="newer-main-body">
              <div style="margin-bottom: 15px">{{ifilesmian.filename}}</div>
              <div v-if="file_url">
                <img v-if="file_type === 'image'" :src="file_url" alt=""/>
                <audio controls v-if="file_type === 'audio'">
                  <source :src="file_url" type="audio/mpeg">
                  Your browser does not support the audio element.
                </audio>
                <video controls v-if="file_type === 'video'">
                  <source :src="file_url" type="video/mp4">
                  Your browser does not support the video tag.
                </video>
                <!--                  http://localhost:8080/api/files/-->
                <!--                  1747532371759-图片.png-->
                <!--                  1747532377682-音频.mp3-->
                <!--                  1747558561273-视频.pm4-->
                <!--                  1747562534245-文本.txt-->
                <!--                  1747532404795-excel.xlsx-->
                <!--                  1747532409194-word.docx-->
                <!--              思路：kkview预览+iframe嵌入-->
                <!--              思路：第三方接口+iframe嵌入-->
                <!--              <embed src="http://localhost:8080/api/files/1747562534245-文本.txt" type="text/plain">-->
                <!--              <iframe src="http://localhost:8080/api/files/1747562534245-文本.txt"></iframe>-->
                <!--              <iframe src="https://kkview.cn/zh-cn/docs/production.html"></iframe>-->
                <!--              <iframe src="https://docs.google.com/gview?url=http://localhost:8080/api/files/1747532409194-word.docx.docx&embedded=true" width="100%" height="500px"></iframe>-->
                <!--              <iframe src="https://view.officeapps.live.com/op/embed.aspx?src=http://localhost:8080/api/files/1747532409194-word.docx" width="100%" height="500px"></iframe>-->
              </div>
            </div>
          </div>
        </div>
      </div>
      <el-dialog :visible.sync="dialogFormVisible" >
        <el-form>
<!--          <el-form-item>11</el-form-item>-->
          <div style="font-size: 18px;margin-bottom: 10px">新建文件夹</div>
          <div style="display: flex;flex-direction: row;align-items: center">
            <el-input v-model="folder_name" placeholder="请输入文件夹名称"></el-input>
            <div @click="saveFolder"
                class="replypoint-btn"
                style="margin-left: 10px;width:80px;height: 32px;line-height: 32px">
              提交
            </div>
          </div>
        </el-form>
      </el-dialog>
      <el-dialog :visible.sync="doc_dialogFormVisible" >
        <el-form>
<!--          <el-form-item>11</el-form-item>-->
          <div style="display: flex;flex-direction: row;align-items: center">
            <el-input v-model="doc_name" placeholder="请输入发布名称"></el-input>
            <div @click="saveDoc"
                class="replypoint-btn"
                style="margin-left: 10px;width:80px;height: 32px;line-height: 32px">
              提交
            </div>
          </div>
        </el-form>
      </el-dialog>
    </div>
  </div>
</template>

<script>
import {Upload} from "element-ui";
import request from "@/utils/request";
import E from 'wangeditor'
let editor
function initWangEditor(content) {	setTimeout(() => {
  if (editor) {
    console.log('editor destroy---'+editor);
    editor.destroy(); // 如果编辑器已存在，先销毁
    editor = null;
  }
  if (!editor) {//如果编辑器不存在，才创建
    console.log('editor none---'+editor);//undefined
    editor = new E('#editor')
    console.log('editor exist---'+editor);//object
    editor.config.placeholder = '请输入内容'
    editor.config.uploadFileName = 'file'
    editor.config.uploadImgServer = 'http://localhost:8080/api/files/wang/upload'
    editor.create()
  }
  if (content) {//如果有传递值不为空，则将内容作为初始化内容
    editor.txt.html(content)
  }
}, 0)
}

export default {
  computed: {
    Upload() {
      return Upload
    }
  },
  data() {
    return {
      dialogFormVisible: false,//打开新增分类对话框
      folder: {},//分类 实体类参数
      folder_name: '',//定义分类名

      files: {},//文件 实体类参数
      fileslist: {},
      file_flag: '',//获取时间戳
      file_name: '',//获取文件名，进而获取文件类型
      file_type: '',//根据文件类型，渲染对应组件
      file_url: '',//绑定传参文件名、时间戳，加载文件内容
      files_showid: 0,//加载文件：当选中文件时，获取该文件id，用于加载文件内容

      doc_dialogFormVisible: false,
      doc: {},//发布 实体类参数
      doclist: {},
      doc_name: '',//定义发布名
      doc_showid: 0,//加载发布：当选中发布时，获取该发布id，用于加载发布


      doceditor: {},//编辑器 实体类参数(子属性：view_checkicon、view_html)
      doceditorlist: {},
      doceditorContent: '',//编辑器内容，渲染到页面的内容
      editorInstances: {}, //创建的编辑器实例(根据索引创建方式)
      initdoceditor: {},//临时参数，用于初始化时传递id参数查询数据库，接收返回的编辑器
      show_editor: '',//父组件---选中编辑器时，打开编辑器，可不关闭已打开的预览
      show_html: '',//子组件---点击保存时打开预览，关闭编辑器
      view_checkicon: '',//子组件---点击保存时变为选中

      user: localStorage.getItem("user") ? JSON.parse(localStorage.getItem("user")) : {},
    };
  },
  created() {
    this.user = JSON.parse(localStorage.getItem('user'));
    this.findFolder();
    this.findFiles();
    this.findDoc();
    this.findDoceditor();
  },
  mounted() {
  },
  methods: {
    //  分类：category [id userid username category]
    findFolder() {
      request.get("/category/find",{params:this.user}).then(res =>{
        if(res.code === '0'){
          this.folder = res.data;
        }else{
          this.$message.error({message: res.msg, duration: 800});
          // this.$message.error(res.msg);
        }
      })
    },                //加载全部新增的分类列表
    addFolder() {
      this.dialogFormVisible = true;
    },                 //点击新增按钮，打开新增分类对话框
    saveFolder() {
      this.folder = {
        userid: this.user.id,
        username: this.user.name,
        category: this.folder_name,
      }
      request.post("/category/save", this.folder).then(res => {
        if (res.code === '0') {
          this.$message.success({message: '操作成功', duration: 800});
          this.findFolder();
        } else {
          this.$message.error({message: res.msg, duration: 800});
        }
      })
      this.dialogFormVisible = false;
    },                //点击提交按钮，保存新增的分类到数据库，关闭开启的新增对话框，调用查询加载全部新增的分类列表
    deleteFolder(categoryid) {
      request.delete("/category/" + categoryid).then(res => {
        if (res.code === '0') {
          this.$message.success({message: "删除成功", duration: 800});
          this.findFolder();
        } else {
          this.$message.error({message: res.msg, duration: 800});
          // this.$message.error(res.msg);
        }
      })
    },    //点击删除按钮，删除分类及其子元素(文件、富文本)，调用查询加载全部新增的分类列表


    //  文件：files [id categoryid userid username flag filename]
    findFiles() {
      request.get("/category/findfiles",{params:this.user}).then(res =>{
        if(res.code === '0'){
          // this.$message.success({message: '加载图片', duration: 800});
          // console.log(res.data);
          this.fileslist = res.data;
          if(this.fileslist[this.fileslist.length - 1]?.id){
            this.files_showid = this.fileslist[this.fileslist.length - 1].id;
            this.doc_showid = 0;
          }else if(this.doclist[this.doclist.length - 1]?.id) {
            this.doc_showid = this.doclist[this.doclist.length - 1].id;
            this.files_showid = 0;
          }
        }else{
          this.$message.error({message: res.msg, duration: 800});
          // this.$message.error(res.msg);
        }
      })
    },                           //加载分类下全部上传的文件列表
    preuploadFile(categoryid) {
      this.files.categoryid = categoryid;//分类id
    },             //点击上传按钮：1. 文件上传前，定位文件分类
    uploadFile(res) {
      this.files.userid = this.user.id;           //userid
      this.files.username =  this.user.name;      //username
      this.files.flag = res.data.flag;            //flag
      this.files.filename = res.data.fileName;    //filename
      request.post("/category/files", this.files).then(res => {
        if (res.code === '0') {
          this.$message.success({message: '操作成功', duration: 800});
          this.findFiles();
        } else {
          this.$message.error({message: res.msg, duration: 800});
        }
      })
    },                       //点击上传按钮：2. 文件上传后，保存上传的文件到数据库，调用查询加载全部上传的文件列表
    downFile(iflag) {
      location.href = 'http://localhost:8080/api/files/' + iflag
    },                       //点击下载文件，调用下载接口，传递时间戳参数
    deleteFile(ifileid,iflag) {
      request.delete("/files/delete/" + iflag).then(res => {
        if (res.code === '0') {
          request.delete("/category/delfiles/" + ifileid).then(res => {
            if (res.code === '0') {
              this.$message.success({message: "删除成功", duration: 800})
              this.findFiles();
            } else {
              this.$message.error({message: res.msg, duration: 800});
            }
          })//删除数据库记录
        } else {
          this.$message.error({message: res.msg, duration: 800});
        }
      })//删除本地文件
    },             //点击删除按钮，删除一个本地文件和数据库记录，调用查询加载全部上传的文件列表

    // 发布：document [id userid username categoryid title]
    findDoc() {
      request.get("/category/finddoc",{params:this.user}).then(res =>{
        if(res.code === '0'){
          this.doclist = res.data;
        }else{
          this.$message.error({message: res.msg, duration: 800});
        }
      })
    },                    //加载分类下全部添加的发布列表
    addDoc(categoryid) {
      this.doc_dialogFormVisible = true;
      this.doc.categoryid = categoryid;     //categoryid
      this.show_editor = false;
    },           //点击新增按钮，打开新增发布对话框，定位分类、关闭已初始化编辑器
    saveDoc() {
      this.doc.userid=this.user.id;         //userid
      this.doc.username=this.user.name;     //username
      this.doc.title= this.doc_name;        //title
      request.post("/category/savedoc", this.doc).then(res => {
        if (res.code === '0') {
          this.$message.success({message: '操作成功', duration: 800});
          this.findDoc();
        } else {
          this.$message.error({message: res.msg, duration: 800});
        }
      })
      this.doc_dialogFormVisible = false;
    },                    //点击提交按钮，保存新增的发布到数据库，关闭开启的新增对话框，调用查询加载全部新增的发布列表
    deleteDoc(idocid) {
      request.delete("/category/deldoc/" + idocid).then(res => {
        if (res.code === '0') {
          this.$message.success({message: "删除成功", duration: 800});
          this.findDoc();
        } else {
          this.$message.error({message: res.msg, duration: 800});
        }
      })
    },            //点击删除按钮，删除发布及其子元素(编辑器)，调用查询加载全部发布列表

    // 切换显示
    filesShowid(ifileid,ifilename,iflag) {
      this.files_showid = ifileid;    //显示选中的文件
      this.doc_showid = 'x';          //隐藏未选中发布
      this.file_flag = iflag;         //flag
      this.file_name = ifilename;     //filename
      this.file_type = this.filesgetType(ifilename);                                          //解析文件格式，以选择预览方式
      this.file_url = `http://localhost:8080/api/files/${this.file_flag}-${this.file_name}`;  //拼接请求路径，以加载文件预览
    },  //点击选中文件：1. 解析文件格式，切换显示并加载文件预览
    filesgetType(ifilename) {
      const extension = ifilename.split('.').pop().toLowerCase();
      if (['jpg', 'jpeg', 'png', 'gif'].includes(extension)) {
        return 'image';
      } else if (['mp3', 'wav'].includes(extension)) {
        return 'audio';
      } else if (['mp4', 'avi'].includes(extension)) {
        return 'video';
      }
      return 'other';
    },               //点击选中文件：2. 解析文件格式（图片、音频、视频、其他）
    docShowid(idocid) {
      this.doc_showid = idocid;     //显示选中的发布
      this.files_showid = 'x';      //隐藏未选中文件
      this.findDoceditor();         //加载发布下全部的编辑器列表
      this.show_html = true;        //编辑器全部启用预览
    },                     //点击选中发布，切换显示并加载富文本预览

    // 编辑器：doceditor [id docid doctitle userid username doceditorContent]
    findDoceditor() {
      request.get("/category/findeditor",{params:this.user}).then(res =>{
        if(res.code === '0'){
          this.doceditorlist = res.data;
        }else{
          this.$message.error({message: res.msg, duration: 800});
        }
      })
    },                                           //加载发布下全部创建的编辑器列表
    addDoceditor(idocid,idoctitle) {
      this.doceditor = {};                      //初始化清空
      this.doceditor.docid = idocid;             //docid
      this.doceditor.doctitle= idoctitle;        //doctitle
      this.doceditor.userid=this.user.id;       //userid
      this.doceditor.username=this.user.name;   //username
      this.doceditor.doceditorContent= '';      //doceditorContent
      request.post("/category/adddoceditor", this.doceditor).then(res => {
        if (res.code === '0') {
          this.$message.success({message: '操作成功', duration: 800});
          this.findDoceditor();
        } else {
          this.$message.error({message: res.msg, duration: 800});
        }
      })
    },                            //点击新增按钮，保存新增的内容区到数据库，调用查询更新前端数据
    selectDoceditor(doceditorid,index) {
      this.show_editor = true;      //打开编辑
      this.show_html = false;       //关闭预览
      if (this.editorInstances[this.currentEditorIndex]) {
        this.editorInstances[this.currentEditorIndex].destroy();
        delete this.editorInstances[this.currentEditorIndex];
      }    //销毁旧编辑器实例：1. 根据当前索引销毁
      this.currentEditorIndex = index;                            //销毁旧编辑器实例：2. 传递当前索引
      this.initDoceditor(doceditorid,index);                      //初始化新编辑器实例
    },                        //点击编辑按钮：1. 打开编辑入口、关闭内容预览，销毁旧编辑器实例，初始化新编辑器实例
    async initDoceditor(doceditorid,index) {
      const editorId = `editor-${index}`;                                          //编辑器id(根据索引赋值)
      this.editorInstances[index] = new E(`#${editorId}`);           //创建编辑器实例
      this.editorInstances[index].create();                                        //初始化编辑器实例
      await this.findDoceditorById(doceditorid);                                   //初始化已有内容：1. 根据编辑器id查询编辑器内容
      this.editorInstances[index].txt.html(this.initdoceditor.doceditorContent);   //初始化已有内容：2. 初始化时传递编辑器内容
    },                    //点击编辑按钮：2. 初始化编辑器，根据编辑器id查询编辑器内容，初始化时传递编辑器内容
    async findDoceditorById(doceditorid) {
      this.initdoceditor.id = doceditorid;
      await request.get("/category/findeditorByid",{params:this.initdoceditor}).then(res =>{
        if(res.code === '0'){
          this.initdoceditor = res.data;
        }else{
          this.$message.error({message: res.msg, duration: 800});
        }
      })
    },                      //点击编辑按钮：3. 根据编辑器id查询编辑器内容
    saveDoceditor(doceditorid,docid,doctitle,indexdoceditor) {
      this.doceditorlist[indexdoceditor].view_checkicon = !this.doceditorlist[indexdoceditor].view_checkicon;//切换保存图标
      setTimeout(() => {
        this.doceditorlist[indexdoceditor].view_checkicon = !this.doceditorlist[indexdoceditor].view_checkicon;
      }, 200);//切换保存图标：失效
      this.doceditor = {};                                                                   //初始化清空
      this.doceditor.id = doceditorid;                                                       //id
      this.doceditor.docid = docid;                                                          //docid
      this.doceditor.doctitle = doctitle;                                                    //doctitle
      this.doceditor.userid=this.user.id;                                                    //userid
      this.doceditor.username=this.user.name;                                                //username
      if (this.editorInstances[this.currentEditorIndex]) {
        this.doceditor.doceditorContent = this.editorInstances[indexdoceditor].txt.html();   //doceditorContent
        request.post("/category/adddoceditor", this.doceditor).then(res => {
          if (res.code === '0') {
            this.$message.success({message: '操作成功', duration: 800});
          } else {
            this.$message.error({message: res.msg, duration: 800});
          }
        })        //保存内容到数据库
        this.doceditorlist[indexdoceditor].doceditorContent = this.editorInstances[indexdoceditor].txt.html();  //传递预览内容
        this.show_html = true;                                                                                  //打开预览
        this.show_editor = false;                                                                               //关闭编辑
      }                               //存在编辑器
    },  //点击保存按钮，保存编辑内容到数据库，打开内容预览、关闭编辑入口
    deleteDoceditor(doceditorid) {
      request.delete("/category/deldoceditor/" + doceditorid).then(res => {
        if (res.code === '0') {
          this.$message.success({message: "删除成功", duration: 800});
          this.findDoceditor();
        } else {
          this.$message.error({message: res.msg, duration: 800});
        }
      })
    },                              //点击删除按钮，删除一个编辑器，调用加载全部创建的编辑器列表
  }
};
</script>

<style>
.newer-container {
  width: 100%;
  height: 100%;
}
.newer-body {
  background-color: rgba(0, 107, 163, 0);
  height: 80vh;
  width: 100%;
  //display: flex;
  //flex-direction: column;
  //justify-content: space-between;
}
.newer-bottom {
  background-color: rgba(0, 107, 163, 0);
  height: 100%;
  width: 100%;
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  position: relative;
}
.newer-left  {
  border: 1px solid rgb(195, 218, 230);
  width: 14%;
  height: 100%;
  overflow: auto;
  text-align: left;
}
.left-top {
  height: 20px;
  border-bottom: 1px solid rgb(195, 218, 230);
  text-align: right;
}
.left-item {
  color: #00c1ed;
  font-size: 15px;
  height: 20px;
  display: flex;
  flex-direction: row;
  justify-content: space-between;
}
.left-subitem {
  color: rgb(9, 123, 147);
  font-size: 15px;
  height: 20px;
  display: flex;
  flex-direction: row;
  justify-content: space-between;
}
.li-first {
  margin-left: 5px;
  display: flex;
  flex-direction: row;
  align-items: center;
}
.li-title {
  //width: 123px;
  margin-left: 5px;
  //width: 75%;
  overflow: hidden;
}
.li-subtitle{
  width: 135px;
  //width: 70%;
  margin-left: 10px;
  overflow: hidden;
}
.li-icon {
  font-size: 14px;
  margin-right: 5px;
  color: #a38200;
}
.li-i {
  color: #a38200;
}
.li-i:hover {
  color: #00c1ed;
}
.ed-icon {
  color: #42b983;
}
.ed-icon:hover {
  color: #00c1ed;
}
.left-item:hover {
  cursor: pointer;
  background-color: rgba(197, 220, 232, 0.3);
}
.left-subitem:hover {
  cursor: pointer;
  background-color: rgba(197, 220, 232, 0.3);
}
.replypoint-btn {
  border-radius: 5px;
  //border: 1px solid rgb(9, 123, 147);
  border: 1px solid #00c1ed;
  width: 50px;height: 25px;line-height: 25px;
  color: #00c1ed;
  //background-color: #8cd4e1a1;
  text-align: center;
  font-size: 14px;
}
.replypoint-btn:hover {
  cursor: pointer;
  color: #ffffff;
  background-color: #d6e7fa;
  transition: background-color 0.3s ease;
  border-color: #d6e7fa;
}
.replybtm-btn {
  border-radius: 5px;
  //border: 1px solid rgb(9, 123, 147);
  border: 1px solid #c5dce8;
  width: 50px;height: 25px;line-height: 25px;
  color: rgb(9, 123, 147);
  background-color: rgba(140, 212, 225, 0);
  text-align: center;
  font-size: 14px;
}
.replybtm-btn:hover {
  cursor: pointer;
  color: #ffffff;
  background-color: #d6e7fa;
  transition: background-color 0.3s ease;
  border-color: #d6e7fa;
}

.test-newer-main {
  //width: 85.5%;
  //height: 100%;
  //overflow: auto;
  //border: 1px solid rgb(195, 218, 230);
}
.newer-main {
  position: absolute;
  margin-left: 185.26px;
  width: 1102.9px;
  height: 100%;
  overflow: auto;
  border: 1px solid rgb(195, 218, 230);
}
.newer-main-body {
  border: 1px #00c1ed solid;
  border-radius: 15px;
  margin: 20px;
  padding: 20px;

}

.newer-main-body img,
.newer-main-body video {
  width: 100%;
}
.newer-main-body iframe {
  width: 100%;
  height: 500px;
}
</style>