<template>
  <div class="admin-container">
    <div class="headsearch">
      <el-input v-model="params.syncid" style="width: 200px; margin-right: 10px" placeholder="请输入协同ID"></el-input>
      <el-input v-model="params.content" style="width: 200px; margin-right: 10px" placeholder="请输入编辑器内容"></el-input>
      <el-button type="warning" @click="findBySearch()">查询</el-button>
      <el-button type="warning" @click="reset()">清空</el-button>
    </div>
    <div class="midtable">
      <el-table :data="tableData" style="width: 100%; margin: 15px 0px">
<!--        <el-table-column prop="id" label="编辑器ID"></el-table-column>-->
        <el-table-column prop="syncid" label="协同ID"></el-table-column>
        <el-table-column prop="action" label="编辑器状态"></el-table-column>
        <el-table-column prop="content" label="编辑器内容"></el-table-column>
        <el-table-column label="操作">
          <template slot-scope="scope">
            <el-button type="primary" @click="edit(scope.row)">编辑</el-button>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <div class="footpage">
      <el-pagination
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
          :current-page="params.pageNum"
          :page-sizes="[5, 10, 15, 20]"
          :page-size="params.pageSize"
          layout=" total, sizes, prev, pager, next"
          :total="total">
      </el-pagination>
    </div>
    <div class="coverdialog">
      <el-dialog :title="sync_title" :visible.sync="dialogFormVisible">
        <el-form :model="form">
          <el-form-item label="编辑器内容：">
<!--            <el-input v-model="form.category" autocomplete="off" style="width:90%" placeholder="请输入分类名"></el-input>-->
<!--            <textarea :value="socketContent" @input="sendEditMessage(isync.id,$event.target.value)" style="width: 100%;height: 50vh"></textarea>-->
            <textarea v-model="form.content" style="width: 100%;height: 50vh"></textarea>
          </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer">
          <el-button @click="dialogFormVisible = false">取 消</el-button>
          <el-button type="primary" @click="submit()">确 定</el-button>
        </div>
      </el-dialog>
    </div>
  </div>
</template>
<style scoped>

</style>
<script>
import request from "@/utils/request";
export default {
  //name: "AdminView",
  data() {
    return {
      user: localStorage.getItem("user") ? JSON.parse(localStorage.getItem("user")) : {},
      params:{
        pageNum: 1,
        pageSize: 5
      },   //前端封装参数：用于传递分页参数或其他参数
      total: 0,                 //分页数据：共几条
      dialogFormVisible: false, //开启/关闭对话框

      tableData: {},            //表格数据
      form: {},                 //表单数据
      formin: {},               //提交对象：提交新增/修改分类数据
      userfind: {},             //用户对象：通过用户名查找用户对象数据

      flag_addORedit: '',       //新增或编辑 标识：add/edit (新增时id为空或undefined)
      sync_title: '',
    }
  },
  created() {
    this.findBySearch();
    this.user = JSON.parse(localStorage.getItem('user'))
  },
  methods: {
    handleSizeChange(pageSize) {
      this.params.pageSize = pageSize;
      this.findBySearch();
    },    //点击切换分页条数
    handleCurrentChange(pageNum) {
      this.params.pageNum = pageNum;
      this.findBySearch();
    },  //点击跳转当前页码
    reset(){
      this.params = {
        pageNum: 1,
        pageSize: 5,
        name: '',
        phone: ''
      }
      this.findBySearch();
    },                        //点击清空按钮：重置查询条件

    // syncmessage： [id syncid action content]
    findBySearch(){
      request.get("/sync/searchSyncMessage",{params:this.params})
          .then(res =>{
        if(res.code === '0'){
          this.tableData = res.data.list;
          this.total = res.data.total;
        }else{
          this.$message.error({message: res.msg, duration: 800});
          // this.$message({message: res.msg, type: 'error'});
        }
      })
    },                 //加载全部协同列表
    findUerList(){
      request.get("/admin").then(res =>{
        if(res.code === '0'){
          this.userlist = res.data;
        }else{
          this.$message.error({message: res.msg, duration: 800});
        }
      })
    },                  //加载用户选项：用于在下拉列表选择用户


    //---
    edit(obj) {
      this.form = obj;
      this.sync_title = '协同ID：'+obj.syncid;
      this.flag_addORedit = 'edit';         //编辑标识：edit
      this.dialogFormVisible = true;
    },                        //点击编辑按钮：打开修改创建协同对话框，传递已有内容

    async submit(){
      this.formin.id = this.form.id;                    //id
      this.formin.syncid = this.form.syncid;            //syncid
      this.formin.action = this.form.action;            //action
      this.formin.content = this.form.content;          //content
      request.post("/sync/saveSyncMessage", this.formin).then(res => {
        if (res.code === '0') {
          this.$message.success({message: '操作成功', duration: 800});
          this.dialogFormVisible = false;
          this.findBySearch();
        } else {
          this.$message.error({message: res.msg, duration: 800});
        }
      })
    },                    //点击提交按钮：通过用户名、分类名向数据库创建协同表新增一条记录


  }
}
</script>