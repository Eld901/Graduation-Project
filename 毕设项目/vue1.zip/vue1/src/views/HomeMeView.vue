<template>
  <div class="admin-container">
    <div class="newer-container">
      <div class="newer-body">
        <div class="newer-bottom">
          <div class="newer-left">
            <div class="mypage-item-group">
              <div class="mypage-left-item">个人设置</div>
              <div class="mypage-left-subitem">账户资料</div>
            </div>
            <div class="mypage-item-group">
              <div class="mypage-left-item">其他设置</div>
              <div class="mypage-left-subitem">参考</div>
              <div class="mypage-left-subitem">参考</div>
              <div class="mypage-left-subitem">参考</div>
              <div class="mypage-left-subitem">参考</div>
              <div class="mypage-left-subitem">参考</div>
              <div class="mypage-left-subitem">参考</div>
              <div class="mypage-left-subitem">参考</div>
              <div class="mypage-left-subitem">参考</div>
              <div class="mypage-left-subitem">参考</div>
              <div class="mypage-left-subitem">参考</div>
            </div>
            <div class="mypage-item-group">
              <div class="mypage-left-item">其他设置</div>
              <div class="mypage-left-subitem">参考</div>
              <div class="mypage-left-subitem">参考</div>
              <div class="mypage-left-subitem">参考</div>
              <div class="mypage-left-subitem">参考</div>
              <div class="mypage-left-subitem">参考</div>
            </div>
          </div>
          <div class="mypage-newer-main">
            <div class="personal-info">
<!--              <div>背景：</div>-->
              <div style="width: 50px;height: 50px;border: 1px #00c1ed solid;display: flex;align-items: center;justify-content: center">
                <el-image
                    style="width: 50px; height: 50px; border-radius: 15px;display: flex;align-items: center;justify-content: center"
                    :src="'http://localhost:8080/api/files/' + files.img"
                    :preview-src-list="['http://localhost:8080/api/files/' + files.img]">
                  <div slot="error" class="image-slot">
                    <i class="el-icon-picture-outline"></i>
                  </div>
                </el-image>
              </div>
              <div style="height: 5px"></div>
              <el-upload action="http://localhost:8080/api/files/upload" :on-success="successUpload">
                <div class="replypoint-btn">上传</div>
              </el-upload>
<!--              <div class="replypoint-btn" @click="findByUser">加载</div>-->
              <div style="height: 20px"></div>
              <div class="replypoint-btn" @click="modify">编辑</div>
              <div style="height: 5px"></div>
              <div style="flex-direction: row;display: flex"><div style="color: #00c1ed">ID：</div>{{ user.id }}</div>
              <div style="flex-direction: row;display: flex"><div style="color: #00c1ed">账号：</div>{{ user.name }}</div>
              <div style="flex-direction: row;display: flex"><div style="color: #00c1ed">密码：</div>{{ user.password }}</div>
              <div style="flex-direction: row;display: flex"><div style="color: #00c1ed">身份：</div>{{ user.role }}</div>
              <div style="flex-direction: row;display: flex"><div style="color: #00c1ed">性别：</div>{{ user.sex }}</div>
              <div style="flex-direction: row;display: flex"><div style="color: #00c1ed">年龄：</div>{{ user.age }}</div>
              <div style="flex-direction: row;display: flex"><div style="color: #00c1ed">电话：</div>{{ user.phone }}</div>
            </div>
            <div>
              <el-dialog title="请填写个人信息" :visible.sync="dialogFormVisible" width="30%">
                <el-form :model="form">
                  <el-form-item label="姓名" label-width="15%">
                    <el-input v-model="form.name" autocomplete="off" style="width:90%"></el-input>
                  </el-form-item>
                  <el-form-item label="性别" label-width="15%">
                    <el-radio v-model="form.sex" label="男">男</el-radio>
                    <el-radio v-model="form.sex" label="女">女</el-radio>
                  </el-form-item>
                  <el-form-item label="年龄" label-width="15%">
                    <el-input v-model="form.age" autocomplete="off" style="width:90%"></el-input>
                  </el-form-item>
                  <el-form-item label="电话" label-width="15%">
                    <el-input v-model="form.phone" autocomplete="off" style="width:90%"></el-input>
                  </el-form-item>
                  <el-form-item label="角色" label-width="15%">
                    <el-select v-model="form.role" placeholder="请选择" style="width: 90%">
                      <el-option label="教师" value="ROLE_TEACHER" v-if="user.role === 'ROLE_TEATURE'"></el-option>
                      <el-option label="学生" value="ROLE_STUDENT" v-if="user.role === 'ROLE_STUDENT'"></el-option>
                      <el-option label="管理员" value="ROLE_ADMIN" v-if="user.role === 'ROLE_ADMIN'"></el-option>
                    </el-select>
                  </el-form-item>
                </el-form>
                <div slot="footer" class="dialog-footer">
                  <el-button @click="dialogFormVisible = false">取 消</el-button>
                  <el-button type="primary" @click="submit()">确 定</el-button>
                </div>
              </el-dialog>
            </div>
          </div>
        </div>
      </div>

    </div>
  </div>
</template>

<style>
.newer-container {
  width: 100%;
  height: 100%;
}
.newer-body {
  background-color: rgba(0, 107, 163, 0);
  height: 80vh;
  width: 100%;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
}
.newer-bottom {
  background-color: rgba(0, 107, 163, 0);
  height: 100%;
  width: 100%;
  display: flex;
  flex-direction: row;
  justify-content: space-between;
}
.newer-left  {
  border: 1px solid rgb(195, 218, 230);
  width: 14%;
  height: 100%;
  overflow: auto;
  text-align: left;
}
.mypage-item-group {
  border-bottom: 1px solid rgb(195, 218, 230);
  display: flex;
  flex-direction: column;
  justify-content: center;
  text-align: center;
}
.mypage-left-item {
  color: #00c1ed;
  font-size: 12px;
  height: 20px;
  width: 100%;
}
.mypage-left-item:hover {
  cursor: pointer;
  background-color: rgba(197, 220, 232, 0.3);
}
.mypage-left-subitem {
  color: rgb(9, 123, 147);
  font-size: 12px;
  height: 20px;
}
.mypage-left-subitem:hover {
  cursor: pointer;
  background-color: rgba(197, 220, 232, 0.3);
}
.personal-info {
  color: rgb(9, 123, 147);
  font-size: 14px;
  text-align: left;
  margin: 20px;
  padding: 20px;
  border: 1px #00c1ed solid;
  border-radius: 15px;
}
.replypoint-btn {
  border-radius: 5px;
  //border: 1px solid rgb(9, 123, 147);
  border: 1px solid #00c1ed;
  width: 50px;height: 25px;line-height: 25px;
  color: #00c1ed;
  //background-color: #8cd4e1a1;
  text-align: center;
  font-size: 14px;
}
.replypoint-btn:hover {
  cursor: pointer;
  color: #ffffff;
  background-color: #d6e7fa;
  transition: background-color 0.3s ease;
  border-color: #d6e7fa;
}

.mypage-newer-main {
  width: 85.5%;
  height: 100%;
  overflow: auto;
  border: 1px solid rgb(195, 218, 230);
}
</style>

<script>
import {Upload} from "element-ui";
import request from "@/utils/request";

export default {
  data() {
    return {
      files: {},
      form: {},
      dialogFormVisible: false,
      user: localStorage.getItem("user") ? JSON.parse(localStorage.getItem("user")) : {},
    };
  },
  created() {
    this.user = JSON.parse(localStorage.getItem('user'));
    this.findByUser();
  },
  methods: {
    modify() {
      console.log(this.user);
      this.form = this.user;
      this.dialogFormVisible = true;
    },
    successUpload(res) {
      //上传文件后
      // this.files = {};//初始化
      //赋值
      this.files.img = res.data;//时间戳
      this.files.userid = this.user.id;//用户id
      this.files.username =  this.user.name;//用户名
      // console.log(this.files);
      // console.log(this.user);
      //保存上传信息
      request.post("/files/save", this.files).then(res => {
        if (res.code === '0') {
          this.$message.success({message: '操作成功', duration: 800});
          // this.$message({message: '操作成功', type: 'success'});
          //加载图片
          this.findByUser();
        } else {
          this.$message.error({message: res.msg, duration: 800});
          // this.$message({message: res.msg, type: 'error'});
        }
      })
    },
    findByUser() {
      request.get("/files/find",{params:this.user}).then(res =>{
        if(res.code === '0'){
          this.files = res.data;
          if(this.files === null) {
            this.files = {};
          }
        }else{
          this.$message.error({message: res.msg, duration: 800});
        }
      })
    },
    submit(){
      request.post("/admin", this.form).then(res => {
        if (res.code === '0') {
          this.$message.success({message: '操作成功', duration: 800});
          this.dialogFormVisible = false;
        } else {
          this.$message.error({message: res.msg, duration: 800});
        }
      })
    },
  }
};
</script>
