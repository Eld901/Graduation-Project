/*
 Navicat Premium Data Transfer

 Source Server         : localhost_3306
 Source Server Type    : MySQL
 Source Server Version : 80040
 Source Host           : localhost:3306
 Source Schema         : springboot

 Target Server Type    : MySQL
 Target Server Version : 80040
 File Encoding         : 65001

 Date: 03/06/2025 16:37:20
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for notice
-- ----------------------------
DROP TABLE IF EXISTS `notice`;
CREATE TABLE `notice`  (
  `id` int NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '公告标题',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL COMMENT '公告内容',
  `time` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '公告时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 36 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '系统公告表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of notice
-- ----------------------------
INSERT INTO `notice` VALUES (21, '公告标题', '555\n666\n777\n8889', '2025-06-03 14:35:34');
INSERT INTO `notice` VALUES (23, '公告标题', '66677', '2025-05-07 08:58:32');
INSERT INTO `notice` VALUES (24, '公告标题', '222', '2025-05-07 08:31:37');
INSERT INTO `notice` VALUES (27, '公告标题', '公告内容', '2025-05-07 08:58:34');
INSERT INTO `notice` VALUES (28, '公告标题', '公告内容', '2025-05-07 08:58:30');
INSERT INTO `notice` VALUES (30, '公告标题', '公告内容22', '2025-05-07 08:58:27');
INSERT INTO `notice` VALUES (31, '公告标题', '公告内容', '2025-05-07 08:58:45');
INSERT INTO `notice` VALUES (32, '公告标题', '公告内容', '2025-05-07 08:58:48');
INSERT INTO `notice` VALUES (33, '111', NULL, '2025-05-15 21:20:41');
INSERT INTO `notice` VALUES (35, '新的公告标题', '公告内容测试', '2025-05-18 08:31:51');

SET FOREIGN_KEY_CHECKS = 1;
