/*
 Navicat Premium Data Transfer

 Source Server         : localhost_3306
 Source Server Type    : MySQL
 Source Server Version : 80040
 Source Host           : localhost:3306
 Source Schema         : springboot

 Target Server Type    : MySQL
 Target Server Version : 80040
 File Encoding         : 65001

 Date: 03/06/2025 16:37:35
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for syncmessage
-- ----------------------------
DROP TABLE IF EXISTS `syncmessage`;
CREATE TABLE `syncmessage`  (
  `id` int NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `syncid` int NULL DEFAULT NULL COMMENT '协同号',
  `action` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT 'socket状态',
  `content` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL COMMENT 'socket内容',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 81 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of syncmessage
-- ----------------------------
INSERT INTO `syncmessage` VALUES (73, 11, 'update', 'admin的协同2 测试内容 13311随着互联网技术的飞速发展，信息传播与共享的方式日益多元化，传统\n文档社区平台已经难以满足用户对丰富信息的需求。因此，设计一个融合了富文本、\n音视频的创新型文档社区平台，具有重要的现实意义。本次设计的主要内容是，实\n现一个功能完备、界面友好的文档社区平台。系统主要划分为用户前台功能部分、\n管理后台功能部分。用户前台功能部分主要包含了以下的几个业务板块：用户登录\n注册模块、用户个人中心模块、用户综合发布模块、用户协同发布模块。管理后台\n功能部分主要包含了以下的几个业务板块：用户信息管理模块、综合发布管理模块、\n协同发布管理模块、系统公告管理模块、系统日志管理模块。112345444');
INSERT INTO `syncmessage` VALUES (74, 3, 'update', '张三的的协同 测试内容 3');
INSERT INTO `syncmessage` VALUES (75, 4, 'update', '张三的的协同2 测试内容 4');
INSERT INTO `syncmessage` VALUES (76, 12, 'update', 'admin的协同3 测试内容 12');
INSERT INTO `syncmessage` VALUES (77, 5, 'update', '张三的的协同3 测试内容 5\n\n张三的编辑333\n\n李四的编辑111\n\nadmin的编辑22236788667777');

SET FOREIGN_KEY_CHECKS = 1;
