/*
 Navicat Premium Data Transfer

 Source Server         : localhost_3306
 Source Server Type    : MySQL
 Source Server Version : 80040
 Source Host           : localhost:3306
 Source Schema         : springboot

 Target Server Type    : MySQL
 Target Server Version : 80040
 File Encoding         : 65001

 Date: 03/06/2025 16:36:09
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for category
-- ----------------------------
DROP TABLE IF EXISTS `category`;
CREATE TABLE `category`  (
  `id` int NOT NULL AUTO_INCREMENT COMMENT '分类id',
  `userid` int NULL DEFAULT NULL COMMENT '用户id',
  `username` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '用户名',
  `category` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '类名',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 94 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '发布分类名表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of category
-- ----------------------------
INSERT INTO `category` VALUES (11, 1, 'admin', '分类名称5');
INSERT INTO `category` VALUES (13, 1, 'admin', '分类名称6');
INSERT INTO `category` VALUES (24, 5, '张三', '文件分类3');
INSERT INTO `category` VALUES (25, 5, '张三', '文件分类4');
INSERT INTO `category` VALUES (26, 5, '张三', '文件分类5');
INSERT INTO `category` VALUES (27, 1, 'admin', '其他分类');
INSERT INTO `category` VALUES (31, 1, 'admin', '发布分类');
INSERT INTO `category` VALUES (58, 1, 'admin', '测试分类');
INSERT INTO `category` VALUES (59, 1, 'admin', '测试分类');
INSERT INTO `category` VALUES (91, 1, 'admin', '测试1111');
INSERT INTO `category` VALUES (92, 1, 'admin', '测试2222');

SET FOREIGN_KEY_CHECKS = 1;
