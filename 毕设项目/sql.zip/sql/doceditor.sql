/*
 Navicat Premium Data Transfer

 Source Server         : localhost_3306
 Source Server Type    : MySQL
 Source Server Version : 80040
 Source Host           : localhost:3306
 Source Schema         : springboot

 Target Server Type    : MySQL
 Target Server Version : 80040
 File Encoding         : 65001

 Date: 03/06/2025 16:36:17
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for doceditor
-- ----------------------------
DROP TABLE IF EXISTS `doceditor`;
CREATE TABLE `doceditor`  (
  `id` int NOT NULL AUTO_INCREMENT COMMENT '编辑器id',
  `docid` int NULL DEFAULT NULL COMMENT '发布id',
  `doctitle` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '发布名称',
  `userid` int NULL DEFAULT NULL COMMENT '用户id',
  `username` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '用户名',
  `doceditorContent` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL COMMENT '编辑器内容',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 84 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '发布编辑表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of doceditor
-- ----------------------------
INSERT INTO `doceditor` VALUES (28, 30, '新增发布1', 1, 'admin', '<h5 style=\"text-align:left;\"><font color=\"#4d80bf\" id=\"n2h6n\" style=\"font-weight: normal;\">社区平台或者说论坛，就是一个为大家展现自己想法，进行创作和交流互动的空间，</font></h5><h5 style=\"text-align:left;\"><font color=\"#4d80bf\" style=\"font-weight: normal;\">想象一般的社区平台，常规的分类有常规的分类有文章类社区平台如知乎，视频类社区平台如B站，</font></h5><h5 style=\"text-align:left;\"><font color=\"#4d80bf\" style=\"font-weight: normal;\">或者其他分类包括音乐创作平台例如网易云，如图片类创作平例如花瓣，</font></h5><h5 style=\"text-align:left;\"><font color=\"#4d80bf\" style=\"font-weight: normal;\">这些社区平台的共同目标就是，</font></h5><h5 style=\"text-align:left;\"><font color=\"#4d80bf\" style=\"font-weight: normal;\">为用户提供创作空间——即发布自己的作品、创作灵感——即浏览他人的作品，以及交流互动的平台。</font></h5><h5 style=\"text-align:left;\"><br/></h5>');
INSERT INTO `doceditor` VALUES (29, 31, '新增发布2', 1, 'admin', '<h5 style=\"text-align:left;\"><font color=\"#4d80bf\" style=\"font-weight: normal;\">考虑到开发人员是一个天天需要和各种软件、技术文档打交道的用户群体，他们对于网络学习交流的需求是极大的，</font></h5><h5 style=\"text-align:left;\"><font color=\"#4d80bf\" style=\"font-weight: normal;\">由于专业的特殊性，普通的文章社区平台根本无法满足广大技术人员学习交流的需求，因此构建一个适宜的社区平台很有必要。</font></h5><h5 style=\"text-align:left;\"><font color=\"#4d80bf\" style=\"font-weight: normal;\">从本人的上网经验来看，由于学习任务的需要，有时要访问各种网站、跳转各种链接，辗转于各大网盘之间才能下载到需要的文件。</font></h5><h5 style=\"text-align:left;\"><font color=\"#4d80bf\" style=\"font-weight: normal;\">于是我希望能够构建一个文档社区平台，不仅能通过视频进行操作演示、口头讲解等，还可以通过图文内容解释进行详细的书面展示，</font></h5><h5 style=\"text-align:left;\"><font color=\"#4d80bf\" style=\"font-weight: normal;\">更重要的是不必跳转第三方，可以直接在页面上获取到关键文件，以此能够方便各种教学需要、创作需要。</font></h5><div style=\"text-align:left;\"><h5><font color=\"#4d80bf\" id=\"ry5nq\" style=\"font-weight: normal;\">于是就诞生了创作本项目平台的思路，本文档社区平台不仅要求实现多种文件格式的预览方案，还能为用户提供直接获取源文件的下载渠道，方便用户二次创作。</font></h5></div>');
INSERT INTO `doceditor` VALUES (33, 30, '新增发布1', 1, 'admin', '<h5 style=\"text-align:left;\"><span style=\"font-weight: normal; background-color: rgb(255, 255, 255);\"><font color=\"#1c487f\">而这些社区平台的共同特点就是，为各自的主体内容打造一个专属的共享空间，看视频就到视频网站，看小说就到小说网站，听歌就到音乐网站，</font></span></h5><h5 style=\"text-align:left;\"><span style=\"font-weight: normal; background-color: rgb(255, 255, 255);\"><font color=\"#1c487f\">它们都是为各自的内容选择了一种专属的展现形式，而这既是平台的优势也是局限，</font></span></h5><h5 style=\"text-align:left;\"><span style=\"font-weight: normal; background-color: rgb(255, 255, 255);\"><font color=\"#1c487f\">像广为人知的新浪微博，则集合了图文、视频更加丰富的内容形式，由于能够展示更加多样化的内容形式和优秀的互动体验而收获了庞大的用户群体。</font></span></h5><h5 style=\"text-align:left;\"><span style=\"font-weight: normal; background-color: rgb(255, 255, 255);\"><font color=\"#1c487f\">由此可知，社区平台是否能吸引用户的关键，就在于能否灵活展现用户的想法，</font></span></h5><h5 style=\"text-align:left;\"><span style=\"font-weight: normal; background-color: rgb(255, 255, 255);\"><font color=\"#1c487f\">落实到开发上就在于能否处理不同格式的文件内容，用于展示、甚至用于制定自定义、个性化的编辑方案。</font></span></h5>');
INSERT INTO `doceditor` VALUES (34, 31, '新增发布2', 1, 'admin', '<p>555</p>');
INSERT INTO `doceditor` VALUES (35, 31, '新增发布2', 1, 'admin', '<p>666</p>');
INSERT INTO `doceditor` VALUES (37, 32, '新增发布3', 1, 'admin', '<p>测试内容</p>');
INSERT INTO `doceditor` VALUES (38, 32, '新增发布3', 1, 'admin', '<p>测试内容33</p>');
INSERT INTO `doceditor` VALUES (39, 30, '新增发布1', 1, 'admin', '<h5 style=\"text-align:left;\"><font color=\"#46acc8\" style=\"font-weight: normal; background-color: rgb(238, 236, 224);\">由于专业的原因，我需要经常在网站跟看视频教程、搜索问答等，并从别人的经验从中收获许多。</font></h5><h5 style=\"text-align:left;\"><font color=\"#46acc8\" style=\"font-weight: normal; background-color: rgb(238, 236, 224);\">网络社区本就是一个及其重要的学习交流的平台，而且一旦平台为用户提供了适宜的表达的窗口，</font></h5><h5 style=\"text-align:left;\"><font color=\"#46acc8\" style=\"font-weight: normal; background-color: rgb(238, 236, 224);\">就会有源源不断的用户这个加入社区、就会有源源不断的用户发布自己的观点，</font></h5><h5 style=\"text-align:left;\"><font color=\"#46acc8\" style=\"font-weight: normal; background-color: rgb(238, 236, 224);\">并且进一步促进平台功能的完善，为知识的传播起到了极大的良性循环作用。</font><span style=\"text-align: center; background-color: rgb(255, 255, 255);\"></span></h5>');
INSERT INTO `doceditor` VALUES (82, 42, '张三的发布', 5, '张三', '<p data-we-empty-p=\"\" style=\"text-align:left;\"><font face=\"楷体\">这是测试文本，这是测试文本，这是测试文本，这是测试文本，这是测试文本，这是测试文本，这是测试文本，这是测试文本，这是测试文本，这是测试文本，这是测试文本，这是测试文本，这是测试文本，这是测试文本，这是测试文本，这是测试文本，这是测试文本，这是测试文本，这是测试文本，这是测试文本，这是测试文本，这是测试文本</font></p>');
INSERT INTO `doceditor` VALUES (83, 43, '张三的发布2', 5, '张三', '<p data-we-empty-p=\"\" style=\"text-align:left;\"><font face=\"楷体\" color=\"#4d80bf\"><i>这是测试文本，这是测试文本，这是测试文本，这是测试文本，这是测试文本，这是测试文本，这是测试文本，这是测试文本，这是测试文本，这是测试文本，这是测试文本，这是测试文本，这是测试文本，这是测试文本，这是测试文本，这是测试文本，这是测试文本，这是测试文本，这是测试文本，这是测试文本，这是测试文本，这是测试文本</i></font></p>');

SET FOREIGN_KEY_CHECKS = 1;
