/*
 Navicat Premium Data Transfer

 Source Server         : localhost_3306
 Source Server Type    : MySQL
 Source Server Version : 80040
 Source Host           : localhost:3306
 Source Schema         : springboot

 Target Server Type    : MySQL
 Target Server Version : 80040
 File Encoding         : 65001

 Date: 03/06/2025 16:37:30
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for syncjoin
-- ----------------------------
DROP TABLE IF EXISTS `syncjoin`;
CREATE TABLE `syncjoin`  (
  `id` int NOT NULL AUTO_INCREMENT COMMENT '用户的加入协同对象id',
  `userid` int NULL DEFAULT NULL COMMENT '用户id',
  `username` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '用户名',
  `joinid` int NULL DEFAULT NULL COMMENT '协同id',
  `joinauthorid` int NULL DEFAULT NULL COMMENT '协同创建者id',
  `joinauthorname` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '协同创建者名',
  `jointitle` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '协同标题',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 90 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '协同加入表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of syncjoin
-- ----------------------------
INSERT INTO `syncjoin` VALUES (30, 5, '张三', 11, 1, 'admin', 'admin的协同2');
INSERT INTO `syncjoin` VALUES (32, 1, 'admin', 5, 5, '张三', '张三新建协同编辑3');
INSERT INTO `syncjoin` VALUES (37, 6, '李四', 5, 5, '张三', '张三新建协同编辑3');
INSERT INTO `syncjoin` VALUES (38, 1, 'admin', 4, 5, '张三', '张三的新建协同编辑2');
INSERT INTO `syncjoin` VALUES (83, 3, '张老师', 5, 5, '张三', '张三新建协同编辑3');
INSERT INTO `syncjoin` VALUES (88, 4, '赵老师', 3, 5, '张三', '张三的新建协同编辑');

SET FOREIGN_KEY_CHECKS = 1;
