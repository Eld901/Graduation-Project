/*
 Navicat Premium Data Transfer

 Source Server         : localhost_3306
 Source Server Type    : MySQL
 Source Server Version : 80040
 Source Host           : localhost:3306
 Source Schema         : springboot

 Target Server Type    : MySQL
 Target Server Version : 80040
 File Encoding         : 65001

 Date: 03/06/2025 16:36:49
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for log
-- ----------------------------
DROP TABLE IF EXISTS `log`;
CREATE TABLE `log`  (
  `id` int NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `content` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL COMMENT '操作内容',
  `time` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '操作时间',
  `username` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '操作人',
  `ip` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '操作人IP',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 388 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '系统日志表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of log
-- ----------------------------
INSERT INTO `log` VALUES (296, '修改图书信息', '2025-05-19 14:43:22', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `log` VALUES (367, '登录该系统', '2025-05-29 12:39:23', '李四', '0:0:0:0:0:0:0:1');
INSERT INTO `log` VALUES (386, '登录系统', '2025-06-02 17:24:44', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `log` VALUES (387, '登录系统', '2025-06-02 17:24:50', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `log` VALUES (388, '登录系统', '2025-06-02 19:25:49', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `log` VALUES (389, '登录系统', '2025-06-03 09:08:53', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `log` VALUES (390, '登录系统', '2025-06-03 11:09:08', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `log` VALUES (391, '登录系统', '2025-06-03 12:42:48', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `log` VALUES (392, '登录系统', '2025-06-03 13:45:47', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `log` VALUES (393, '更新日志操作', '2025-06-03 14:35:34', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `log` VALUES (394, '登录系统', '2025-06-03 14:58:14', '张三', '0:0:0:0:0:0:0:1');
INSERT INTO `log` VALUES (395, '登录系统', '2025-06-03 15:00:30', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `log` VALUES (396, '登录系统', '2025-06-03 15:00:53', '张三', '0:0:0:0:0:0:0:1');
INSERT INTO `log` VALUES (397, '登录系统', '2025-06-03 15:21:34', 'admin', '0:0:0:0:0:0:0:1');
INSERT INTO `log` VALUES (398, '登录系统', '2025-06-03 15:22:08', '张三', '0:0:0:0:0:0:0:1');

SET FOREIGN_KEY_CHECKS = 1;
