/*
 Navicat Premium Data Transfer

 Source Server         : localhost_3306
 Source Server Type    : MySQL
 Source Server Version : 80040
 Source Host           : localhost:3306
 Source Schema         : springboot

 Target Server Type    : MySQL
 Target Server Version : 80040
 File Encoding         : 65001

 Date: 03/06/2025 16:37:40
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for syncuser
-- ----------------------------
DROP TABLE IF EXISTS `syncuser`;
CREATE TABLE `syncuser`  (
  `id` int NOT NULL AUTO_INCREMENT COMMENT '协同成员对象id',
  `syncid` int NULL DEFAULT NULL COMMENT '协同id',
  `synctitle` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '协同标题',
  `userid` int NULL DEFAULT NULL COMMENT '成员id',
  `username` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '成员名',
  `syncjoinid` int NULL DEFAULT NULL COMMENT '加入协同id',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 52 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '协同成员列表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of syncuser
-- ----------------------------
INSERT INTO `syncuser` VALUES (17, 11, 'admin的协同2', 5, '张三', 30);
INSERT INTO `syncuser` VALUES (19, 5, '张三新建协同编辑3', 1, 'admin', 32);
INSERT INTO `syncuser` VALUES (24, 5, '张三新建协同编辑3', 6, '李四', 37);
INSERT INTO `syncuser` VALUES (25, 4, '张三的新建协同编辑2', 1, 'admin', 38);
INSERT INTO `syncuser` VALUES (47, 5, '张三新建协同编辑3', 3, '张老师', 83);
INSERT INTO `syncuser` VALUES (50, 3, '张三的新建协同编辑', 4, '赵老师', 88);

SET FOREIGN_KEY_CHECKS = 1;
